require('dotenv').config();
const http = require('http');
const https = require('https');
const RSSParser = require('rss-parser');
const ti = require('technicalindicators');
const Database = require('better-sqlite3');
const Anthropic = require('@anthropic-ai/sdk');
const { URL } = require('url');

// ─────────────────────────────────────────────
// FINNHUB WEBSOCKET — Real-time tick prices
// Free tier: live during market hours, Yahoo fallback otherwise
// ─────────────────────────────────────────────
const FINNHUB_KEY = 'd6lavqpr01qr0gn6hkn0d6lavqpr01qr0gn6hkng';
const finnhubPrices = {};
const finnhubSubscribed = new Set();
let finnhubWs = null;
let finnhubReady = false;

function connectFinnhub() {
  try {
    const WebSocket = require('ws');
    finnhubWs = new WebSocket(`wss://ws.finnhub.io?token=${FINNHUB_KEY}`);
    finnhubWs.on('open', () => {
      finnhubReady = true;
      console.log('[Finnhub] Connected — live prices active');
      finnhubSubscribed.forEach(t => finnhubWs.send(JSON.stringify({ type: 'subscribe', symbol: t })));
    });
    finnhubWs.on('message', (raw) => {
      try {
        const msg = JSON.parse(raw);
        if (msg.type === 'trade' && msg.data) {
          msg.data.forEach(trade => {
            const isNew = !finnhubPrices[trade.s];
            finnhubPrices[trade.s] = { price: trade.p, volume: trade.v, ts: Date.now() };
            if (isNew) console.log(`[Finnhub] Live: ${trade.s} = ${trade.p}`);
          });
        }
        if (msg.type === 'ping') finnhubWs.send(JSON.stringify({ type: 'pong' }));
      } catch(e) {}
    });
    finnhubWs.on('error', () => { finnhubReady = false; });
    finnhubWs.on('close', () => {
      finnhubReady = false;
      setTimeout(connectFinnhub, 5000);
    });
  } catch(e) { console.log('[Finnhub] Error:', e.message); }
}

function finnhubSubscribe(ticker) {
  if (finnhubSubscribed.has(ticker)) return;
  finnhubSubscribed.add(ticker);
  if (finnhubReady && finnhubWs) {
    finnhubWs.send(JSON.stringify({ type: 'subscribe', symbol: ticker }));
    console.log(`[Finnhub] Subscribed: ${ticker}`);
  }
}

function getFinnhubPrice(ticker) {
  const p = finnhubPrices[ticker];
  if (!p) return null;
  if (Date.now() - p.ts > 120000) return null;
  return p;
}

connectFinnhub();

async function checkSignalResults() {
  const pending = db.prepare(`
    SELECT * FROM signal_log 
    WHERE (price_1d IS NULL AND datetime(logged_at, '+1 day') < datetime('now'))
       OR (price_7d IS NULL AND datetime(logged_at, '+7 days') < datetime('now'))
  `).all();

  for (const row of pending) {
    try {
      const p = await fetchYahooPrice(row.ticker);
      if (!p) continue;
      const hoursAgo = (Date.now() - new Date(row.logged_at).getTime()) / 3600000;

      if (!row.price_1d && hoursAgo >= 24) {
        const result = evaluateSignal(row.signal, row.price_at_signal, p);
        db.prepare('UPDATE signal_log SET price_1d=?, result_1d=? WHERE id=?').run(p, result, row.id);
      }
      if (!row.price_7d && hoursAgo >= 168) {
        const result = evaluateSignal(row.signal, row.price_at_signal, p);
        db.prepare('UPDATE signal_log SET price_7d=?, result_7d=? WHERE id=?').run(p, result, row.id);
      }
    } catch(e) {}
  }
}

function evaluateSignal(signal, entryPrice, currentPrice) {
  const change = ((currentPrice - entryPrice) / entryPrice) * 100;
  if (signal === 'STRONG BUY' || signal === 'BUY') {
    return change > 0 ? 'CORRECT' : 'WRONG';
  } else if (signal === 'STRONG SELL' || signal === 'SELL') {
    return change < 0 ? 'CORRECT' : 'WRONG';
  }
  return 'NEUTRAL';
}

// Check signal results every hour
setInterval(checkSignalResults, 3600000);
setTimeout(checkSignalResults, 5000);

const rssParser = new RSSParser();
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const db = new Database('wealthcore.db');

db.exec(`
  CREATE TABLE IF NOT EXISTS portfolio (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker TEXT NOT NULL,
    name TEXT,
    shares REAL NOT NULL,
    buyPrice REAL NOT NULL,
    buyCurrency TEXT DEFAULT 'USD',
    addedAt TEXT DEFAULT CURRENT_TIMESTAMP
  )
`);

// Migrate existing portfolio table if buyCurrency column missing
try { db.exec(`ALTER TABLE portfolio ADD COLUMN buyCurrency TEXT DEFAULT 'USD'`); } catch(e) {}
try { db.exec(`ALTER TABLE portfolio ADD COLUMN sector TEXT DEFAULT 'General'`); } catch(e) {}
try { db.exec(`ALTER TABLE portfolio ADD COLUMN groupLabel TEXT DEFAULT ''`); } catch(e) {}

db.exec(`
  CREATE TABLE IF NOT EXISTS expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT NOT NULL,
    category TEXT NOT NULL,
    description TEXT,
    amount REAL NOT NULL,
    date TEXT NOT NULL,
    createdAt TEXT DEFAULT CURRENT_TIMESTAMP
  )
`);

db.exec(`
  CREATE TABLE IF NOT EXISTS assets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    name TEXT NOT NULL,
    value REAL NOT NULL,
    currency TEXT DEFAULT 'GBP',
    notes TEXT,
    addedAt TEXT DEFAULT CURRENT_TIMESTAMP
  )
`);

db.exec(`
  CREATE TABLE IF NOT EXISTS signal_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker TEXT NOT NULL,
    signal TEXT NOT NULL,
    score INTEGER,
    price_at_signal REAL,
    price_1d REAL,
    price_3d REAL,
    price_7d REAL,
    result_1d TEXT,
    result_7d TEXT,
    logged_at TEXT DEFAULT CURRENT_TIMESTAMP
  )
`);

// ─── GUARDIAN AI TABLES ───
db.exec(`
  CREATE TABLE IF NOT EXISTS guardian_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type TEXT NOT NULL,
    ticker TEXT,
    detail TEXT,
    session_id TEXT,
    ts TEXT DEFAULT CURRENT_TIMESTAMP
  )
`);

db.exec(`
  CREATE TABLE IF NOT EXISTS guardian_interventions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    level TEXT NOT NULL,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    trigger_type TEXT,
    dismissed INTEGER DEFAULT 0,
    ts TEXT DEFAULT CURRENT_TIMESTAMP
  )
`);

db.exec(`
  CREATE TABLE IF NOT EXISTS guardian_profile (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
  )
`);

// ─── PAPER TRADING TABLE ───
db.exec(`
  CREATE TABLE IF NOT EXISTS paper_trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker TEXT NOT NULL,
    name TEXT,
    action TEXT NOT NULL,
    shares REAL NOT NULL,
    price REAL NOT NULL,
    total REAL NOT NULL,
    notes TEXT,
    opened_at TEXT DEFAULT CURRENT_TIMESTAMP,
    closed_at TEXT,
    close_price REAL,
    pnl REAL,
    status TEXT DEFAULT 'OPEN'
  )
`);

db.exec(`
  CREATE TABLE IF NOT EXISTS paper_balance (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    cash REAL DEFAULT 10000,
    starting_cash REAL DEFAULT 10000,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
  )
`);

// Seed paper balance if not exists
const existingBalance = db.prepare('SELECT id FROM paper_balance WHERE id = 1').get();
if (!existingBalance) {
  db.prepare('INSERT INTO paper_balance (id, cash, starting_cash) VALUES (1, 10000, 10000)').run();
}

// ═══════════════════════════════════════════════════════════════
// 📊 WEALTHCORE DATA ENGINE — Personal Alpha Database
// Collects data every market day. Builds YOUR edge over time.
// Layer 1: Daily snapshots | Layer 2: Earnings | Layer 3: Insiders
// ═══════════════════════════════════════════════════════════════

// ─── WATCHLIST TABLE — dynamic, user managed ───
db.exec(`
  CREATE TABLE IF NOT EXISTS watchlist (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker TEXT UNIQUE NOT NULL,
    name TEXT,
    category TEXT DEFAULT 'General',
    added_at TEXT DEFAULT CURRENT_TIMESTAMP,
    active INTEGER DEFAULT 1
  )
`);

// ─── DAILY SNAPSHOTS — the core data layer ───
db.exec(`
  CREATE TABLE IF NOT EXISTS daily_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker TEXT NOT NULL,
    date TEXT NOT NULL,
    price REAL,
    open REAL,
    high REAL,
    low REAL,
    volume INTEGER,
    avg_volume_20d INTEGER,
    vol_ratio REAL,
    change_1d REAL,
    change_5d REAL,
    change_20d REAL,
    rsi_14 REAL,
    macd REAL,
    macd_signal REAL,
    sma_20 REAL,
    sma_50 REAL,
    sma_200 REAL,
    bb_upper REAL,
    bb_lower REAL,
    bb_width REAL,
    year_high REAL,
    year_low REAL,
    dist_from_high REAL,
    dist_from_low REAL,
    fear_greed_score REAL,
    collected_at TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(ticker, date)
  )
`);

// ─── EARNINGS DATABASE ───
db.exec(`
  CREATE TABLE IF NOT EXISTS earnings_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker TEXT NOT NULL,
    earnings_date TEXT NOT NULL,
    period TEXT,
    est_eps REAL,
    actual_eps REAL,
    eps_surprise REAL,
    eps_surprise_pct REAL,
    est_revenue REAL,
    actual_revenue REAL,
    rev_surprise_pct REAL,
    guidance TEXT,
    price_before REAL,
    price_1d_after REAL,
    price_5d_after REAL,
    price_20d_after REAL,
    reaction_1d REAL,
    reaction_5d REAL,
    reaction_20d REAL,
    beat_miss TEXT,
    collected_at TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(ticker, earnings_date)
  )
`);

// ─── INSIDER TRADES (SEC FORM 4) ───
db.exec(`
  CREATE TABLE IF NOT EXISTS insider_trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker TEXT NOT NULL,
    insider_name TEXT,
    insider_title TEXT,
    trade_type TEXT,
    shares REAL,
    price REAL,
    value REAL,
    shares_owned_after REAL,
    filing_date TEXT,
    trade_date TEXT,
    form_url TEXT,
    price_30d_after REAL,
    return_30d REAL,
    collected_at TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(ticker, insider_name, trade_date, shares)
  )
`);

// ─── NEWS SENTIMENT ARCHIVE ───
db.exec(`
  CREATE TABLE IF NOT EXISTS news_archive (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker TEXT NOT NULL,
    date TEXT NOT NULL,
    headline TEXT NOT NULL,
    source TEXT,
    sentiment_score REAL,
    sentiment_label TEXT,
    price_at_publish REAL,
    price_1d_after REAL,
    price_reaction REAL,
    collected_at TEXT DEFAULT CURRENT_TIMESTAMP
  )
`);

// ─── PATTERN DISCOVERIES ───
db.exec(`
  CREATE TABLE IF NOT EXISTS patterns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker TEXT,
    pattern_type TEXT NOT NULL,
    description TEXT NOT NULL,
    occurrences INTEGER DEFAULT 0,
    win_rate REAL,
    avg_return REAL,
    sample_size INTEGER,
    last_seen TEXT,
    discovered_at TEXT DEFAULT CURRENT_TIMESTAMP
  )
`);

// ─── DATA ENGINE STATUS ───
db.exec(`
  CREATE TABLE IF NOT EXISTS data_engine_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_date TEXT NOT NULL,
    tickers_collected INTEGER DEFAULT 0,
    earnings_collected INTEGER DEFAULT 0,
    insiders_collected INTEGER DEFAULT 0,
    news_collected INTEGER DEFAULT 0,
    errors TEXT,
    duration_ms INTEGER,
    ts TEXT DEFAULT CURRENT_TIMESTAMP
  )
`);

// Seed watchlist with all known holdings
const seedTickers = [
  { ticker: 'MSFT', name: 'Microsoft', category: 'Technology' },
  { ticker: 'NVDA', name: 'Nvidia', category: 'Technology' },
  { ticker: 'GOOG', name: 'Alphabet', category: 'Technology' },
  { ticker: 'AAPL', name: 'Apple', category: 'Technology' },
  { ticker: 'AMD', name: 'Advanced Micro Devices', category: 'Technology' },
  { ticker: 'ASML', name: 'ASML', category: 'Technology' },
  { ticker: 'AVGO', name: 'Broadcom', category: 'Technology' },
  { ticker: 'MU', name: 'Micron Technology', category: 'Technology' },
  { ticker: 'TXN', name: 'Texas Instruments', category: 'Technology' },
  { ticker: 'CSCO', name: 'Cisco Systems', category: 'Technology' },
  { ticker: 'ORCL', name: 'Oracle', category: 'Technology' },
  { ticker: 'SNDK', name: 'Sandisk', category: 'Technology' },
  { ticker: 'V', name: 'Visa', category: 'Technology' },
  { ticker: 'SERV', name: 'Serve Robotics', category: 'Small Tech' },
  { ticker: 'CRWV', name: 'CoreWeave', category: 'Small Tech' },
  { ticker: 'JNJ', name: 'Johnson & Johnson', category: 'Healthcare' },
  { ticker: 'LLY', name: 'Eli Lilly', category: 'Healthcare' },
  { ticker: 'AZN', name: 'AstraZeneca', category: 'Healthcare' },
  { ticker: 'ABT', name: 'Abbott Laboratories', category: 'Healthcare' },
  { ticker: 'HIMS', name: 'Hims & Hers Health', category: 'Healthcare' },
  { ticker: 'PEP', name: 'PepsiCo', category: 'Staples' },
  { ticker: 'PG', name: 'Procter & Gamble', category: 'Staples' },
  { ticker: 'COST', name: 'Costco', category: 'Staples' },
  { ticker: 'CVX', name: 'Chevron', category: 'Resources' },
  { ticker: 'APD', name: 'Air Products', category: 'Resources' },
  { ticker: 'BNZL', name: 'Bunzl', category: 'Industrial' },
  { ticker: 'MTO', name: 'Mitie Group', category: 'Industrial' },
  { ticker: 'SPY', name: 'S&P 500 ETF', category: 'Index' },
  { ticker: 'QQQ', name: 'NASDAQ ETF', category: 'Index' },
  { ticker: 'GLD', name: 'Gold ETF', category: 'Commodities' },
];
const insertWatchlist = db.prepare('INSERT OR IGNORE INTO watchlist (ticker, name, category) VALUES (?, ?, ?)');
seedTickers.forEach(s => insertWatchlist.run(s.ticker, s.name, s.category));

// ─── DATA ENGINE FUNCTIONS ───

// Collect daily snapshot for one ticker
async function collectSnapshot(ticker) {
  try {
    const [quote, hist] = await Promise.all([fetchStock(ticker), fetchHistorical(ticker)]);
    const closes = hist.closes.filter(c => c !== null);
    const volumes = hist.volumes.filter(v => v !== null);
    if (closes.length < 20) return null;

    const sma20arr = ti.SMA.calculate({ values: closes, period: 20 });
    const sma50arr = ti.SMA.calculate({ values: closes, period: Math.min(50, closes.length - 1) });
    const sma200arr = ti.SMA.calculate({ values: closes, period: Math.min(200, closes.length - 1) });
    const rsiArr = ti.RSI.calculate({ values: closes, period: 14 });
    const macdArr = ti.MACD.calculate({ values: closes, fastPeriod: 12, slowPeriod: 26, signalPeriod: 9, SimpleMAOscillator: false, SimpleMASignal: false });
    const bbArr = ti.BollingerBands.calculate({ values: closes, period: 20, stdDev: 2 });

    const price = quote.price;
    const avgVol20 = volumes.slice(-21, -1).reduce((a, b) => a + b, 0) / 20;
    const todayVol = volumes[volumes.length - 1];
    const volRatio = avgVol20 > 0 ? todayVol / avgVol20 : 1;
    const change1d = closes.length > 1 ? ((closes[closes.length-1] - closes[closes.length-2]) / closes[closes.length-2] * 100) : 0;
    const change5d = closes.length > 6 ? ((closes[closes.length-1] - closes[closes.length-6]) / closes[closes.length-6] * 100) : 0;
    const change20d = closes.length > 21 ? ((closes[closes.length-1] - closes[closes.length-21]) / closes[closes.length-21] * 100) : 0;
    const bb = bbArr[bbArr.length - 1];
    const macd = macdArr[macdArr.length - 1];
    const bbWidth = bb ? (bb.upper - bb.lower) / bb.middle : 0;
    const distFromHigh = quote.yearHigh ? ((quote.yearHigh - price) / quote.yearHigh * 100) : 0;
    const distFromLow = quote.yearLow ? ((price - quote.yearLow) / quote.yearLow * 100) : 0;
    const today = new Date().toISOString().split('T')[0];

    db.prepare(`INSERT OR REPLACE INTO daily_snapshots 
      (ticker, date, price, volume, avg_volume_20d, vol_ratio, change_1d, change_5d, change_20d,
       rsi_14, macd, macd_signal, sma_20, sma_50, sma_200, bb_upper, bb_lower, bb_width,
       year_high, year_low, dist_from_high, dist_from_low)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(ticker, today, price, todayVol, Math.round(avgVol20), parseFloat(volRatio.toFixed(2)),
        parseFloat(change1d.toFixed(2)), parseFloat(change5d.toFixed(2)), parseFloat(change20d.toFixed(2)),
        parseFloat((rsiArr[rsiArr.length-1] || 50).toFixed(1)),
        parseFloat((macd?.MACD || 0).toFixed(4)), parseFloat((macd?.signal || 0).toFixed(4)),
        parseFloat((sma20arr[sma20arr.length-1] || price).toFixed(2)),
        parseFloat((sma50arr[sma50arr.length-1] || price).toFixed(2)),
        parseFloat((sma200arr[sma200arr.length-1] || price).toFixed(2)),
        parseFloat((bb?.upper || price).toFixed(2)), parseFloat((bb?.lower || price).toFixed(2)),
        parseFloat(bbWidth.toFixed(4)),
        quote.yearHigh || price, quote.yearLow || price,
        parseFloat(distFromHigh.toFixed(1)), parseFloat(distFromLow.toFixed(1)));
    return { ticker, price, change1d: parseFloat(change1d.toFixed(2)) };
  } catch(e) { return null; }
}

// Collect earnings data from Finnhub
async function collectEarnings(ticker) {
  try {
    const data = await new Promise((resolve, reject) => {
      const options = { hostname: 'finnhub.io', path: `/api/v1/stock/earnings?symbol=${ticker}&limit=8&token=${FINNHUB_KEY}`, method: 'GET' };
      https.get(options, r => {
        let d = ''; r.on('data', c => d += c);
        r.on('end', () => { try { resolve(JSON.parse(d)); } catch(e) { reject(e); } });
      }).on('error', reject);
    });
    if (!Array.isArray(data)) return 0;
    let collected = 0;
    for (const e of data) {
      if (!e.period) continue;
      const epsSurprise = e.actual != null && e.estimate != null ? e.actual - e.estimate : null;
      const epsSurprisePct = e.estimate && e.estimate !== 0 ? (epsSurprise / Math.abs(e.estimate) * 100) : null;
      const beatMiss = epsSurprise > 0 ? 'BEAT' : epsSurprise < 0 ? 'MISS' : 'IN-LINE';
      try {
        db.prepare(`INSERT OR IGNORE INTO earnings_history 
          (ticker, earnings_date, period, est_eps, actual_eps, eps_surprise, eps_surprise_pct, beat_miss)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
          .run(ticker, e.period, e.period, e.estimate, e.actual, epsSurprise, epsSurprisePct, beatMiss);
        collected++;
      } catch(e2) {}
    }
    return collected;
  } catch(e) { return 0; }
}

// Collect insider trades from SEC EDGAR (free RSS feed)
async function collectInsiders(ticker) {
  try {
    const data = await new Promise((resolve, reject) => {
      const options = { hostname: 'finnhub.io', path: `/api/v1/stock/insider-transactions?symbol=${ticker}&token=${FINNHUB_KEY}`, method: 'GET' };
      https.get(options, r => {
        let d = ''; r.on('data', c => d += c);
        r.on('end', () => { try { resolve(JSON.parse(d)); } catch(e) { reject(e); } });
      }).on('error', reject);
    });
    if (!data?.data || !Array.isArray(data.data)) return 0;
    let collected = 0;
    for (const t of data.data.slice(0, 20)) {
      if (!t.name || !t.transactionDate) continue;
      try {
        db.prepare(`INSERT OR IGNORE INTO insider_trades 
          (ticker, insider_name, insider_title, trade_type, shares, price, value, filing_date, trade_date)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
          .run(ticker, t.name, t.position || '', t.transactionCode === 'P' ? 'BUY' : t.transactionCode === 'S' ? 'SELL' : t.transactionCode,
            t.share, t.transactionPrice, t.value, t.filingDate, t.transactionDate);
        collected++;
      } catch(e2) {}
    }
    return collected;
  } catch(e) { return 0; }
}

// Run full data collection for all active watchlist tickers
async function runDataEngine(manual = false) {
  const start = Date.now();
  const tickers = db.prepare('SELECT ticker FROM watchlist WHERE active = 1').all().map(r => r.ticker);
  console.log(`[DataEngine] Starting collection for ${tickers.length} tickers...`);
  let snapshots = 0, earnings = 0, insiders = 0, errors = [];

  // Collect in batches of 5 to avoid rate limits
  for (let i = 0; i < tickers.length; i += 5) {
    const batch = tickers.slice(i, i + 5);
    const results = await Promise.allSettled(batch.map(async t => {
      const snap = await collectSnapshot(t);
      if (snap) snapshots++;
      const earn = await collectEarnings(t);
      earnings += earn;
      const ins = await collectInsiders(t);
      insiders += ins;
    }));
    results.forEach((r, idx) => { if (r.status === 'rejected') errors.push(batch[idx]); });
    if (i + 5 < tickers.length) await new Promise(r => setTimeout(r, 2000)); // rate limit pause
  }

  const duration = Date.now() - start;
  const today = new Date().toISOString().split('T')[0];
  db.prepare('INSERT INTO data_engine_log (run_date, tickers_collected, earnings_collected, insiders_collected, errors, duration_ms) VALUES (?, ?, ?, ?, ?, ?)')
    .run(today, snapshots, earnings, insiders, errors.join(','), duration);
  console.log(`[DataEngine] Done — ${snapshots} snapshots, ${earnings} earnings, ${insiders} insider trades in ${(duration/1000).toFixed(1)}s`);
  return { snapshots, earnings, insiders, tickers: tickers.length, duration };
}

// ─── AUTO SCHEDULER — runs at 4:30pm UK time on weekdays ───
function scheduleDataEngine() {
  const now = new Date();
  const target = new Date();
  target.setHours(16, 30, 0, 0); // 4:30pm
  if (now >= target) target.setDate(target.getDate() + 1); // next day if already past
  // Skip weekends
  while (target.getDay() === 0 || target.getDay() === 6) target.setDate(target.getDate() + 1);
  const msUntil = target - now;
  console.log(`[DataEngine] Next collection in ${(msUntil/3600000).toFixed(1)} hours`);
  setTimeout(async () => {
    await runDataEngine();
    scheduleDataEngine(); // reschedule for next day
  }, msUntil);
}
scheduleDataEngine();

// ═══════════════════════════════════════════════════════════════
// 🧠 GUARDIAN AI — The Big Brother Intelligence Engine
// Watches everything. Learns everything. Speaks when it must.
// ═══════════════════════════════════════════════════════════════

let guardianSessionId = `s_${Date.now()}`;

// Log every user action silently
function guardianLog(eventType, ticker = null, detail = {}) {
  try {
    db.prepare('INSERT INTO guardian_events (event_type, ticker, detail, session_id) VALUES (?, ?, ?, ?)')
      .run(eventType, ticker, JSON.stringify(detail), guardianSessionId);
  } catch(e) {}
}

// Create an intervention notification
function guardianIntervene(level, title, message, triggerType) {
  try {
    // Don't spam — check if same trigger fired in last 30 mins
    const recent = db.prepare(`SELECT id FROM guardian_interventions WHERE trigger_type = ? AND ts > datetime('now', '-30 minutes')`).get(triggerType);
    if (recent) return false;
    db.prepare('INSERT INTO guardian_interventions (level, title, message, trigger_type) VALUES (?, ?, ?, ?)')
      .run(level, title, message, triggerType);
    console.log(`[Guardian] ${level}: ${title}`);
    return true;
  } catch(e) { return false; }
}

// Update the learned profile
function guardianLearn(key, value) {
  try {
    db.prepare('INSERT OR REPLACE INTO guardian_profile (key, value, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)')
      .run(key, JSON.stringify(value));
  } catch(e) {}
}

function guardianGetProfile(key) {
  try {
    const row = db.prepare('SELECT value FROM guardian_profile WHERE key = ?').get(key);
    return row ? JSON.parse(row.value) : null;
  } catch(e) { return null; }
}

// ── THE MAIN GUARDIAN INTELLIGENCE LOOP ──
// Runs every 5 minutes. Watches. Learns. Acts when needed.
async function runGuardianCheck() {
  try {
    const now = new Date();
    const hourUK = parseInt(new Intl.DateTimeFormat('en-GB', { hour: 'numeric', hour12: false, timeZone: 'Europe/London' }).format(now));
    const today = getToday ? getToday() : now.toISOString().split('T')[0];

    // ── 1. RAPID FIRE SIGNALS — emotional trading detector
    const signalsLast30 = db.prepare(`SELECT COUNT(*) as cnt FROM guardian_events WHERE event_type = 'signal_run' AND ts > datetime('now', '-30 minutes')`).get();
    if (signalsLast30.cnt >= 5) {
      guardianIntervene('WARNING', '⚡ Rapid Fire Signals Detected', `You've run ${signalsLast30.cnt} signals in the last 30 minutes. This pattern often indicates emotional or impulsive trading. Step back. The market will still be there.`, 'rapid_fire_signals');
    }

    // ── 2. LOSS STREAK — consecutive losses
    const recentSignals = db.prepare(`SELECT signal, result_1d FROM signal_log WHERE result_1d IS NOT NULL ORDER BY logged_at DESC LIMIT 5`).all();
    const lossStreak = recentSignals.reduce((streak, s) => {
      if (streak.stopped) return streak;
      if (s.result_1d === 'LOSS') return { count: streak.count + 1, stopped: false };
      return { ...streak, stopped: true };
    }, { count: 0, stopped: false });
    if (lossStreak.count >= 3) {
      guardianIntervene('CRITICAL', `🔴 ${lossStreak.count} Consecutive Losses`, `Your last ${lossStreak.count} trades were losses. This is exactly when traders make their biggest mistakes — trying to recover quickly. Do NOT increase position size. Consider a break.`, 'loss_streak');
    }

    // ── 3. SAME TICKER OBSESSION — concentration risk
    const tickerToday = db.prepare(`SELECT ticker, COUNT(*) as cnt FROM guardian_events WHERE ticker IS NOT NULL AND DATE(ts) = ? GROUP BY ticker ORDER BY cnt DESC LIMIT 1`).get(today);
    if (tickerToday && tickerToday.cnt >= 6) {
      guardianIntervene('WARNING', `👁️ ${tickerToday.ticker} Fixation Detected`, `You've interacted with ${tickerToday.ticker} ${tickerToday.cnt} times today. Heavy focus on a single ticker can distort your risk perception. Are you overexposed or about to be?`, 'ticker_obsession_' + tickerToday.ticker);
    }

    // ── 4. LATE NIGHT TRADING — impaired judgment detector
    if (hourUK >= 22 || hourUK <= 4) {
      const lateActivity = db.prepare(`SELECT COUNT(*) as cnt FROM guardian_events WHERE event_type IN ('signal_run', 'research_query') AND ts > datetime('now', '-60 minutes')`).get();
      if (lateActivity.cnt >= 3) {
        guardianIntervene('WARNING', `🌙 Late Night Trading Alert (${hourUK}:00 UK)`, `You\'re running analysis at ${hourUK}:00. Studies show decision quality drops significantly after 10pm. Your brain is tired. Any decisions made now should be reviewed tomorrow.`, 'late_night_trading');
      }
    }

    // ── 5. OVERTRADING DAY — too many signals in one day
    const signalsToday = db.prepare(`SELECT COUNT(*) as cnt FROM guardian_events WHERE event_type = 'signal_run' AND DATE(ts) = ?`).get(today);
    if (signalsToday.cnt >= 20) {
      guardianIntervene('INFO', `📊 High Activity Day`, `You've run ${signalsToday.cnt} signals today. High signal volume doesn't equal better returns — it often means lower quality decisions. Focus on quality over quantity.`, 'overtrading_day');
    }

    // ── 6. SECTOR CONCENTRATION — all eggs in one basket
    const sectorEvents = db.prepare(`SELECT ticker FROM guardian_events WHERE event_type = 'signal_run' AND DATE(ts) = ?`).all(today);
    const smallCaps = ['NIO', 'LCID', 'RIVN', 'SOFI', 'MARA', 'RIOT', 'GME', 'AMC', 'BBBY', 'SPCE', 'GRAB', 'PLNHF'];
    const smallCapHits = sectorEvents.filter(e => smallCaps.includes(e.ticker));
    if (smallCapHits.length >= 4) {
      guardianIntervene('WARNING', '⚠️ Small-Cap Concentration Risk', `You've been analysing ${smallCapHits.length} small/speculative caps today (${[...new Set(smallCapHits.map(e=>e.ticker))].join(', ')}). These carry extreme volatility. Ensure you have proper position sizing and aren't overexposed.`, 'smallcap_concentration');
    }

    // ── 7. LEARN PATTERNS — update the profile
    const totalSignals = db.prepare("SELECT COUNT(*) as cnt FROM guardian_events WHERE event_type = 'signal_run'").get();
    const totalResearch = db.prepare("SELECT COUNT(*) as cnt FROM guardian_events WHERE event_type = 'research_query'").get();
    const mostSearched = db.prepare('SELECT ticker, COUNT(*) as cnt FROM guardian_events WHERE ticker IS NOT NULL GROUP BY ticker ORDER BY cnt DESC LIMIT 5').all();
    const winRate = (() => {
      const results = db.prepare('SELECT result_1d FROM signal_log WHERE result_1d IS NOT NULL').all();
      if (!results.length) return null;
      const wins = results.filter(r => r.result_1d === 'WIN').length;
      return ((wins / results.length) * 100).toFixed(1);
    })();

    guardianLearn('total_signals', totalSignals.cnt);
    guardianLearn('total_research', totalResearch.cnt);
    guardianLearn('most_searched', mostSearched);
    guardianLearn('win_rate', winRate);
    guardianLearn('last_check', new Date().toISOString());

    // ── 8. PORTFOLIO RISK CHECK
    const portfolio = db.prepare('SELECT * FROM portfolio').all();
    if (portfolio.length > 0) {
      const smallCapPositions = portfolio.filter(p => smallCaps.includes(p.ticker));
      const totalCost = portfolio.reduce((s, p) => s + (p.buyPrice * p.shares), 0);
      const smallCapCost = smallCapPositions.reduce((s, p) => s + (p.buyPrice * p.shares), 0);
      const smallCapPct = totalCost > 0 ? (smallCapCost / totalCost) * 100 : 0;
      if (smallCapPct > 40) {
        guardianIntervene('CRITICAL', `🚨 Portfolio Risk: ${smallCapPct.toFixed(0)}% in Speculative Stocks`, `Over 40% of your portfolio is in high-risk speculative positions. This level of concentration in small/meme caps significantly increases your drawdown risk. Consider rebalancing.`, 'portfolio_smallcap_risk');
      }
    }

  } catch(e) { console.log('[Guardian] Check error:', e.message); }
}

// Run Guardian every 5 minutes
setInterval(runGuardianCheck, 5 * 60 * 1000);
// Run once 10 seconds after boot
setTimeout(runGuardianCheck, 10000);

console.log('[Guardian] AI active — watching, learning, protecting');

function getBody(req) {
  return new Promise((resolve) => {
    const chunks = [];
    req.on('data', chunk => chunks.push(chunk));
    req.on('end', () => {
      try {
        const raw = Buffer.concat(chunks).toString('utf8');
        resolve(raw.length > 0 ? JSON.parse(raw) : {});
      } catch(e) { resolve({}); }
    });
    req.on('error', () => resolve({}));
  });
}

async function fetchYahooPrice(ticker) {
  try {
    const data = await fetchStock(ticker);
    return data.price;
  } catch(e) { return null; }
}

// Finnhub REST quote — current price, not rate limited like Yahoo
function fetchLiveQuote(ticker) {
  return new Promise((resolve, reject) => {
    // Finnhub uses different symbol format for some stocks
    const sym = ticker.replace('.L', ''); // strip London suffix for now
    const options = {
      hostname: 'finnhub.io',
      path: `/api/v1/quote?symbol=${encodeURIComponent(ticker)}&token=${FINNHUB_KEY}`,
      method: 'GET',
      headers: { 'User-Agent': 'Mozilla/5.0' }
    };
    https.get(options, (httpRes) => {
      let data = '';
      httpRes.on('data', chunk => data += chunk);
      httpRes.on('end', () => {
        try {
          const q = JSON.parse(data);
          // Finnhub returns: c=current, o=open, h=high, l=low, pc=prev close, t=timestamp
          if (!q.c || q.c === 0) { reject(new Error('No price data')); return; }
          const price = q.c;
          const change = (q.c - q.pc).toFixed(2);
          const changePct = (((q.c - q.pc) / q.pc) * 100).toFixed(2);
          resolve({
            source: 'FINNHUB_QUOTE',
            ticker,
            price,
            change,
            changePercent: changePct,
            open: q.o,
            high: q.h,
            low: q.l,
            prevClose: q.pc,
            ts: (q.t || Date.now()/1000) * 1000
          });
        } catch(e) { reject(e); }
      });
    }).on('error', reject);
  });
}

function fetchStock(ticker) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'query1.finance.yahoo.com',
      path: `/v8/finance/chart/${ticker}`,
      method: 'GET',
      headers: { 'User-Agent': 'Mozilla/5.0' }
    };
    https.get(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          const meta = json.chart.result[0].meta;
          resolve({
            symbol: meta.symbol,
            name: meta.longName || meta.shortName || ticker,
            price: meta.regularMarketPrice,
            previousClose: meta.previousClose,
            change: (meta.regularMarketPrice - meta.previousClose).toFixed(2),
            changePercent: (((meta.regularMarketPrice - meta.previousClose) / meta.previousClose) * 100).toFixed(2),
            currency: meta.currency,
            yearHigh: meta.fiftyTwoWeekHigh,
            yearLow: meta.fiftyTwoWeekLow,
            volume: meta.regularMarketVolume,
            avgVolume: meta.averageDailyVolume10Day,
          });
        } catch (e) { reject(e); }
      });
    }).on('error', reject);
  });
}

function fetchHistorical(ticker) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'query1.finance.yahoo.com',
      path: `/v8/finance/chart/${ticker}?interval=1d&range=6mo`,
      method: 'GET',
      headers: { 'User-Agent': 'Mozilla/5.0' }
    };
    https.get(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          const result = json.chart.result[0];
          resolve({
            closes: result.indicators.quote[0].close,
            highs: result.indicators.quote[0].high,
            lows: result.indicators.quote[0].low,
            volumes: result.indicators.quote[0].volume
          });
        } catch (e) { reject(e); }
      });
    }).on('error', reject);
  });
}

function getToday() { return new Date().toISOString().split('T')[0]; }
function getDateDaysAgo(days) {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d.toISOString().split('T')[0];
}

function extractSource(item) {
  try {
    const match = item.link && item.link.match(/https?:\/\/(?:www\.)?([^\/]+)/);
    if (match) {
      const domain = match[1].replace('www.', '');
      const sourceMap = {
        'reuters.com': '🔵 Reuters', 'cnbc.com': '🟡 CNBC',
        'marketwatch.com': '🟢 MarketWatch', 'bloomberg.com': '🟠 Bloomberg',
        'ft.com': '🔴 Financial Times', 'bbc.co.uk': '🔵 BBC',
        'finance.yahoo.com': '📊 Yahoo Finance', 'fool.com': '🎯 Motley Fool',
        'seekingalpha.com': '📈 Seeking Alpha', 'wsj.com': '📰 WSJ',
        'forbes.com': '💼 Forbes',
      };
      for (const [key, value] of Object.entries(sourceMap)) {
        if (domain.includes(key)) return value;
      }
      return '📰 ' + domain;
    }
  } catch(e) {}
  return '📰 News';
}

async function fetchAllNews(ticker, companyName) {
  const cleanTicker = ticker.replace('.L', '');
  const shortName = companyName.split(' ')[0];
  const sources = await Promise.allSettled([
    rssParser.parseURL(`https://feeds.finance.yahoo.com/rss/2.0/headline?s=${ticker}&region=US&lang=en-US`)
      .then(feed => feed.items.slice(0, 6).map(item => ({ title: item.title, link: item.link, date: item.pubDate, source: extractSource(item), type: 'news' }))).catch(() => []),
    rssParser.parseURL(`https://news.google.com/rss/search?q=${encodeURIComponent(shortName + ' stock')}&hl=en-US&gl=US&ceid=US:en`)
      .then(feed => feed.items.slice(0, 8).map(item => ({ title: item.title, link: item.link, date: item.pubDate, source: extractSource(item), type: 'news' }))).catch(() => []),
    rssParser.parseURL(`https://efts.sec.gov/LATEST/search-index?q=%22${cleanTicker}%22&forms=4&dateRange=custom&startdt=${getDateDaysAgo(90)}&enddt=${getToday()}`)
      .then(feed => feed.items.slice(0, 3).map(item => ({ title: `🚨 INSIDER TRADE: ${item.title}`, link: item.link, date: item.pubDate || item.isoDate, source: '🔴 SEC EDGAR', type: 'insider' }))).catch(() => []),
  ]);
  let allNews = [];
  const seen = new Set();
  sources.forEach(result => {
    if (result.status === 'fulfilled') {
      result.value.forEach(item => {
        if (!seen.has(item.title)) { seen.add(item.title); allNews.push(item); }
      });
    }
  });
  allNews.sort((a, b) => new Date(b.date) - new Date(a.date));
  return allNews.slice(0, 20);
}

function analyseNewsSentiment(newsItems) {
  const bullishWords = ['surge', 'soar', 'jump', 'rally', 'beat', 'record', 'growth', 'profit', 'upgrade', 'buy', 'bullish', 'strong', 'positive', 'gain', 'rise', 'higher', 'outperform', 'exceed', 'boost', 'win', 'success', 'expand', 'innovation', 'breakthrough', 'deal', 'dividend'];
  const bearishWords = ['crash', 'fall', 'drop', 'plunge', 'miss', 'loss', 'downgrade', 'sell', 'bearish', 'weak', 'negative', 'decline', 'lower', 'disappointing', 'concern', 'risk', 'lawsuit', 'fraud', 'investigation', 'cut', 'layoff', 'warning', 'debt', 'default', 'recall', 'scandal'];
  let bullishScore = 0, bearishScore = 0, insiderBuying = false;
  newsItems.forEach(item => {
    const text = (item.title || '').toLowerCase();
    bullishWords.forEach(word => { if (text.includes(word)) bullishScore++; });
    bearishWords.forEach(word => { if (text.includes(word)) bearishScore++; });
    if (text.includes('insider') && text.includes('buy')) insiderBuying = true;
  });
  const total = bullishScore + bearishScore;
  const sentimentScore = total > 0 ? (bullishScore / total) * 100 : 50;
  return { score: sentimentScore, bullishCount: bullishScore, bearishCount: bearishScore, insiderBuying, label: sentimentScore > 65 ? 'Positive' : sentimentScore < 35 ? 'Negative' : 'Neutral' };
}

async function generateSignal(ticker) {
  const [quote, historical, news] = await Promise.all([
    fetchStock(ticker),
    fetchHistorical(ticker),
    fetchAllNews(ticker, ticker).catch(() => [])
  ]);

  const closes = historical.closes.filter(c => c !== null);
  const volumes = historical.volumes.filter(v => v !== null);
  const currentPrice = quote.price;
  const reasons = [], warnings = [];
  let score = 50;

  const rsiValues = ti.RSI.calculate({ values: closes, period: 14 });
  const rsi = rsiValues[rsiValues.length - 1];
  if (rsi < 30) { score += 20; reasons.push(`RSI is ${rsi.toFixed(1)} — deeply oversold, strong buy zone`); }
  else if (rsi < 45) { score += 10; reasons.push(`RSI is ${rsi.toFixed(1)} — oversold, potential bounce`); }
  else if (rsi > 70) { score -= 20; warnings.push(`RSI is ${rsi.toFixed(1)} — overbought, risk of pullback`); }
  else if (rsi > 60) { score -= 8; warnings.push(`RSI is ${rsi.toFixed(1)} — approaching overbought`); }
  else { reasons.push(`RSI is ${rsi.toFixed(1)} — neutral`); }

  const macdResult = ti.MACD.calculate({ values: closes, fastPeriod: 12, slowPeriod: 26, signalPeriod: 9, SimpleMAOscillator: false, SimpleMASignal: false });
  const macd = macdResult[macdResult.length - 1];
  const macdPrev = macdResult[macdResult.length - 2];
  if (macd && macdPrev) {
    if (macd.MACD > macd.signal && macdPrev.MACD <= macdPrev.signal) { score += 15; reasons.push(`MACD bullish crossover — momentum shifting up`); }
    else if (macd.MACD < macd.signal && macdPrev.MACD >= macdPrev.signal) { score -= 15; warnings.push(`MACD bearish crossover — momentum shifting down`); }
    else if (macd.MACD > macd.signal) { score += 8; reasons.push(`MACD above signal line — upward momentum`); }
    else { score -= 8; warnings.push(`MACD below signal line — downward pressure`); }
  }

  const sma20 = ti.SMA.calculate({ values: closes, period: 20 });
  const sma50 = ti.SMA.calculate({ values: closes, period: 50 });
  const sma200 = ti.SMA.calculate({ values: closes, period: 200 });
  const ma20 = sma20[sma20.length - 1];
  const ma50 = sma50[sma50.length - 1];
  const ma200 = sma200[sma200.length - 1];

  if (currentPrice > ma20) { score += 5; reasons.push(`Above 20-day MA ($${ma20.toFixed(2)}) — short term uptrend`); }
  else { score -= 5; warnings.push(`Below 20-day MA ($${ma20.toFixed(2)}) — short term downtrend`); }
  if (currentPrice > ma50) { score += 8; reasons.push(`Above 50-day MA ($${ma50.toFixed(2)}) — medium term uptrend`); }
  else { score -= 8; warnings.push(`Below 50-day MA ($${ma50.toFixed(2)}) — medium term downtrend`); }
  if (ma200) {
    if (currentPrice > ma200) { score += 10; reasons.push(`Above 200-day MA ($${ma200.toFixed(2)}) — long term uptrend`); }
    else { score -= 10; warnings.push(`Below 200-day MA ($${ma200.toFixed(2)}) — long term downtrend`); }
  }
  if (ma50 && ma200) {
    if (ma50 > ma200) { score += 8; reasons.push(`Golden Cross active — long term bullish`); }
    else { score -= 8; warnings.push(`Death Cross active — long term bearish`); }
  }

  const bbResult = ti.BollingerBands.calculate({ values: closes, period: 20, stdDev: 2 });
  const bb = bbResult[bbResult.length - 1];
  if (bb) {
    if (currentPrice < bb.lower) { score += 15; reasons.push(`Below lower Bollinger Band — oversold, mean reversion likely`); }
    else if (currentPrice > bb.upper) { score -= 15; warnings.push(`Above upper Bollinger Band — overbought`); }
    else {
      const bbPos = ((currentPrice - bb.lower) / (bb.upper - bb.lower)) * 100;
      if (bbPos < 30) { score += 8; reasons.push(`Lower Bollinger zone (${bbPos.toFixed(0)}%) — bullish`); }
      else if (bbPos > 70) { score -= 5; warnings.push(`Upper Bollinger zone (${bbPos.toFixed(0)}%) — extended`); }
    }
  }

  const avgVol = volumes.slice(-20).reduce((a, b) => a + b, 0) / 20;
  const recentVol = volumes[volumes.length - 1];
  const volRatio = recentVol / avgVol;
  if (volRatio > 1.5 && parseFloat(quote.change) > 0) { score += 10; reasons.push(`Volume ${volRatio.toFixed(1)}x avg on up day — conviction buying`); }
  else if (volRatio > 1.5 && parseFloat(quote.change) < 0) { score -= 10; warnings.push(`Volume ${volRatio.toFixed(1)}x avg on down day — conviction selling`); }
  else if (volRatio < 0.5) { warnings.push(`Volume very low — weak conviction`); }

  const yearRange = quote.yearHigh - quote.yearLow;
  const yearPosition = ((currentPrice - quote.yearLow) / yearRange) * 100;
  if (yearPosition < 20) { score += 12; reasons.push(`Near 52-week low (${yearPosition.toFixed(0)}%) — deep value`); }
  else if (yearPosition > 80) { score -= 5; warnings.push(`Near 52-week high (${yearPosition.toFixed(0)}%) — limited upside`); }
  else if (yearPosition > 50) { score += 5; reasons.push(`Upper 52-week range (${yearPosition.toFixed(0)}%) — momentum good`); }

  const sentiment = analyseNewsSentiment(news);
  if (sentiment.insiderBuying) { score += 20; reasons.push(`🚨 INSIDER BUYING DETECTED — extremely bullish`); }
  if (sentiment.score > 65) { score += 10; reasons.push(`News sentiment positive (${sentiment.bullishCount} bullish vs ${sentiment.bearishCount} bearish)`); }
  else if (sentiment.score < 35) { score -= 10; warnings.push(`News sentiment negative (${sentiment.bearishCount} bearish vs ${sentiment.bullishCount} bullish)`); }
  else { reasons.push(`News sentiment neutral`); }

  const priceChange5d = ((closes[closes.length - 1] - closes[closes.length - 6]) / closes[closes.length - 6]) * 100;
  const priceChange20d = ((closes[closes.length - 1] - closes[closes.length - 21]) / closes[closes.length - 21]) * 100;
  if (priceChange5d > 3) { score += 8; reasons.push(`Strong 5-day momentum: +${priceChange5d.toFixed(1)}%`); }
  else if (priceChange5d < -3) { score -= 8; warnings.push(`Weak 5-day momentum: ${priceChange5d.toFixed(1)}%`); }
  if (priceChange20d > 8) { score += 5; reasons.push(`Strong 20-day momentum: +${priceChange20d.toFixed(1)}%`); }
  else if (priceChange20d < -8) { score -= 5; warnings.push(`Weak 20-day momentum: ${priceChange20d.toFixed(1)}%`); }

  score = Math.max(0, Math.min(100, score));
  let signal, signalColor, recommendation;
  if (score >= 75) { signal = 'STRONG BUY'; signalColor = '#2ECC8F'; recommendation = `Multiple strong bullish signals aligned. Compelling entry point.`; }
  else if (score >= 60) { signal = 'BUY'; signalColor = '#2ECC8F'; recommendation = `More bullish than bearish. Conditions favour upward move.`; }
  else if (score >= 45) { signal = 'HOLD'; signalColor = '#C8A84B'; recommendation = `Mixed signals. Hold existing positions and wait for clearer setup.`; }
  else if (score >= 30) { signal = 'SELL'; signalColor = '#E05555'; recommendation = `More bearish signals. Consider reducing exposure.`; }
  else { signal = 'STRONG SELL'; signalColor = '#E05555'; recommendation = `Multiple bearish signals. High risk of further downside.`; }

  // ─── TRADE LEVELS (ATR-based) ───
  // ATR = Average True Range over 14 days — measures volatility
  const highs = historical.highs || [];
  const lows = historical.lows || [];
  let tradeLevels = null;

  if (highs.length >= 14 && lows.length >= 14) {
    // Calculate ATR manually
    const trValues = [];
    for (let i = 1; i < Math.min(closes.length, highs.length, lows.length); i++) {
      const tr = Math.max(
        highs[i] - lows[i],
        Math.abs(highs[i] - closes[i - 1]),
        Math.abs(lows[i] - closes[i - 1])
      );
      trValues.push(tr);
    }
    const atr = trValues.slice(-14).reduce((a, b) => a + b, 0) / 14;
    const atrPct = (atr / currentPrice * 100).toFixed(1);

    // Key support/resistance levels
    const recentHighs = highs.slice(-20);
    const recentLows = lows.slice(-20);
    const resistance = Math.max(...recentHighs);
    const support = Math.min(...recentLows);

    // Entry zone — slightly above current for BUY (don't chase), at current for STRONG BUY
    const isBullish = signal === 'STRONG BUY' || signal === 'BUY';
    const isBearish = signal === 'STRONG SELL' || signal === 'SELL';

    let entry, stopLoss, tp1, tp2, tp3, stopReason, entryReason;

    if (isBullish) {
      // Entry: at current price or wait for slight dip to MA support
      const entryFromMA = Math.max(ma20 || 0, ma50 || 0);
      entry = signal === 'STRONG BUY' ? currentPrice : Math.min(currentPrice, entryFromMA * 1.005);
      
      // Stop loss: 1.5x ATR below entry OR below key support (whichever is tighter)
      const atrStop = entry - (atr * 1.5);
      const supportStop = support * 0.995;
      stopLoss = Math.max(atrStop, supportStop); // tighter stop
      stopReason = Math.abs(entry - atrStop) < Math.abs(entry - supportStop) 
        ? `1.5× ATR (${atr.toFixed(2)}) below entry` 
        : `Just below recent support (${support.toFixed(2)})`;

      const risk = entry - stopLoss;
      tp1 = entry + (risk * 1.5);   // 1.5:1 R:R
      tp2 = entry + (risk * 2.5);   // 2.5:1 R:R
      tp3 = entry + (risk * 4.0);   // 4:1 R:R — runner target
      entryReason = signal === 'STRONG BUY' ? 'Enter at market — strong momentum' : `Wait for price to pull back to ~${(entry).toFixed(2)}`;

    } else if (isBearish) {
      entry = currentPrice;
      const atrStop = entry + (atr * 1.5);
      const resistanceStop = resistance * 1.005;
      stopLoss = Math.min(atrStop, resistanceStop);
      stopReason = `1.5× ATR above entry — if price reclaims this, trend has reversed`;

      const risk = stopLoss - entry;
      tp1 = entry - (risk * 1.5);
      tp2 = entry - (risk * 2.5);
      tp3 = entry - (risk * 4.0);
      entryReason = 'Short entry at market';

    } else {
      // HOLD — show levels anyway
      entry = currentPrice;
      stopLoss = entry - (atr * 2);
      tp1 = entry + (atr * 1.5);
      tp2 = entry + (atr * 2.5);
      tp3 = entry + (atr * 4.0);
      entryReason = 'Wait for clearer signal before entering';
      stopReason = '2× ATR — wide stop for uncertain market';
    }

    const riskPct = (Math.abs(entry - stopLoss) / entry * 100).toFixed(1);
    const rr1 = (Math.abs(tp1 - entry) / Math.abs(entry - stopLoss)).toFixed(1);
    const rr2 = (Math.abs(tp2 - entry) / Math.abs(entry - stopLoss)).toFixed(1);
    const rr3 = (Math.abs(tp3 - entry) / Math.abs(entry - stopLoss)).toFixed(1);

    // Position size suggestion (risk £100 per trade example)
    const riskPerShare = Math.abs(entry - stopLoss);
    const sharesFor100Risk = Math.floor(100 / riskPerShare);
    const sharesFor250Risk = Math.floor(250 / riskPerShare);
    const sharesFor500Risk = Math.floor(500 / riskPerShare);

    tradeLevels = {
      entry: parseFloat(entry.toFixed(2)),
      stopLoss: parseFloat(stopLoss.toFixed(2)),
      stopReason,
      entryReason,
      tp1: parseFloat(tp1.toFixed(2)),
      tp2: parseFloat(tp2.toFixed(2)),
      tp3: parseFloat(tp3.toFixed(2)),
      rr1, rr2, rr3,
      atr: parseFloat(atr.toFixed(2)),
      atrPct,
      riskPct,
      support: parseFloat(support.toFixed(2)),
      resistance: parseFloat(resistance.toFixed(2)),
      positionSize: { risk100: sharesFor100Risk, risk250: sharesFor250Risk, risk500: sharesFor500Risk },
      ma20: parseFloat((ma20||0).toFixed(2)),
      ma50: parseFloat((ma50||0).toFixed(2)),
    };
  }

  return {
    signal, signalColor, score: Math.round(score), recommendation, reasons, warnings,
    tradeLevels,
    indicators: {
      rsi: rsi ? rsi.toFixed(1) : 'N/A',
      macd: macd ? (macd.MACD > macd.signal ? 'Bullish' : 'Bearish') : 'N/A',
      trend: currentPrice > (ma50||0) ? 'Uptrend' : 'Downtrend',
      ma20: ma20 ? ma20.toFixed(2) : 'N/A',
      ma50: ma50 ? ma50.toFixed(2) : 'N/A',
      ma200: ma200 ? ma200.toFixed(2) : 'N/A',
      bollingerBands: bb ? `$${bb.lower.toFixed(2)} — $${bb.upper.toFixed(2)}` : 'N/A',
      volumeRatio: volRatio ? `${volRatio.toFixed(1)}x avg` : 'N/A',
      sentiment: sentiment.label,
      momentum5d: `${priceChange5d.toFixed(1)}%`,
      momentum20d: `${priceChange20d.toFixed(1)}%`,
      yearPosition: `${yearPosition.toFixed(0)}% of 52wk range`,
    },
    quote
  };
}

const server = http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Content-Type', 'application/json');

  if (req.method === 'OPTIONS') { res.writeHead(200); res.end(); return; }

  const parsedUrl = new URL(req.url, "http://localhost");
  const ticker = parsedUrl.searchParams.get('ticker');

  if (parsedUrl.pathname === '/stock/search') {
    try {
      const q = parsedUrl.searchParams.get('q') || '';
      const url = `https://finnhub.io/api/v1/search?q=${encodeURIComponent(q)}&token=${FINNHUB_KEY}`;
      const data = await fetch(url).then(r => r.json());
      const results = (data.result || []).slice(0, 10).map(r => ({
        ticker: r.symbol, name: r.description, type: r.type
      }));
      res.writeHead(200); res.end(JSON.stringify({ results }));
    } catch(e) { res.writeHead(200); res.end(JSON.stringify({ results: [] })); }

  } else if (parsedUrl.pathname === '/stock' && ticker) {
    try {
      const data = await fetchStock(ticker);
      guardianLog('stock_search', ticker, { price: data.price });
      res.writeHead(200); res.end(JSON.stringify(data));
    } catch (err) { res.writeHead(500); res.end(JSON.stringify({ error: err.message })); }

  } else if (parsedUrl.pathname === '/news' && ticker) {
    try {
      const stockData = await fetchStock(ticker);
      const news = await fetchAllNews(ticker, stockData.name || ticker);
      res.writeHead(200); res.end(JSON.stringify(news));
    } catch (err) { res.writeHead(500); res.end(JSON.stringify({ error: err.message })); }

  } else if (parsedUrl.pathname === '/signal' && ticker) {
    try {
      const signal = await generateSignal(ticker);
      guardianLog('signal_run', ticker, { signal: signal.signal, score: signal.score });
      res.writeHead(200); res.end(JSON.stringify(signal));
    } catch (err) { res.writeHead(500); res.end(JSON.stringify({ error: err.message })); }

  } else if (parsedUrl.pathname === '/portfolio/add') {
    try {
      const body = await getBody(req);
      let ticker = body.ticker.toUpperCase();
      let stockName = ticker;

      // Try to fetch stock info — if it fails try with .L suffix for UK stocks
      try {
        const stock = await fetchStock(ticker);
        stockName = stock.name || ticker;
      } catch(e) {
        // Try adding .L for UK-listed stocks/ETFs
        try {
          const stock = await fetchStock(ticker + '.L');
          stockName = stock.name || ticker;
          ticker = ticker + '.L'; // update ticker to include .L
        } catch(e2) {
          // Still failed — just use ticker as name, save anyway
          stockName = ticker;
        }
      }

      db.prepare('INSERT INTO portfolio (ticker, name, shares, buyPrice, buyCurrency) VALUES (?, ?, ?, ?, ?)').run(ticker, stockName, body.shares, body.buyPrice, body.buyCurrency || 'USD');
      const positionValue = body.buyPrice * body.shares;
      guardianLog('portfolio_add', ticker, { shares: body.shares, buyPrice: body.buyPrice, positionValue });
      if (positionValue > 1000) {
        guardianIntervene('INFO', `💼 Large Position Added: ${ticker}`, `You've added £${positionValue.toFixed(0)} in ${ticker}. Make sure you have a stop loss defined and this aligns with your position sizing rules.`, 'large_position_' + ticker);
      }
      res.writeHead(200); res.end(JSON.stringify({ success: true }));
    } catch (err) { res.writeHead(500); res.end(JSON.stringify({ error: err.message })); }

  } else if (parsedUrl.pathname === '/portfolio/list') {
    try {
      const holdings = db.prepare('SELECT * FROM portfolio ORDER BY addedAt DESC').all();

      // Fetch live GBPUSD rate once for all conversions
      let gbpUsdRate = 1.27; // fallback
      try {
        const fxQuote = await fetchStock('GBPUSD=X');
        if (fxQuote && fxQuote.price) gbpUsdRate = fxQuote.price;
      } catch(e) {}

      const enriched = await Promise.all(holdings.map(async (h) => {
        try {
          const quote = await fetchStock(h.ticker);
          const stockCurrency = (quote.currency || 'USD').toUpperCase();

          // Determine currency of this stock
          // GBp / GBX = pence (LSE), divide by 100 to get GBP
          // USD = US stocks, convert via live rate
          // GBP = already in pounds
          const isLSE = h.ticker.endsWith('.L');

          // Detect pence-priced stocks: currency is GBp/GBX OR it's LSE AND price > 150
          // (LSE stocks priced in pence are typically 150p+; USD-denominated LSE ETFs are ~$10-100)
          const isGBp = stockCurrency === 'GBp' || stockCurrency === 'GBX'
            || (isLSE && stockCurrency !== 'USD' && quote.price > 150);

          // USD: explicit USD currency, OR LSE stock that Finnhub returns in USD (e.g. iShares USD-class ETFs)
          const isUSD = stockCurrency === 'USD' && !isGBp;

          // Convert current price to GBP
          let currentPriceGBP;
          if (isGBp) currentPriceGBP = quote.price / 100;            // pence → pounds
          else if (isUSD) currentPriceGBP = quote.price / gbpUsdRate; // USD → GBP
          else currentPriceGBP = quote.price;                         // already GBP

          // Convert buy price to GBP using the stored buyCurrency flag
          let buyPriceGBP;
          const bc = h.buyCurrency || 'USD';
          if (bc === 'GBP') {
            buyPriceGBP = h.buyPrice;               // already in GBP (Pie CSV imports)
          } else if (bc === 'GBp' || bc === 'GBX') {
            buyPriceGBP = h.buyPrice / 100;         // pence → pounds (manual .L entry)
          } else {
            buyPriceGBP = h.buyPrice / gbpUsdRate;  // USD → GBP (US stocks)
          }

          const currentValueGBP = currentPriceGBP * h.shares;
          const costBasisGBP = buyPriceGBP * h.shares;
          const pnlGBP = currentValueGBP - costBasisGBP;
          const pnlPercent = ((pnlGBP / costBasisGBP) * 100).toFixed(2);

          return {
            ...h,
            currentPrice: currentPriceGBP,        // GBP
            currentPriceNative: quote.price,       // original currency
            buyPriceGBP,                           // GBP equivalent of what was paid
            currentValue: currentValueGBP,         // GBP
            costBasis: costBasisGBP,               // GBP
            pnl: pnlGBP,                           // GBP
            pnlPercent,
            currency: 'GBP',
            nativeCurrency: stockCurrency,
            gbpUsdRate: gbpUsdRate.toFixed(4),
          };
        } catch(e) { return { ...h, currentPrice: null, pnl: null, currency: 'GBP' }; }
      }));
      res.writeHead(200); res.end(JSON.stringify(enriched));
    } catch (err) { res.writeHead(500); res.end(JSON.stringify({ error: err.message })); }

  } else if (parsedUrl.pathname === '/portfolio/delete') {
    try {
      const body = await getBody(req);
      db.prepare('DELETE FROM portfolio WHERE id = ?').run(body.id);
      res.writeHead(200); res.end(JSON.stringify({ success: true }));
    } catch (err) { res.writeHead(500); res.end(JSON.stringify({ error: err.message })); }

  } else if (parsedUrl.pathname === '/portfolio/dividends') {
    try {
      const holdings = db.prepare('SELECT * FROM portfolio').all();

      // Known dividend data — hardcoded for speed, no API call needed
      // All values in GBP (not pence). UK stock divs converted: RKT.L pays ~174.6p = £1.746/share
      const KNOWN_DIVS = {
        // US stocks — USD per share (accurate as of 2025)
        MSFT: {divPerShare:3.00, divYield:0.72, freq:'Quarterly'},
        AAPL: {divPerShare:1.00, divYield:0.46, freq:'Quarterly'},
        JNJ:  {divPerShare:4.96, divYield:3.10, freq:'Quarterly'},
        PEP:  {divPerShare:5.42, divYield:3.20, freq:'Quarterly'},
        PG:   {divPerShare:3.76, divYield:2.40, freq:'Quarterly'},
        KO:   {divPerShare:1.94, divYield:3.10, freq:'Quarterly'},
        TXN:  {divPerShare:5.20, divYield:2.80, freq:'Quarterly'},
        ABBV: {divPerShare:6.20, divYield:3.50, freq:'Quarterly'},
        CVX:  {divPerShare:6.52, divYield:4.40, freq:'Quarterly'},
        COST: {divPerShare:4.64, divYield:0.60, freq:'Quarterly'},
        V:    {divPerShare:2.08, divYield:0.80, freq:'Quarterly'},
        CSCO: {divPerShare:1.60, divYield:3.10, freq:'Quarterly'},
        ORCL: {divPerShare:1.60, divYield:1.20, freq:'Quarterly'},
        ABT:  {divPerShare:2.20, divYield:2.00, freq:'Quarterly'},
        LLY:  {divPerShare:5.20, divYield:0.65, freq:'Quarterly'},
        AVGO: {divPerShare:21.00,divYield:1.40, freq:'Quarterly'},
        ASML: {divPerShare:6.40, divYield:0.90, freq:'Quarterly'},
        AZN:  {divPerShare:2.97, divYield:2.10, freq:'Semi-annual'},
        // UK stocks — divPerShare in GBP (already converted from pence)
        'AZN.L':  {divPerShare:2.97,  divYield:2.10, freq:'Semi-annual', pence:false},
        'ULVR.L': {divPerShare:1.75,  divYield:3.60, freq:'Semi-annual', pence:false},
        'RKT.L':  {divPerShare:1.746, divYield:3.40, freq:'Semi-annual', pence:false}, // 174.6p = £1.746
        'BNZL.L': {divPerShare:0.62,  divYield:2.20, freq:'Semi-annual', pence:false}, // 62p = £0.62
        'MTO.L':  {divPerShare:0.048, divYield:4.10, freq:'Semi-annual', pence:false}, // ~4.8p = £0.048
        // LSE ETF distributions — GBP per share
        'ISUS.L': {divPerShare:0.75, divYield:1.20, freq:'Quarterly'},
        'ISWD.L': {divPerShare:0.47, divYield:1.10, freq:'Quarterly'},
        'ISDE.L': {divPerShare:0.27, divYield:1.30, freq:'Quarterly'},
        'IGDA.L': {divPerShare:0.20, divYield:0.80, freq:'Quarterly'},
        'HINS.L': {divPerShare:0.23, divYield:2.10, freq:'Quarterly'},
      };

      const data = holdings.map(h => {
        const known = KNOWN_DIVS[h.ticker] || KNOWN_DIVS[h.ticker.replace('.L','')] || null;
        // All values already in GBP — no pence conversion needed
        const divPerShare = known?.divPerShare || 0;
        const annualIncome = divPerShare * h.shares;
        return {
          id: h.id, ticker: h.ticker, name: h.name || h.ticker,
          shares: h.shares, buyCurrency: h.buyCurrency || 'USD',
          divPerShare, divYield: known?.divYield || 0,
          freq: known?.freq || '', annualIncome,
          hasDividend: divPerShare > 0,
          source: known ? 'estimated' : 'none',
        };
      });

      res.writeHead(200); res.end(JSON.stringify(data));
    } catch(err) { res.writeHead(500); res.end(JSON.stringify({ error: err.message })); }

  } else if (parsedUrl.pathname === '/portfolio/divlive') {
    // Background live fetch for a single ticker from Finnhub
    try {
      const ticker = parsedUrl.searchParams.get('ticker') || '';
      if (!ticker) { res.writeHead(400); res.end(JSON.stringify({ error: 'No ticker' })); return; }
      const url = `https://finnhub.io/api/v1/stock/metric?symbol=${ticker}&metric=all&token=${FINNHUB_KEY}`;
      const data = await fetch(url).then(r => r.json());
      const metric = data.metric || {};
      const divPerShare = metric['dividendPerShareAnnual'] || 0;
      const divYield = metric['currentDividendYieldTTM'] || 0;
      res.writeHead(200); res.end(JSON.stringify({ ticker, divPerShare, divYield, source: 'finnhub' }));
    } catch(err) { res.writeHead(500); res.end(JSON.stringify({ error: err.message })); }

  } else if (parsedUrl.pathname === '/portfolio/deleteall') {
    try {
      db.prepare('DELETE FROM portfolio').run();
      res.writeHead(200); res.end(JSON.stringify({ success: true }));
    } catch (err) { res.writeHead(500); res.end(JSON.stringify({ error: err.message })); }

  } else if (parsedUrl.pathname === '/portfolio/edit') {
    try {
      const body = await getBody(req);
      let ticker = body.ticker.toUpperCase();
      let stockName = ticker;
      try {
        const stock = await fetchStock(ticker);
        stockName = stock.name || ticker;
      } catch(e) {
        try {
          const stock = await fetchStock(ticker + '.L');
          stockName = stock.name || ticker;
          if (!ticker.endsWith('.L')) ticker = ticker + '.L';
        } catch(e2) { stockName = ticker; }
      }
      db.prepare('UPDATE portfolio SET ticker=?, name=?, shares=?, buyPrice=?, buyCurrency=?, sector=?, groupLabel=? WHERE id=?')
        .run(ticker, stockName, body.shares, body.buyPrice, body.buyCurrency || 'USD', body.sector || 'General', body.groupLabel || '', body.id);
      res.writeHead(200); res.end(JSON.stringify({ success: true }));
    } catch (err) { res.writeHead(500); res.end(JSON.stringify({ error: err.message })); }

  } else if (parsedUrl.pathname === '/portfolio/buymore') {
    try {
      const body = await getBody(req);
      const existing = db.prepare('SELECT * FROM portfolio WHERE id = ?').get(body.id);
      if (!existing) { res.writeHead(404); res.end(JSON.stringify({ error: 'Not found' })); return; }
      // Calculate new weighted average buy price
      const newShares = parseFloat(body.shares);
      const newPrice = parseFloat(body.buyPrice);
      const totalShares = existing.shares + newShares;
      // Convert both to same currency for avg calculation (use stored buyCurrency)
      const bc = body.buyCurrency || existing.buyCurrency || 'USD';
      // Weighted average — both in native currency
      const avgPrice = ((existing.buyPrice * existing.shares) + (newPrice * newShares)) / totalShares;
      db.prepare('UPDATE portfolio SET shares=?, buyPrice=?, buyCurrency=? WHERE id=?')
        .run(totalShares, avgPrice, bc, body.id);
      res.writeHead(200); res.end(JSON.stringify({ success: true, newShares: totalShares, newAvg: avgPrice }));
    } catch (err) { res.writeHead(500); res.end(JSON.stringify({ error: err.message })); }

  } else if (parsedUrl.pathname === '/portfolio/sell') {
    try {
      const body = await getBody(req);
      const existing = db.prepare('SELECT * FROM portfolio WHERE id = ?').get(body.id);
      if (!existing) { res.writeHead(404); res.end(JSON.stringify({ error: 'Not found' })); return; }
      const sellShares = parseFloat(body.shares);
      const remainingShares = existing.shares - sellShares;
      if (remainingShares < 0) { res.writeHead(400); res.end(JSON.stringify({ error: 'Cannot sell more than you own' })); return; }
      if (remainingShares < 0.0001) {
        // Fully sold — delete the holding
        db.prepare('DELETE FROM portfolio WHERE id = ?').run(body.id);
        res.writeHead(200); res.end(JSON.stringify({ success: true, fullyExited: true }));
      } else {
        // Partial sell — reduce shares, keep avg buy price
        db.prepare('UPDATE portfolio SET shares=? WHERE id=?').run(remainingShares, body.id);
        res.writeHead(200); res.end(JSON.stringify({ success: true, fullyExited: false, remainingShares }));
      }
    } catch (err) { res.writeHead(500); res.end(JSON.stringify({ error: err.message })); }

  } else if (parsedUrl.pathname === '/expenses/add') {
    try {
      const body = await getBody(req);
      db.prepare('INSERT INTO expenses (type, category, description, amount, date) VALUES (?, ?, ?, ?, ?)').run(body.type, body.category, body.description, body.amount, body.date);
      res.writeHead(200); res.end(JSON.stringify({ success: true }));
    } catch (err) { res.writeHead(500); res.end(JSON.stringify({ error: err.message })); }

  } else if (parsedUrl.pathname === '/expenses/list') {
    try {
      const expenses = db.prepare('SELECT * FROM expenses ORDER BY date DESC').all();
      res.writeHead(200); res.end(JSON.stringify(expenses));
    } catch (err) { res.writeHead(500); res.end(JSON.stringify({ error: err.message })); }

  } else if (parsedUrl.pathname === '/expenses/delete') {
    try {
      const body = await getBody(req);
      db.prepare('DELETE FROM expenses WHERE id = ?').run(body.id);
      res.writeHead(200); res.end(JSON.stringify({ success: true }));
    } catch (err) { res.writeHead(500); res.end(JSON.stringify({ error: err.message })); }

  } else if (parsedUrl.pathname === '/assets/add') {
    try {
      const body = await getBody(req);
      db.prepare('INSERT INTO assets (category, name, value, currency, notes) VALUES (?, ?, ?, ?, ?)').run(body.category, body.name, body.value, body.currency, body.notes || '');
      res.writeHead(200); res.end(JSON.stringify({ success: true }));
    } catch (err) { res.writeHead(500); res.end(JSON.stringify({ error: err.message })); }

  } else if (parsedUrl.pathname === '/assets/list') {
    try {
      const assets = db.prepare('SELECT * FROM assets ORDER BY addedAt DESC').all();
      res.writeHead(200); res.end(JSON.stringify(assets));
    } catch (err) { res.writeHead(500); res.end(JSON.stringify({ error: err.message })); }

  } else if (parsedUrl.pathname === '/assets/delete') {
    try {
      const body = await getBody(req);
      db.prepare('DELETE FROM assets WHERE id = ?').run(body.id);
      res.writeHead(200); res.end(JSON.stringify({ success: true }));
    } catch (err) { res.writeHead(500); res.end(JSON.stringify({ error: err.message })); }

  } else if (parsedUrl.pathname === '/advisor') {
    try {
      const body = await getBody(req);
      const holdings = db.prepare('SELECT * FROM portfolio ORDER BY addedAt DESC').all();
      const expenses = db.prepare('SELECT * FROM expenses ORDER BY date DESC LIMIT 50').all();
      const assets = db.prepare('SELECT * FROM assets ORDER BY addedAt DESC').all();

      const enriched = await Promise.all(holdings.map(async (h) => {
        try {
          const quote = await fetchStock(h.ticker);
          const currentValue = quote.price * h.shares;
          const costBasis = h.buyPrice * h.shares;
          const pnl = currentValue - costBasis;
          const pnlPercent = ((pnl / costBasis) * 100).toFixed(2);
          return { ...h, currentPrice: quote.price, currentValue, costBasis, pnl, pnlPercent };
        } catch(e) { return h; }
      }));

      const totalValue = enriched.reduce((a, h) => a + (h.currentValue || 0), 0);
      const totalCost = enriched.reduce((a, h) => a + (h.costBasis || 0), 0);
      const totalPnl = totalValue - totalCost;
      const totalIncome = expenses.filter(e => e.type === 'income').reduce((a, e) => a + e.amount, 0);
      const totalExpenses = expenses.filter(e => e.type === 'expense').reduce((a, e) => a + e.amount, 0);
      const savingsRate = totalIncome > 0 ? (((totalIncome - totalExpenses) / totalIncome) * 100).toFixed(1) : 0;

      const portfolioSummary = enriched.map(h =>
        `${h.ticker}: ${h.shares} shares, bought at £${h.buyPrice}, now £${h.currentPrice ? h.currentPrice.toFixed(2) : 'unknown'}, P&L: ${h.pnl ? '£' + h.pnl.toFixed(2) + ' (' + h.pnlPercent + '%)' : 'unknown'}`
      ).join('\n');

      const assetsSummary = assets.map(a => `${a.name} (${a.category}): ${a.currency} ${a.value}`).join('\n');
      const expenseSummary = `Income: £${totalIncome.toFixed(2)}, Expenses: £${totalExpenses.toFixed(2)}, Savings rate: ${savingsRate}%`;

      const systemPrompt = `You are a professional wealth advisor for a UK-based 24-year-old Pakistani investor named Qureshi. His goals:
1. Retire by age 40 (16 years away)
2. Build a wedding hall/marquee on land in Pakistan
3. Build a mall on 7 marla land in Pakistan
4. Buy a UK house for rental income
5. Invest in halal stocks and ETFs only
6. Build a gold/silver portfolio for passive income
7. Buy more rental shops in Pakistan
8. Eventually move back to Pakistan

Be specific, actionable and personalised. Always consider:
- Halal investing principles (no interest/riba, no haram industries)
- UK ISA allowances and CGT
- PKR/GBP exchange rates
- Pakistan real estate market
- His dual UK/Pakistan wealth strategy
Format responses with clear sections and emojis. Be direct and ambitious.`;

      const userMessage = `PORTFOLIO:\n${portfolioSummary || 'Empty'}\n\nTotal: £${totalValue.toFixed(2)}, Cost: £${totalCost.toFixed(2)}, P&L: £${totalPnl.toFixed(2)}\n\nASSETS:\n${assetsSummary || 'None added yet'}\n\nFINANCES: ${expenseSummary}\n\nQUESTION: ${body.question}`;

      const message = await anthropic.messages.create({
        model: 'claude-opus-4-6',
        max_tokens: 1500,
        system: systemPrompt,
        messages: [{ role: 'user', content: userMessage }]
      });

      res.writeHead(200); res.end(JSON.stringify({ response: message.content[0].text }));
    } catch (err) {
      console.log('Advisor error:', err.message);
      res.writeHead(500); res.end(JSON.stringify({ error: err.message }));
    }

  // ─── LIVE PRICE ───
  } else if (parsedUrl.pathname === '/liveprice') {
    const t = parsedUrl.searchParams.get('ticker');
    if (!t) { res.writeHead(400); res.end(JSON.stringify({ error: 'ticker required' })); return; }

    finnhubSubscribe(t);

    // 1. Finnhub WebSocket tick (true real-time during market hours)
    const fPrice = getFinnhubPrice(t);
    if (fPrice) {
      res.writeHead(200); res.end(JSON.stringify({
        source: 'FINNHUB_LIVE', ticker: t,
        price: fPrice.price, volume: fPrice.volume, ts: fPrice.ts
      }));
      return;
    }

    // 2. Finnhub REST quote (current price, works pre/post market, no rate limit issues)
    try {
      const q = await fetchLiveQuote(t);
      res.writeHead(200); res.end(JSON.stringify(q));
    } catch(e) {
      res.writeHead(500); res.end(JSON.stringify({ error: e.message }));
    }

  // ─── FINNHUB STATUS ───
  } else if (parsedUrl.pathname === '/finnhub/status') {
    res.writeHead(200); res.end(JSON.stringify({
      connected: finnhubReady,
      subscribed: [...finnhubSubscribed],
      priceCount: Object.keys(finnhubPrices).length
    }));

  // ─── ORDER BOOK (coming soon — needs market data subscription) ───
  } else if (parsedUrl.pathname === '/orderbook') {
    res.writeHead(200); res.end(JSON.stringify({ 
      connected: false, bids: [], asks: [],
      error: 'Order book coming soon'
    }));

  // ─── FINNHUB STATUS ───
  } else if (parsedUrl.pathname === '/ibkr/status') {
    res.writeHead(200); res.end(JSON.stringify({ 
      connected: finnhubReady,
      subscribed: [...finnhubSubscribed],
      prices: Object.keys(finnhubPrices).length
    }));

  // ─── FINNHUB STATUS ───
  } else if (parsedUrl.pathname === '/ibkr/status') {
    res.writeHead(200); res.end(JSON.stringify({ 
      connected: finnhubReady,
      subscribed: [...finnhubSubscribed],
      prices: Object.keys(finnhubPrices).length
    }));

  // ─── VOLUME SPIKE SCANNER ───
  } else if (parsedUrl.pathname === '/scanner/volume') {
    try {
      const watchlist = (parsedUrl.searchParams.get('tickers') || 'AAPL,TSLA,NVDA,MSFT,AMZN,META,AMD,GOOGL,NFLX,PLTR,SOFI,RIVN,NIO,LCID,GME,AMC,MARA,RIOT,COIN,SPY').split(',').slice(0, 20);
      const results = await Promise.allSettled(watchlist.map(async (t) => {
        const hist = await fetchHistorical(t);
        const volumes = hist.volumes.filter(v => v !== null);
        const closes = hist.closes.filter(c => c !== null);
        if (volumes.length < 20) return null;
        const avgVol20 = volumes.slice(-21, -1).reduce((a, b) => a + b, 0) / 20;
        const todayVol = volumes[volumes.length - 1];
        const volRatio = todayVol / avgVol20;
        const priceChange = ((closes[closes.length - 1] - closes[closes.length - 2]) / closes[closes.length - 2]) * 100;
        const price5dAgo = closes[closes.length - 6];
        const momentum5d = ((closes[closes.length - 1] - price5dAgo) / price5dAgo) * 100;
        // ATR for volatility
        const highs = hist.highs || [];
        const lows = hist.lows || [];
        let atr = 0;
        if (highs.length >= 14) {
          const trs = [];
          for (let i = Math.max(1, closes.length - 14); i < closes.length; i++) {
            trs.push(Math.max(highs[i] - lows[i], Math.abs(highs[i] - closes[i-1]), Math.abs(lows[i] - closes[i-1])));
          }
          atr = trs.reduce((a,b) => a+b, 0) / trs.length;
        }
        // Spike score
        let spikeScore = 0;
        let signals = [];
        if (volRatio >= 3) { spikeScore += 40; signals.push(`🔥 Volume ${volRatio.toFixed(1)}x avg`); }
        else if (volRatio >= 2) { spikeScore += 25; signals.push(`⚡ Volume ${volRatio.toFixed(1)}x avg`); }
        else if (volRatio >= 1.5) { spikeScore += 10; signals.push(`📈 Volume ${volRatio.toFixed(1)}x avg`); }
        if (Math.abs(priceChange) > 3) { spikeScore += 20; signals.push(`${priceChange > 0 ? '▲' : '▼'} ${Math.abs(priceChange).toFixed(1)}% today`); }
        if (Math.abs(priceChange) > 1.5) { spikeScore += 10; }
        if (momentum5d > 5) { spikeScore += 15; signals.push(`Strong 5d momentum +${momentum5d.toFixed(1)}%`); }
        else if (momentum5d < -5) { spikeScore += 10; signals.push(`Bearish 5d momentum ${momentum5d.toFixed(1)}%`); }
        const alert = volRatio >= 2 ? (priceChange > 0 ? 'BULLISH SPIKE' : 'BEARISH SPIKE') : volRatio >= 1.5 ? 'ELEVATED' : 'NORMAL';
        return {
          ticker: t, price: closes[closes.length - 1], volRatio: parseFloat(volRatio.toFixed(2)),
          todayVol: Math.round(todayVol), avgVol: Math.round(avgVol20),
          priceChange: parseFloat(priceChange.toFixed(2)), momentum5d: parseFloat(momentum5d.toFixed(2)),
          atr: parseFloat(atr.toFixed(2)), spikeScore, signals, alert
        };
      }));
      const scanned = results.filter(r => r.status === 'fulfilled' && r.value).map(r => r.value);
      scanned.sort((a, b) => b.spikeScore - a.spikeScore);
      res.writeHead(200); res.end(JSON.stringify({ scanned, ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── AI CHART ANALYSIS ───
  } else if (parsedUrl.pathname === '/chart/analyse') {
    const t = parsedUrl.searchParams.get('ticker');
    if (!t) { res.writeHead(400); res.end(JSON.stringify({ error: 'ticker required' })); return; }
    try {
      const [hist, quote] = await Promise.all([fetchHistorical(t), fetchStock(t)]);
      const closes = hist.closes.filter(c => c !== null);
      const highs = hist.highs?.filter(h => h !== null) || [];
      const lows = hist.lows?.filter(l => l !== null) || [];
      const volumes = hist.volumes.filter(v => v !== null);
      const price = quote.price;

      // Calculate all indicators for Claude to analyse
      const sma20 = ti.SMA.calculate({ values: closes, period: 20 });
      const sma50 = ti.SMA.calculate({ values: closes, period: 50 });
      const sma200 = ti.SMA.calculate({ values: closes, period: 200 });
      const rsiVals = ti.RSI.calculate({ values: closes, period: 14 });
      const macdVals = ti.MACD.calculate({ values: closes, fastPeriod: 12, slowPeriod: 26, signalPeriod: 9, SimpleMAOscillator: false, SimpleMASignal: false });
      const bbVals = ti.BollingerBands.calculate({ values: closes, period: 20, stdDev: 2 });
      const ma20 = sma20[sma20.length - 1];
      const ma50 = sma50[sma50.length - 1];
      const ma200 = sma200[sma200.length - 1];
      const rsi = rsiVals[rsiVals.length - 1];
      const macd = macdVals[macdVals.length - 1];
      const bb = bbVals[bbVals.length - 1];
      const avgVol = volumes.slice(-20).reduce((a,b)=>a+b,0)/20;
      const todayVol = volumes[volumes.length-1];

      // Find support/resistance from recent highs/lows
      const recent20Highs = highs.slice(-20);
      const recent20Lows = lows.slice(-20);
      const resistance = recent20Highs.length ? Math.max(...recent20Highs) : null;
      const support = recent20Lows.length ? Math.min(...recent20Lows) : null;

      // Recent price action (last 5 closes)
      const recentCloses = closes.slice(-5).map(c => c.toFixed(2));
      const priceChange1d = ((closes[closes.length-1] - closes[closes.length-2]) / closes[closes.length-2] * 100).toFixed(2);
      const priceChange5d = ((closes[closes.length-1] - closes[closes.length-6]) / closes[closes.length-6] * 100).toFixed(2);

      // Send to Claude for analysis
      const claudeRes = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        messages: [{
          role: 'user',
          content: `You are a professional technical analyst. Analyse this stock chart data for

IMPORTANT: Write everything in simple plain English. Imagine you are explaining to a smart 18 year old who is just learning to trade and has never worked in finance. No jargon, no complex terms. If you must use a technical word, explain it in brackets immediately after.

 ${t} and give a detailed breakdown.

CURRENT PRICE: $${price}
1D CHANGE: ${priceChange1d}%
5D CHANGE: ${priceChange5d}%

MOVING AVERAGES:
- Price vs MA20: ${price > ma20 ? 'ABOVE' : 'BELOW'} ($${ma20?.toFixed(2)})
- Price vs MA50: ${price > ma50 ? 'ABOVE' : 'BELOW'} ($${ma50?.toFixed(2)})
- Price vs MA200: ${ma200 ? (price > ma200 ? 'ABOVE' : 'BELOW') + ' ($' + ma200.toFixed(2) + ')' : 'N/A'}
- MA50 vs MA200: ${ma50 && ma200 ? (ma50 > ma200 ? 'GOLDEN CROSS (bullish)' : 'DEATH CROSS (bearish)') : 'N/A'}

MOMENTUM:
- RSI(14): ${rsi?.toFixed(1)} — ${rsi < 30 ? 'OVERSOLD' : rsi > 70 ? 'OVERBOUGHT' : 'NEUTRAL'}
- MACD: ${macd?.MACD?.toFixed(3)} | Signal: ${macd?.signal?.toFixed(3)} | ${macd?.MACD > macd?.signal ? 'BULLISH' : 'BEARISH'}
- Bollinger Bands: Lower $${bb?.lower?.toFixed(2)} | Middle $${bb?.middle?.toFixed(2)} | Upper $${bb?.upper?.toFixed(2)}
- Price in BB: ${bb ? (((price - bb.lower)/(bb.upper - bb.lower))*100).toFixed(0) + '%' : 'N/A'}

VOLUME:
- Today vs 20d avg: ${(todayVol/avgVol).toFixed(1)}x
- Today: ${Math.round(todayVol/1000000).toFixed(1)}M | Avg: ${Math.round(avgVol/1000000).toFixed(1)}M

KEY LEVELS:
- 20d Resistance: $${resistance?.toFixed(2)}
- 20d Support: $${support?.toFixed(2)}
- Distance to support: ${support ? ((price - support)/price*100).toFixed(1) + '%' : 'N/A'}
- Distance to resistance: ${resistance ? ((resistance - price)/price*100).toFixed(1) + '%' : 'N/A'}

RECENT CLOSES (last 5 days): ${recentCloses.join(' → ')}

Respond in JSON only with this exact structure:
{
  "trend": "UPTREND|DOWNTREND|SIDEWAYS",
  "strength": "STRONG|MODERATE|WEAK",
  "pattern": "name of chart pattern detected or null",
  "patternDesc": "brief description of the pattern",
  "support": [list of key support levels as numbers],
  "resistance": [list of key resistance levels as numbers],
  "keyInsight": "single most important thing about this chart right now",
  "nextMove": "what is likely to happen next based on the technicals",
  "riskLevel": "LOW|MEDIUM|HIGH",
  "tradeBias": "BUY|SELL|NEUTRAL",
  "summary": "2-3 sentence professional chart summary"
}`
        }]
      });

      const raw = claudeRes.content[0].text.replace(/```json|```/g, '').trim();
      const analysis = JSON.parse(raw);
      res.writeHead(200); res.end(JSON.stringify({
        ticker: t, price, analysis,
        indicators: { rsi: rsi?.toFixed(1), macd: macd?.MACD?.toFixed(3), ma20: ma20?.toFixed(2), ma50: ma50?.toFixed(2), ma200: ma200?.toFixed(2), bb: bb ? { lower: bb.lower?.toFixed(2), upper: bb.upper?.toFixed(2) } : null, support: support?.toFixed(2), resistance: resistance?.toFixed(2), volRatio: (todayVol/avgVol).toFixed(1) },
        ts: Date.now()
      }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── AI RESEARCH LAB ───
  } else if (parsedUrl.pathname === '/research' && req.method === 'POST') {
    try {
      const body = await getBody(req);
      const { mode, ticker, tickerB, extra } = body;

      // Fetch market data to ground the AI in real numbers
      let marketData = '';
      if (ticker) {
        try {
          const [quote, hist] = await Promise.all([fetchStock(ticker), fetchHistorical(ticker)]);
          const closes = hist.closes.filter(c => c !== null);
          const sma20 = ti.SMA.calculate({ values: closes, period: 20 });
          const sma50 = ti.SMA.calculate({ values: closes, period: 50 });
          const sma200 = ti.SMA.calculate({ values: closes, period: 200 });
          const rsiVals = ti.RSI.calculate({ values: closes, period: 14 });
          const change1d = ((closes[closes.length-1] - closes[closes.length-2]) / closes[closes.length-2] * 100).toFixed(2);
          const change1m = ((closes[closes.length-1] - closes[closes.length-22]) / closes[closes.length-22] * 100).toFixed(2);
          const change3m = ((closes[closes.length-1] - closes[closes.length-66]) / closes[closes.length-66] * 100).toFixed(2);
          marketData = `
LIVE MARKET DATA FOR ${ticker}:
- Current Price: $${quote.price}
- 1D Change: ${change1d}%
- 1M Change: ${change1m}%
- 3M Change: ${change3m}%
- 52W High: $${quote.yearHigh} | 52W Low: $${quote.yearLow}
- 52W Position: ${(((quote.price - quote.yearLow) / (quote.yearHigh - quote.yearLow)) * 100).toFixed(0)}%
- RSI(14): ${rsiVals[rsiVals.length-1]?.toFixed(1)}
- vs MA20: ${quote.price > sma20[sma20.length-1] ? 'ABOVE' : 'BELOW'} ($${sma20[sma20.length-1]?.toFixed(2)})
- vs MA50: ${quote.price > sma50[sma50.length-1] ? 'ABOVE' : 'BELOW'} ($${sma50[sma50.length-1]?.toFixed(2)})
- vs MA200: ${sma200.length ? (quote.price > sma200[sma200.length-1] ? 'ABOVE' : 'BELOW') + ' ($' + sma200[sma200.length-1]?.toFixed(2) + ')' : 'N/A'}
- Volume vs Avg: ${(hist.volumes[hist.volumes.length-1] / (hist.volumes.slice(-21,-1).reduce((a,b)=>a+b,0)/20)).toFixed(1)}x`;
        } catch(e) { marketData = `Market data unavailable for ${ticker}`; }
      }

      // Build the prompt based on mode
      const prompts = {
        goldman: `Act as a senior equity research analyst at Goldman Sachs. Perform a comprehensive institutional analysis of ${ticker}.

${marketData}
${extra ? `\nADDITIONAL CONTEXT: ${extra}` : ''}

Cover:
1. REVENUE TRENDS — growth trajectory, acceleration/deceleration, quality of revenue
2. MARGIN TRAJECTORY — gross, operating, net margin trends and direction
3. CASH FLOW QUALITY — FCF generation, capex requirements, cash conversion
4. DEBT STRUCTURE — leverage ratios, maturity profile, interest coverage
5. COMPETITIVE POSITIONING — moat strength, market share, pricing power
6. VALUATION — P/E, P/S, EV/EBITDA vs peers and historical averages
7. CATALYSTS — near-term positive and negative catalysts
8. RATING + PRICE TARGET — Buy/Hold/Sell with 12-month price target and reasoning

Format as a professional research report with clear sections. Be decisive and specific with numbers.`,

        earnings: `Act as a senior equity analyst breaking down an earnings report in plain English.

${marketData}
${extra ? `\nEARNINGS DATA / NOTES: ${extra}` : `Analyse the most recent earnings context for ${ticker} based on the market data above.`}

Cover:
1. BEATS vs MISSES — EPS, revenue, key metrics vs estimates
2. FORWARD GUIDANCE — what management is signalling about next quarter/year
3. MANAGEMENT TONE — confident, cautious, defensive? Any language shifts?
4. INVESTMENT THESIS — does this strengthen or weaken the bull case?
5. IMMEDIATE REACTION — what this means for the stock in next 1-4 weeks
6. VERDICT — one clear sentence on what to do now

Plain English, no jargon. Be direct.`,

        screener: `Act as a quantitative portfolio manager building a custom stock screener.

Asset type requested: ${extra || 'growth stocks in technology sector'}
${marketData ? `Reference stock: ${ticker}\n${marketData}` : ''}

Build a complete screening system with:
1. EXACT FINANCIAL RATIOS — specific numbers and thresholds for each metric
2. GROWTH CRITERIA — revenue growth, EPS growth, earnings acceleration
3. QUALITY FILTERS — balance sheet health, cash flow, margins
4. MOMENTUM FILTERS — price and earnings momentum signals
5. VALUATION LIMITS — max P/E, P/S, PEG ratios
6. RANKING SYSTEM — how to score and rank candidates 1-10
7. WEEKLY CHECKLIST — step-by-step process to run every week
8. RED FLAGS — automatic disqualifiers

Format as an actionable checklist. Include specific numbers for every threshold.`,

        risk: `Act as a JPMorgan risk analyst. Run a full risk assessment on ${ticker}.

${marketData}

Cover:
1. SECTOR HEADWINDS — macro and industry-level risks
2. COMPETITIVE THREATS — who could take market share and how
3. BALANCE SHEET RED FLAGS — debt, liquidity, working capital concerns
4. REGULATORY EXPOSURE — legal, regulatory, political risks
5. MANAGEMENT CONCERNS — execution risk, track record, incentives
6. BEAR CASE MODEL — realistic worst-case price scenario with step-by-step reasoning
7. RISK SCORE — overall risk rating 1-10 with breakdown
8. RISK-ADJUSTED VERDICT — given these risks, is the reward worth it?

Be forensic. Surface things most retail investors miss.`,

        versus: `Act as a senior investment analyst doing a head-to-head comparison.

Stock A: ${ticker}
${marketData}
Stock B: ${tickerB || 'SPY'}
${extra ? `Investor profile: ${extra}` : 'Growth investor with 12-month horizon'}

Score each stock 1-10 on:
1. VALUATION — which is cheaper on risk-adjusted basis
2. GROWTH RUNWAY — revenue and earnings growth potential
3. FINANCIAL HEALTH — balance sheet, cash flow, debt
4. MOAT DURABILITY — competitive advantage sustainability
5. MANAGEMENT QUALITY — track record, capital allocation, incentives
6. MOMENTUM — price and earnings momentum
7. RISK PROFILE — downside risk and volatility

Show a scorecard table. Declare a clear winner with conviction and reasoning.`,

        portfolio: `Act as a Goldman Sachs portfolio strategist.

${extra ? `Client profile: ${extra}` : 'Moderate investor, £10,000 to deploy, 12-month horizon, 8-10 stocks'}
${ticker ? `Seed holding / reference: ${ticker}\n${marketData}` : ''}

Build a complete portfolio with:
1. ALLOCATION TABLE — exact % for each position with reasoning
2. STOCK THESIS — one powerful sentence per pick
3. ENTRY LOGIC — buy now vs scale in vs wait for pullback
4. SECTOR BALANCE — diversification across sectors
5. RISK MANAGEMENT — stop losses, position sizing, correlation
6. EXPECTED RETURN — realistic 12-month target return
7. MONTHLY REVIEW TRIGGERS — what would make you sell each position

Be specific. Real tickers. Real numbers.`,

        insider: `Act as a market intelligence analyst specialising in insider trading signals.

${ticker} Insider Activity Analysis:
${marketData}

Analyse and explain:
1. RECENT TRANSACTIONS — typical patterns for this type of company and stock price level
2. BULLISH SIGNALS — what insider buying patterns look like and what they mean
3. BEARISH SIGNALS — what insider selling patterns suggest
4. CONTEXT — how to distinguish routine selling from meaningful signals
5. HISTORICAL PATTERNS — how insider activity has preceded price moves in similar stocks
6. CURRENT SIGNAL — based on price action and momentum, what insider sentiment likely looks like
7. ACTION — what an investor should do with this information

Note: Use SEC Form 4 filings context. Be specific about what different transaction types signal.`,

        dividend: `Act as a dividend investment specialist evaluating ${ticker} for an income portfolio.

${marketData}

Analyse:
1. PAYOUT RATIO — current ratio, sustainability threshold, trend
2. DIVIDEND GROWTH HISTORY — CAGR, consistency, years of growth
3. FCF COVERAGE — free cash flow vs dividend payments
4. YIELD ANALYSIS — current yield vs sector average and historical range
5. CUT PROBABILITY — likelihood of dividend cut in next 12-24 months (score 1-10)
6. BALANCE SHEET SUPPORT — can debt levels sustain the dividend?
7. GROWTH OUTLOOK — will the dividend grow, stay flat, or shrink?
8. INCOME VERDICT — Core Hold / Accumulate / Avoid for income portfolios

Include specific numbers. Income investors need certainty, not hope.`,

        macro: `Act as a macro strategist at Bridgewater Associates.

Current market context: ${extra || 'March 2026, post-rate-hike cycle, inflation cooling, potential recession risk, AI infrastructure boom'}
${ticker ? `Portfolio context / reference sector: ${ticker}` : ''}

Provide:
1. ECONOMIC CYCLE POSITIONING — where are we and what comes next
2. INTEREST RATE IMPACT — how rate trajectory affects different sectors
3. INFLATION REGIME — what the current inflation environment means for assets
4. OVERWEIGHT SECTORS (3) — specific sectors to overweight with reasoning
5. UNDERWEIGHT SECTORS (3) — specific sectors to reduce with reasoning
6. ETF PICKS — 2-3 specific ETFs for each overweight sector
7. STOCK PICKS — 1-2 individual stocks per overweight sector
8. 6-12 MONTH OUTLOOK — what the macro picture looks like and key risks

Think like Ray Dalio. Connect macro to specific actionable trades.`,

        valuation: `Act as a value investor and technical analyst combined.

${ticker} Valuation & Entry Analysis:
${marketData}

Answer decisively:
1. CURRENT VALUATION — P/E, P/S vs 5-year averages and sector peers. Cheap or expensive?
2. TECHNICAL SETUP — RSI, moving averages, trend direction, key levels
3. SUPPORT LEVELS — exact price levels where buyers historically step in
4. RESISTANCE LEVELS — exact price levels where selling pressure appears
5. ENTRY DECISION — one of three options:
   a) BUY NOW — why current price is a good entry with exact reasoning
   b) WAIT FOR PULLBACK — target price, what you're waiting for
   c) LIMIT ORDER — exact limit order price and why that level
6. STOP LOSS — where to put your stop if you enter now
7. PRICE TARGET — 12-month target with multiple scenarios (bear/base/bull)

Be decisive. Give one clear answer. No sitting on the fence.`
      };

      const prompt = prompts[mode];
      if (!prompt) { res.writeHead(400); res.end(JSON.stringify({ error: 'Invalid mode' })); return; }

      const claudeRes = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 2000,
        messages: [{ role: 'user', content: prompt }]
      });

      res.writeHead(200); res.end(JSON.stringify({
        mode, ticker, analysis: claudeRes.content[0].text, ts: Date.now()
      }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── GUARDIAN: LOG CUSTOM EVENT FROM FRONTEND ───
  } else if (parsedUrl.pathname === '/guardian/event' && req.method === 'POST') {
    try {
      const body = await getBody(req);
      guardianLog(body.type || 'ui_event', body.ticker || null, body.detail || {});
      res.writeHead(200); res.end(JSON.stringify({ ok: true }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── GUARDIAN: STATUS + ACTIVE INTERVENTIONS ───
  } else if (parsedUrl.pathname === '/guardian/status') {
    try {
      const today = new Date().toISOString().split('T')[0];
      const active = db.prepare(`SELECT * FROM guardian_interventions WHERE dismissed = 0 ORDER BY ts DESC LIMIT 20`).all();
      const todayEvents = db.prepare(`SELECT event_type, COUNT(*) as cnt FROM guardian_events WHERE DATE(ts) = ? GROUP BY event_type`).all(today);
      const todaySignals = db.prepare(`SELECT COUNT(*) as cnt FROM guardian_events WHERE event_type = 'signal_run' AND DATE(ts) = ?`).get(today);
      const sessionEvents = db.prepare(`SELECT COUNT(*) as cnt FROM guardian_events WHERE session_id = ?`).get(guardianSessionId);
      const recentTickers = db.prepare(`SELECT DISTINCT ticker FROM guardian_events WHERE ticker IS NOT NULL AND ts > datetime('now', '-2 hours') ORDER BY ts DESC LIMIT 10`).all();
      const profile = {
        winRate: guardianGetProfile('win_rate'),
        mostSearched: guardianGetProfile('most_searched'),
        totalSignals: guardianGetProfile('total_signals'),
        lastCheck: guardianGetProfile('last_check'),
      };
      res.writeHead(200); res.end(JSON.stringify({
        active, todayEvents, todaySignals: todaySignals?.cnt || 0,
        sessionEvents: sessionEvents?.cnt || 0,
        recentTickers: recentTickers.map(r => r.ticker),
        profile, ts: Date.now()
      }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── GUARDIAN: DISMISS INTERVENTION ───
  } else if (parsedUrl.pathname === '/guardian/dismiss' && req.method === 'POST') {
    try {
      const body = await getBody(req);
      if (body.id === 'all') {
        db.prepare('UPDATE guardian_interventions SET dismissed = 1').run();
      } else {
        db.prepare('UPDATE guardian_interventions SET dismissed = 1 WHERE id = ?').run(body.id);
      }
      res.writeHead(200); res.end(JSON.stringify({ ok: true }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── GUARDIAN: ACTIVITY FEED ───
  } else if (parsedUrl.pathname === '/guardian/feed') {
    try {
      const events = db.prepare(`SELECT * FROM guardian_events ORDER BY ts DESC LIMIT 100`).all();
      const interventions = db.prepare(`SELECT * FROM guardian_interventions ORDER BY ts DESC LIMIT 50`).all();
      res.writeHead(200); res.end(JSON.stringify({ events, interventions }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── GUARDIAN: AI DEEP ANALYSIS — the scary one ───
  } else if (parsedUrl.pathname === '/guardian/analyse') {
    try {
      // Pull everything Guardian knows about you
      const allEvents = db.prepare(`SELECT event_type, ticker, detail, ts FROM guardian_events ORDER BY ts DESC LIMIT 500`).all();
      const allSignals = db.prepare(`SELECT ticker, signal, score, price_at_signal, result_1d, result_7d, logged_at FROM signal_log ORDER BY logged_at DESC LIMIT 100`).all();
      const allInterventions = db.prepare(`SELECT level, title, trigger_type, ts FROM guardian_interventions ORDER BY ts DESC LIMIT 50`).all();
      const portfolio = db.prepare('SELECT ticker, shares, buyPrice FROM portfolio').all();

      // Compute behavioural stats
      const byHour = {};
      allEvents.forEach(e => {
        const h = new Date(e.ts).getHours();
        byHour[h] = (byHour[h] || 0) + 1;
      });
      const peakHour = Object.entries(byHour).sort((a,b) => b[1]-a[1])[0];

      const tickerFreq = {};
      allEvents.filter(e => e.ticker).forEach(e => { tickerFreq[e.ticker] = (tickerFreq[e.ticker] || 0) + 1; });
      const topTickers = Object.entries(tickerFreq).sort((a,b) => b[1]-a[1]).slice(0, 10);

      const winRateByTicker = {};
      allSignals.filter(s => s.result_1d).forEach(s => {
        if (!winRateByTicker[s.ticker]) winRateByTicker[s.ticker] = { wins: 0, total: 0 };
        winRateByTicker[s.ticker].total++;
        if (s.result_1d === 'WIN') winRateByTicker[s.ticker].wins++;
      });

      const interventionTypes = {};
      allInterventions.forEach(i => { interventionTypes[i.trigger_type] = (interventionTypes[i.trigger_type] || 0) + 1; });
      const mostCommonWarning = Object.entries(interventionTypes).sort((a,b) => b[1]-a[1])[0];

      const totalSignalsMade = allSignals.length;
      const signalsWithResult = allSignals.filter(s => s.result_1d);
      const wins = signalsWithResult.filter(s => s.result_1d === 'WIN').length;
      const overallWinRate = signalsWithResult.length ? ((wins/signalsWithResult.length)*100).toFixed(1) : 'unknown';

      const prompt = `You are GUARDIAN — an elite AI financial behaviour analyst who has been silently watching this trader's every move. You know everything about them. You are brutally honest, deeply perceptive, and care about their financial wellbeing above all else.

Here is everything you know about this trader:

BEHAVIOURAL DATA (last 500 actions):
- Total events tracked: ${allEvents.length}
- Peak activity hour: ${peakHour ? `${peakHour[0]}:00 (${peakHour[1]} actions)` : 'unknown'}
- Top stocks they focus on: ${topTickers.map(([t,c]) => `${t}(${c}x)`).join(', ')}

TRADING PERFORMANCE:
- Total signals run: ${totalSignalsMade}
- Signals with results: ${signalsWithResult.length}
- Overall win rate: ${overallWinRate}%
- Win rates by ticker: ${Object.entries(winRateByTicker).map(([t,s]) => `${t}: ${((s.wins/s.total)*100).toFixed(0)}% (${s.total} trades)`).join(', ') || 'not enough data yet'}

PORTFOLIO (current holdings):
${portfolio.map(p => `- ${p.ticker}: ${p.shares} shares @ £${p.buyPrice}`).join('\n') || 'No holdings'}

WARNINGS TRIGGERED:
${allInterventions.slice(0, 20).map(i => `- ${i.level}: ${i.title} (${i.ts})`).join('\n') || 'None yet'}
- Most repeated warning: ${mostCommonWarning ? `"${mostCommonWarning[0]}" (${mostCommonWarning[1]} times)` : 'none'}

RECENT SIGNAL LOG:
${allSignals.slice(0, 20).map(s => `${s.ticker}: ${s.signal} (score:${s.score}, result:${s.result_1d || 'pending'})`).join('\n')}

Now give your full GUARDIAN ANALYSIS. Be specific. Be forensic. Be scary-accurate. Cover:

1. **TRADER PROFILE** — what type of trader are they based on behaviour patterns? What do their habits reveal about their psychology?

2. **STRENGTHS** — what are they genuinely good at? Where do they make money?

3. **BLIND SPOTS** — what patterns in the data reveal hidden weaknesses they probably don't know about? Be brutally specific.

4. **RISK PROFILE** — what is the real risk they're running? What's the most dangerous thing about how they trade?

5. **THE PATTERN I SEE** — one deep insight that will genuinely surprise them. Something they've never consciously noticed about themselves.

6. **WHAT WILL HURT THEM** — if they continue current patterns, what specific scenario will cause their biggest loss?

7. **3 THINGS TO CHANGE IMMEDIATELY** — specific, actionable changes ranked by impact.

8. **APP IMPROVEMENT SUGGESTIONS** — based on how they actually use this app, what features would genuinely help them? Be specific and creative.

9. **GUARDIAN VERDICT** — a final 2-3 sentence assessment. Raw. Honest. Empowering.

Write in first person as GUARDIAN. No fluff. No generic advice. Everything must reference their actual data.`;

      const claudeRes = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 2500,
        messages: [{ role: 'user', content: prompt }]
      });

      guardianLog('guardian_analyse', null, { requestedAt: new Date().toISOString() });
      res.writeHead(200); res.end(JSON.stringify({
        analysis: claudeRes.content[0].text,
        stats: { totalEvents: allEvents.length, totalSignals: totalSignalsMade, overallWinRate, topTickers, peakHour },
        ts: Date.now()
      }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── GUARDIAN: DAILY DEBRIEF ───
  } else if (parsedUrl.pathname === '/guardian/debrief') {
    try {
      const today = new Date().toISOString().split('T')[0];
      const todayEvents = db.prepare(`SELECT * FROM guardian_events WHERE DATE(ts) = ?`).all(today);
      const todaySignals = db.prepare(`SELECT * FROM signal_log WHERE DATE(logged_at) = ?`).all(today);
      const todayInterventions = db.prepare(`SELECT * FROM guardian_interventions WHERE DATE(ts) = ?`).all(today);

      const claudeRes = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 800,
        messages: [{
          role: 'user',
          content: `You are GUARDIAN. Give a concise daily debrief for today's trading activity.

TODAY'S ACTIVITY (${today}):
- Total actions: ${todayEvents.length}
- Signals run: ${todaySignals.length}
- Tickers looked at: ${[...new Set(todayEvents.filter(e=>e.ticker).map(e=>e.ticker))].join(', ') || 'none'}
- Warnings triggered: ${todayInterventions.length}
- Warning types: ${todayInterventions.map(i=>i.title).join('; ') || 'none'}

Give a daily debrief in this exact JSON format:
{
  "score": <number 1-10 for today's trading discipline>,
  "headline": "<one punchy sentence summarising today>",
  "positives": ["<thing they did well>", "<thing they did well>"],
  "concerns": ["<concern from today>"],
  "tomorrowFocus": "<one specific thing to focus on tomorrow>",
  "quote": "<a short motivational or cautionary quote relevant to today's behaviour>"
}`
        }]
      });

      const raw = claudeRes.content[0].text.replace(/```json|```/g, '').trim();
      res.writeHead(200); res.end(JSON.stringify({ debrief: JSON.parse(raw), ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── PENNY STOCK SCANNER ───
  } else if (parsedUrl.pathname === '/scanner/penny') {
    try {
      const mode = parsedUrl.searchParams.get('mode') || 'momentum'; // momentum | geopolitical | sector
      const customTickers = parsedUrl.searchParams.get('tickers');

      // Curated penny/small-cap lists by theme
      const lists = {
        momentum: ['MARA','RIOT','CLSK','CIFR','BTBT','SOPA','KOSS','NAKD','BBIG','CRON','SNDL','TLRY','ACB','CGC','NKLA','WKHS','RIDE','GOEV','BLNK','CHPT','SPWR','FCEL','PLUG','BLDP','BE','HYLN','SOLO','XPEV','LI','NIO','LCID','RIVN','FSR','WEJO','VVPR','GFAI','ATER','BBBY','GME','AMC','EXPR'],
        geopolitical: ['BALT','EGLE','SBLK','GNK','GOGL','NM','DSX','SHIP','TOPS','FREE','EDRY','CTRM','GLBS','PANL','GASS','SALT','SINO','OCLN','ABIO','ACST','IMVT','ZFOX','CXAI','AEYE','CLRO','KOPN','KRTX'],
        defense: ['AVAV','KTOS','RCAT','SPIR','IRDM','GILT','HSAI','ACHR','JOBY','LILM','EVTOL','BZFD','NRXP','ATHX','SIGA','EMER','LAKE','APT','FTIV'],
        biotech: ['ACST','IMVT','NRXP','ATHX','SIGA','EMER','INVA','ARQT','NVAX','CRTX','MOTS','DARE','CTIC','PHVS','CALA','TYME','ATNF','IMBI','LQDA','ACCD'],
        energy: ['TELL','GXII','NRGV','AMPE','VKIN','PRTK','ENSV','ReTo','STRO','CLIR','MFIN','HLBZ','PHGE','INPX','PRPB','HCAC'],
        custom: customTickers ? customTickers.split(',') : []
      };

      const watchlist = (lists[mode] || lists.momentum).slice(0, 25);
      
      const results = await Promise.allSettled(watchlist.map(async (t) => {
        try {
          const [quote, hist] = await Promise.all([fetchStock(t), fetchHistorical(t)]);
          if (!quote.price || quote.price > 20) return null; // penny = under $20
          
          const closes = hist.closes.filter(c => c !== null);
          const volumes = hist.volumes.filter(v => v !== null);
          if (closes.length < 10 || volumes.length < 10) return null;

          const avgVol = volumes.slice(-21, -1).reduce((a, b) => a + b, 0) / 20;
          const todayVol = volumes[volumes.length - 1];
          const volRatio = avgVol > 0 ? todayVol / avgVol : 0;

          const change1d = ((closes[closes.length-1] - closes[closes.length-2]) / closes[closes.length-2]) * 100;
          const change5d = closes.length > 6 ? ((closes[closes.length-1] - closes[closes.length-6]) / closes[closes.length-6]) * 100 : 0;
          const change1m = closes.length > 22 ? ((closes[closes.length-1] - closes[closes.length-22]) / closes[closes.length-22]) * 100 : 0;

          // Float proxy — high vol + low price = potential explosive move
          const dollarVol = todayVol * quote.price;
          const isLowFloat = dollarVol < 5000000 && todayVol > avgVol * 1.5;

          // Momentum score
          let score = 0;
          let tags = [];
          if (volRatio >= 5) { score += 50; tags.push(`🚀 ${volRatio.toFixed(0)}x volume`); }
          else if (volRatio >= 3) { score += 35; tags.push(`🔥 ${volRatio.toFixed(1)}x volume`); }
          else if (volRatio >= 2) { score += 20; tags.push(`⚡ ${volRatio.toFixed(1)}x volume`); }
          if (change1d > 10) { score += 30; tags.push(`+${change1d.toFixed(0)}% today`); }
          else if (change1d > 5) { score += 20; tags.push(`+${change1d.toFixed(0)}% today`); }
          else if (change1d > 2) { score += 10; tags.push(`+${change1d.toFixed(0)}% today`); }
          if (change1d < -10) { score += 15; tags.push(`${change1d.toFixed(0)}% drop`); } // oversold bounce potential
          if (change5d > 20) { score += 20; tags.push(`+${change5d.toFixed(0)}% 5d run`); }
          if (isLowFloat) { score += 25; tags.push('💎 Low float'); }
          if (quote.price < 1) { score += 10; tags.push('Sub $1'); }
          if (quote.price < 5) score += 5;

          const potential = quote.price < 1 ? '10-50x possible' : quote.price < 5 ? '5-10x possible' : '2-5x possible';

          return {
            ticker: t, price: quote.price, change1d: parseFloat(change1d.toFixed(2)),
            change5d: parseFloat(change5d.toFixed(2)), change1m: parseFloat(change1m.toFixed(2)),
            volRatio: parseFloat(volRatio.toFixed(1)), todayVol, avgVol: Math.round(avgVol),
            dollarVol: Math.round(dollarVol), score, tags, potential,
            alert: score >= 60 ? 'EXPLOSIVE' : score >= 40 ? 'HOT' : score >= 20 ? 'WATCH' : 'COLD',
            yearHigh: quote.yearHigh, yearLow: quote.yearLow,
            distFromLow: quote.yearLow > 0 ? (((quote.price - quote.yearLow) / quote.yearLow) * 100).toFixed(0) : 0
          };
        } catch(e) { return null; }
      }));

      const scanned = results.filter(r => r.status === 'fulfilled' && r.value).map(r => r.value);
      scanned.sort((a, b) => b.score - a.score);
      res.writeHead(200); res.end(JSON.stringify({ scanned, mode, ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── EARNINGS SURPRISE PREDICTOR ───
  } else if (parsedUrl.pathname === '/earnings/predict') {
    const t = parsedUrl.searchParams.get('ticker');
    if (!t) { res.writeHead(400); res.end(JSON.stringify({ error: 'ticker required' })); return; }
    try {
      const [quote, hist] = await Promise.all([fetchStock(t), fetchHistorical(t)]);
      const closes = hist.closes.filter(c => c !== null);
      const volumes = hist.volumes.filter(v => v !== null);
      
      // Pre-earnings signals
      const avgVol20 = volumes.slice(-21,-1).reduce((a,b)=>a+b,0)/20;
      const vol5dAvg = volumes.slice(-6,-1).reduce((a,b)=>a+b,0)/5;
      const volAcceleration = vol5dAvg / avgVol20;
      const change5d = ((closes[closes.length-1] - closes[closes.length-6]) / closes[closes.length-6]) * 100;
      const change20d = ((closes[closes.length-1] - closes[closes.length-21]) / closes[closes.length-21]) * 100;
      const rsi = ti.RSI.calculate({ values: closes, period: 14 });
      const currentRsi = rsi[rsi.length-1];
      const news = await fetchAllNews(t, quote.name || t);

      const claudeRes = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1200,
        messages: [{
          role: 'user',
          content: `You are an elite earnings analyst. Predict whether

IMPORTANT: Write everything in simple plain English. Imagine you are explaining to a smart 18 year old who is just learning to trade and has never worked in finance. No jargon, no complex terms. If you must use a technical word, explain it in brackets immediately after.

 ${t} will BEAT or MISS earnings, and predict the post-earnings stock move.

MARKET DATA:
- Current Price: $${quote.price}
- 5D Change: ${change5d.toFixed(2)}% (smart money positioning signal)
- 20D Change: ${change20d.toFixed(2)}%
- Volume Acceleration (5d vs 20d avg): ${volAcceleration.toFixed(2)}x (institutions accumulating?)
- RSI: ${currentRsi?.toFixed(1)}
- 52W High: $${quote.yearHigh} | 52W Low: $${quote.yearLow}
- Price position in 52W range: ${(((quote.price - quote.yearLow)/(quote.yearHigh-quote.yearLow))*100).toFixed(0)}%

RECENT NEWS HEADLINES:
${news.slice(0,8).map(n=>n.title).join('\n')}

Analyse and respond in JSON only:
{
  "earningsVerdict": "BEAT" | "MISS" | "IN-LINE",
  "confidence": <number 1-100>,
  "priceReaction": "+X% to +Y%" or "-X% to -Y%",
  "keySignals": ["signal 1", "signal 2", "signal 3"],
  "smartMoneyRead": "what the volume and price action suggests institutions are doing",
  "optionsPlay": "specific options strategy if you were trading earnings",
  "riskFactor": "biggest risk to this prediction",
  "preEarningsPlay": "buy before / avoid / short squeeze potential",
  "historicalPattern": "what typically happens to this type of stock around earnings",
  "verdict": "2 sentence decisive summary"
}`
        }]
      });
      const raw = claudeRes.content[0].text.replace(/```json|```/g, '').trim();
      guardianLog('earnings_predict', t, {});
      res.writeHead(200); res.end(JSON.stringify({ ticker: t, price: quote.price, prediction: JSON.parse(raw), signals: { volAcceleration: volAcceleration.toFixed(2), change5d: change5d.toFixed(2), rsi: currentRsi?.toFixed(1) }, ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── SOCIAL SENTIMENT SCANNER ───
  } else if (parsedUrl.pathname === '/sentiment/social') {
    const t = parsedUrl.searchParams.get('ticker');
    if (!t) { res.writeHead(400); res.end(JSON.stringify({ error: 'ticker required' })); return; }
    try {
      const [quote, news] = await Promise.all([fetchStock(t), fetchAllNews(t, t)]);
      
      const claudeRes = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        messages: [{
          role: 'user',
          content: `You are a social sentiment analyst who monitors Reddit

IMPORTANT: Write everything in simple plain English. Imagine you are explaining to a smart 18 year old who is just learning to trade and has never worked in finance. No jargon, no complex terms. If you must use a technical word, explain it in brackets immediately after.

 (WallStreetBets, stocks, investing), Twitter/X, StockTwits, and financial news for ${t}.

CURRENT PRICE: $${quote.price} (${quote.changePercent}% today)
52W: $${quote.yearLow} - $${quote.yearHigh}

RECENT NEWS (${news.length} articles found):
${news.slice(0,12).map(n=>`- ${n.title} [${n.source}]`).join('\n')}

Analyse the sentiment and retail investor activity. Respond in JSON only:
{
  "overallSentiment": "EXTREMELY_BULLISH" | "BULLISH" | "NEUTRAL" | "BEARISH" | "EXTREMELY_BEARISH",
  "sentimentScore": <-100 to +100>,
  "retailInterest": "VERY_HIGH" | "HIGH" | "MEDIUM" | "LOW",
  "wsb_hype": <0-10 WSB/meme potential score>,
  "shortSqueezeRisk": <0-10>,
  "catalysts": ["catalyst from news 1", "catalyst 2"],
  "bearArguments": ["bear case 1", "bear case 2"],
  "bullArguments": ["bull case 1", "bull case 2"],
  "narrrative": "what is the dominant market narrative around this stock right now",
  "retailTrap": true/false — is this stock being hyped to trap retail buyers,
  "alphaSigal": "the one thing most retail investors are missing about this stock",
  "tradingImplication": "what this sentiment means for the next 1-2 weeks"
}`
        }]
      });
      const raw = claudeRes.content[0].text.replace(/```json|```/g, '').trim();
      guardianLog('sentiment_scan', t, {});
      res.writeHead(200); res.end(JSON.stringify({ ticker: t, price: quote.price, sentiment: JSON.parse(raw), newsCount: news.length, ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── 10X GROWTH STOCK FINDER ───
  } else if (parsedUrl.pathname === '/stocks/tenx') {
    try {
      const sector = parsedUrl.searchParams.get('sector') || 'technology';
      const horizon = parsedUrl.searchParams.get('horizon') || '3-5 years';
      
      const claudeRes = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 2000,
        messages: [{
          role: 'user',
          content: `You are a venture-style growth investor at a top hedge fund.

IMPORTANT: Write everything in simple plain English. Imagine you are explaining to a smart 18 year old who is just learning to trade and has never worked in finance. No jargon, no complex terms. If you must use a technical word, explain it in brackets immediately after.

 Find genuine 10X+ stock opportunities.

Sector focus: ${sector}
Time horizon: ${horizon}
Current date: ${new Date().toISOString().split('T')[0]}

Find 5 stocks with genuine 10X potential. For each stock provide real analysis. Respond in JSON only:
{
  "picks": [
    {
      "ticker": "XXXX",
      "name": "Company Name",
      "currentPrice": <estimated price>,
      "target10x": <10x price>,
      "timeframe": "X-Y years",
      "marketCap": "small/micro/nano cap",
      "thesis": "the core reason this could 10x in 2-3 sentences",
      "catalysts": ["catalyst 1", "catalyst 2", "catalyst 3"],
      "risks": ["risk 1", "risk 2"],
      "moat": "what protects this company",
      "revenueGrowth": "estimated growth rate",
      "insiderOwnership": "high/medium/low",
      "conviction": <1-10>,
      "entryStrategy": "buy now / wait for dip to $X / scale in",
      "stopLoss": "where to cut losses"
    }
  ],
  "sectorOutlook": "2-3 sentence macro view on this sector",
  "bestEntry": "which of the 5 has the best risk/reward RIGHT NOW"
}`
        }]
      });
      const raw = claudeRes.content[0].text.replace(/```json|```/g, '').trim();
      guardianLog('tenx_scan', null, { sector });
      res.writeHead(200); res.end(JSON.stringify({ picks: JSON.parse(raw), sector, horizon, ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── HEDGE FUND STRATEGY REVERSE ENGINEER ───
  } else if (parsedUrl.pathname === '/hedge/decode') {
    try {
      const fund = parsedUrl.searchParams.get('fund') || 'Citadel';
      const claudeRes = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 2000,
        messages: [{
          role: 'user',
          content: `You are explaining a hedge fund to someone who is just learning to trade. Use simple everyday language. No jargon at all. Explain like you are talking to a smart 18 year old who has never worked in finance.

Fund to explain: ${fund}

Respond in JSON only. Every field must be plain simple English — no finance words:
{
  "fund": "${fund}",
  "aum": "how much money they manage, put it in perspective e.g. more than the GDP of France",
  "primaryStrategy": "what they actually do to make money in 2 simple sentences like explaining to a friend",
  "subStrategies": ["simple thing 1 they do to make money", "simple thing 2", "simple thing 3"],
  "topSectors": ["area of market 1 in plain words", "area 2", "area 3"],
  "knownPositions": [
    { "ticker": "XX", "rationale": "why they own this in one simple sentence a beginner understands" }
  ],
  "entrySignals": ["simple thing 1 they look for before buying", "thing 2", "thing 3"],
  "exitRules": ["when they sell and why — plain English"],
  "riskManagement": "how they protect themselves from big losses — explain simply",
  "edgeSource": "what advantage they have that regular investors do not — keep it simple",
  "replicateWith": ["ticker 1", "ticker 2", "ticker 3"],
  "currentBet": "what they seem to be betting will happen in the market right now — explained simply",
  "retailLesson": "the single most useful thing a regular person learning to trade can copy from how this fund thinks",
  "warningForRetail": "be honest and direct — explain simply how this fund sometimes makes money by being on the opposite side to small traders like us"
}`
        }]
      });
      const raw = claudeRes.content[0].text.replace(/```json|```/g, '').trim();
      guardianLog('hedge_decode', null, { fund });
      res.writeHead(200); res.end(JSON.stringify({ strategy: JSON.parse(raw), ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── PRICE FORECAST (AI + TECHNICALS) ───
  } else if (parsedUrl.pathname === '/forecast/price') {
    const t = parsedUrl.searchParams.get('ticker');
    if (!t) { res.writeHead(400); res.end(JSON.stringify({ error: 'ticker required' })); return; }
    try {
      const [quote, hist] = await Promise.all([fetchStock(t), fetchHistorical(t)]);
      const closes = hist.closes.filter(c => c !== null);
      const volumes = hist.volumes.filter(v => v !== null);
      
      // Technical indicators
      const sma20 = ti.SMA.calculate({ values: closes, period: 20 });
      const sma50 = ti.SMA.calculate({ values: closes, period: 50 });
      const rsi = ti.RSI.calculate({ values: closes, period: 14 });
      const macd = ti.MACD.calculate({ values: closes, fastPeriod: 12, slowPeriod: 26, signalPeriod: 9, SimpleMAOscillator: false, SimpleMASignal: false });
      const bb = ti.BollingerBands.calculate({ values: closes, period: 20, stdDev: 2 });

      // Simple linear regression on last 20 closes for trend direction
      const last20 = closes.slice(-20);
      const n = last20.length;
      const sumX = n*(n-1)/2;
      const sumY = last20.reduce((a,b)=>a+b,0);
      const sumXY = last20.reduce((s,y,i)=>s+i*y,0);
      const sumX2 = last20.reduce((s,_,i)=>s+i*i,0);
      const slope = (n*sumXY - sumX*sumY) / (n*sumX2 - sumX*sumX);
      const dailyTrend = slope; // $ per day trend

      const currentBB = bb[bb.length-1];
      const bbPosition = currentBB ? ((quote.price - currentBB.lower)/(currentBB.upper-currentBB.lower)*100).toFixed(0) : 50;

      const claudeRes = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1200,
        messages: [{
          role: 'user',
          content: `You are a quantitative analyst building a price forecast model

IMPORTANT: Write everything in simple plain English. Imagine you are explaining to a smart 18 year old who is just learning to trade and has never worked in finance. No jargon, no complex terms. If you must use a technical word, explain it in brackets immediately after.

 for ${t}.

TECHNICAL DATA:
- Current Price: $${quote.price}
- Linear Trend ($/day): ${dailyTrend.toFixed(3)} (${dailyTrend > 0 ? 'uptrend' : 'downtrend'})
- RSI(14): ${rsi[rsi.length-1]?.toFixed(1)}
- vs MA20: ${quote.price > sma20[sma20.length-1] ? 'ABOVE' : 'BELOW'} ($${sma20[sma20.length-1]?.toFixed(2)})
- vs MA50: ${quote.price > sma50[sma50.length-1] ? 'ABOVE' : 'BELOW'} ($${sma50[sma50.length-1]?.toFixed(2)})
- BB Position: ${bbPosition}% (0=at lower band, 100=at upper band)
- BB Upper: $${currentBB?.upper?.toFixed(2)} | Lower: $${currentBB?.lower?.toFixed(2)}
- MACD: ${macd[macd.length-1]?.MACD?.toFixed(3)} vs Signal: ${macd[macd.length-1]?.signal?.toFixed(3)}
- 52W Range: $${quote.yearLow} - $${quote.yearHigh}
- Volume today vs avg: ${(volumes[volumes.length-1]/( volumes.slice(-21,-1).reduce((a,b)=>a+b,0)/20)).toFixed(1)}x

Build a multi-timeframe price forecast. Respond in JSON only:
{
  "currentPrice": ${quote.price},
  "forecasts": {
    "week1": { "bear": X, "base": Y, "bull": Z },
    "month1": { "bear": X, "base": Y, "bull": Z },
    "month3": { "bear": X, "base": Y, "bull": Z },
    "month6": { "bear": X, "base": Y, "bull": Z }
  },
  "probabilities": {
    "up10pct_1month": <0-100>,
    "down10pct_1month": <0-100>,
    "newHighs_3month": <0-100>
  },
  "keyLevels": {
    "nextResistance": X,
    "nextSupport": X,
    "breakoutTarget": X,
    "breakdownTarget": X
  },
  "trendStrength": "STRONG_UP | MODERATE_UP | SIDEWAYS | MODERATE_DOWN | STRONG_DOWN",
  "meanReversionSignal": "oversold bounce likely | overbought pullback likely | neutral",
  "bestCase": "what happens in the best case scenario",
  "worstCase": "what happens in the worst case",
  "forecastConfidence": <1-100>,
  "tradeIdea": "specific trade idea based on this forecast"
}`
        }]
      });
      const raw = claudeRes.content[0].text.replace(/```json|```/g, '').trim();
      guardianLog('price_forecast', t, {});
      res.writeHead(200); res.end(JSON.stringify({ ticker: t, forecast: JSON.parse(raw), technicals: { rsi: rsi[rsi.length-1]?.toFixed(1), dailyTrend: dailyTrend.toFixed(3), bbPosition }, ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── INSIDER TRADING SIGNALS ───
  } else if (parsedUrl.pathname === '/insider/signals') {
    const t = parsedUrl.searchParams.get('ticker');
    if (!t) { res.writeHead(400); res.end(JSON.stringify({ error: 'ticker required' })); return; }
    try {
      const [quote, hist, news] = await Promise.all([fetchStock(t), fetchHistorical(t), fetchAllNews(t, t)]);
      const closes = hist.closes.filter(c=>c!==null);
      const volumes = hist.volumes.filter(v=>v!==null);
      
      // Unusual volume can proxy for insider accumulation
      const avgVol = volumes.slice(-21,-1).reduce((a,b)=>a+b,0)/20;
      const recentVols = volumes.slice(-5).map((v,i) => ({ day: i+1, ratio: (v/avgVol).toFixed(2) }));
      const change20d = ((closes[closes.length-1] - closes[closes.length-21]) / closes[closes.length-21] * 100).toFixed(2);

      const claudeRes = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1200,
        messages: [{
          role: 'user',
          content: `You are an expert in reading insider trading signals

IMPORTANT: Write everything in simple plain English. Imagine you are explaining to a smart 18 year old who is just learning to trade and has never worked in finance. No jargon, no complex terms. If you must use a technical word, explain it in brackets immediately after.

 using SEC Form 4 filings, dark pool data, and volume patterns.

Stock: ${t}
Price: $${quote.price} (${quote.changePercent}% today)
20D Price Change: ${change20d}%
52W Range: $${quote.yearLow} - $${quote.yearHigh}

VOLUME PATTERN (ratio vs 20d avg):
${recentVols.map(v=>`Day -${5-v.day}: ${v.ratio}x avg`).join('\n')}

RECENT NEWS:
${news.slice(0,8).map(n=>`- ${n.title}`).join('\n')}

Based on price action, volume patterns, and news context, analyse insider signals. Respond in JSON only:
{
  "insiderSentiment": "ACCUMULATING" | "DISTRIBUTING" | "NEUTRAL" | "MIXED",
  "confidenceScore": <0-100>,
  "volumeSignal": "what the volume pattern suggests about smart money activity",
  "priceActionClue": "what the price action reveals about who is in control",
  "darkPoolSignal": "estimated dark pool activity based on patterns",
  "institutionalFlow": "BUYING | SELLING | NEUTRAL — with reasoning",
  "recentForm4Signals": ["what we might expect from Form 4 filings based on price/vol patterns"],
  "clusterBuy": <true/false — multiple insiders likely buying>,
  "clusterSell": <true/false — multiple insiders likely selling>,
  "unusualActivity": ["any unusual patterns worth flagging"],
  "historicalInsiderPattern": "how insiders typically behave with this type of stock",
  "retailImplication": "what this means for a retail investor right now",
  "actionSignal": "BUY ALONGSIDE INSIDERS | CAUTION INSIDERS SELLING | WAIT | AVOID",
  "priceTarget": "where smart money is likely targeting",
  "timeframe": "estimated timeframe for the insider thesis to play out"
}`
        }]
      });
      const raw = claudeRes.content[0].text.replace(/```json|```/g, '').trim();
      guardianLog('insider_signals', t, {});
      res.writeHead(200); res.end(JSON.stringify({ ticker: t, price: quote.price, insiderAnalysis: JSON.parse(raw), volumePattern: recentVols, ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── FEAR & GREED INDEX (free CNN endpoint) ───
  } else if (parsedUrl.pathname === '/market/feargreed') {
    try {
      const options = { hostname: 'production.dataviz.cnn.io', path: '/index/fearandgreed/graphdata', method: 'GET', headers: { 'User-Agent': 'Mozilla/5.0', 'Referer': 'https://www.cnn.com' } };
      const data = await new Promise((resolve, reject) => {
        https.get(options, r => {
          let d = ''; r.on('data', c => d += c); r.on('end', () => { try { resolve(JSON.parse(d)); } catch(e) { reject(e); } });
        }).on('error', reject);
      });
      const score = data.fear_and_greed?.score;
      const rating = data.fear_and_greed?.rating;
      const prev = data.fear_and_greed?.previous_close;
      const week = data.fear_and_greed?.previous_1_week;
      const month = data.fear_and_greed?.previous_1_month;
      const year = data.fear_and_greed?.previous_1_year;
      res.writeHead(200); res.end(JSON.stringify({ score, rating, prev, week, month, year, ts: Date.now() }));
    } catch(e) {
      // Fallback: calculate from VIX-style using SPY data
      try {
        const spy = await fetchHistorical('SPY');
        const closes = spy.closes.filter(c=>c!==null);
        const vols = spy.volumes.filter(v=>v!==null);
        const rsi = ti.RSI.calculate({ values: closes, period: 14 });
        const currentRsi = rsi[rsi.length-1] || 50;
        const avgVol = vols.slice(-21,-1).reduce((a,b)=>a+b,0)/20;
        const volRatio = vols[vols.length-1]/avgVol;
        const mom5 = ((closes[closes.length-1]-closes[closes.length-6])/closes[closes.length-6])*100;
        // Composite score
        let score = 50;
        score += (currentRsi - 50) * 0.8;
        score += (volRatio - 1) * 10;
        score += mom5 * 2;
        score = Math.max(0, Math.min(100, score));
        const rating = score < 25 ? 'Extreme Fear' : score < 40 ? 'Fear' : score < 60 ? 'Neutral' : score < 75 ? 'Greed' : 'Extreme Greed';
        res.writeHead(200); res.end(JSON.stringify({ score: parseFloat(score.toFixed(1)), rating, calculated: true, ts: Date.now() }));
      } catch(e2) { res.writeHead(500); res.end(JSON.stringify({ error: e2.message })); }
    }

  // ─── SECTOR HEAT MAP ───
  } else if (parsedUrl.pathname === '/market/sectors') {
    try {
      const sectors = [
        { name: 'Technology', ticker: 'XLK', emoji: '💻' },
        { name: 'Healthcare', ticker: 'XLV', emoji: '🏥' },
        { name: 'Financials', ticker: 'XLF', emoji: '🏦' },
        { name: 'Energy', ticker: 'XLE', emoji: '⛽' },
        { name: 'Consumer Disc', ticker: 'XLY', emoji: '🛍️' },
        { name: 'Industrials', ticker: 'XLI', emoji: '🏭' },
        { name: 'Utilities', ticker: 'XLU', emoji: '⚡' },
        { name: 'Materials', ticker: 'XLB', emoji: '🪨' },
        { name: 'Real Estate', ticker: 'XLRE', emoji: '🏠' },
        { name: 'Comm Services', ticker: 'XLC', emoji: '📡' },
        { name: 'Consumer Staples', ticker: 'XLP', emoji: '🛒' },
        { name: 'S&P 500', ticker: 'SPY', emoji: '📊' },
        { name: 'NASDAQ', ticker: 'QQQ', emoji: '🔷' },
        { name: 'Russell 2000', ticker: 'IWM', emoji: '🔸' },
        { name: 'Crypto', ticker: 'BITO', emoji: '🟡' },
        { name: 'Gold', ticker: 'GLD', emoji: '🥇' }
      ];
      const results = await Promise.allSettled(sectors.map(async s => {
        const q = await fetchStock(s.ticker);
        const h = await fetchHistorical(s.ticker);
        const closes = h.closes.filter(c=>c!==null);
        const w1 = closes.length>6 ? ((closes[closes.length-1]-closes[closes.length-6])/closes[closes.length-6]*100) : 0;
        const m1 = closes.length>22 ? ((closes[closes.length-1]-closes[closes.length-22])/closes[closes.length-22]*100) : 0;
        const m3 = closes.length>66 ? ((closes[closes.length-1]-closes[closes.length-66])/closes[closes.length-66]*100) : 0;
        return { ...s, price: q.price, change1d: parseFloat(q.changePercent), change1w: parseFloat(w1.toFixed(2)), change1m: parseFloat(m1.toFixed(2)), change3m: parseFloat(m3.toFixed(2)) };
      }));
      const data = results.filter(r=>r.status==='fulfilled').map(r=>r.value);
      res.writeHead(200); res.end(JSON.stringify({ sectors: data, ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── SIGNAL BOARD SCAN — full technical read in plain English ───
  } else if (parsedUrl.pathname === '/signals/scan') {
    try {
      const ticker = (parsedUrl.searchParams.get('ticker') || 'AAPL').toUpperCase();
      const [quote, hist] = await Promise.all([fetchStock(ticker), fetchHistorical(ticker)]);
      const closes = hist.closes.filter(c => c !== null);
      const volumes = hist.volumes.filter(v => v !== null);
      const highs = (hist.highs || []).filter(c => c !== null);
      const lows = (hist.lows || []).filter(c => c !== null);
      if (closes.length < 30) throw new Error('Not enough data');

      const price = quote.price;
      const signals = [];

      // ── 1. Death Cross / Golden Cross (SMA 50 vs SMA 200) ──
      if (closes.length >= 200) {
        const sma50 = ti.SMA.calculate({ values: closes, period: 50 });
        const sma200 = ti.SMA.calculate({ values: closes, period: 200 });
        const s50now = sma50[sma50.length - 1];
        const s50prev = sma50[sma50.length - 6];
        const s200now = sma200[sma200.length - 1];
        const s200prev = sma200[sma200.length - 6];
        const crossedBelow = s50now < s200now && s50prev >= s200prev;
        const crossedAbove = s50now > s200now && s50prev <= s200prev;
        const currentlyBelow = s50now < s200now;
        if (crossedBelow) {
          signals.push({ id:'cross', status:'BEARISH', icon:'💀', name:'Death Cross Just Happened', value:`50-day: $${s50now.toFixed(2)} · 200-day: $${s200now.toFixed(2)}`, explanation:'The 50-day average just crossed below the 200-day average this week. Think of it like this — the short term trend has turned worse than the long term trend. Historically this often means more downside is coming before things recover. Not guaranteed but worth being careful.' });
        } else if (crossedAbove) {
          signals.push({ id:'cross', status:'BULLISH', icon:'✨', name:'Golden Cross Just Happened', value:`50-day: $${s50now.toFixed(2)} · 200-day: $${s200now.toFixed(2)}`, explanation:'The 50-day average just crossed above the 200-day average this week. This means the short term momentum is now stronger than the long term trend. Historically this often signals the start of a stronger upward move.' });
        } else if (currentlyBelow) {
          signals.push({ id:'cross', status:'BEARISH', icon:'📉', name:'Death Cross Active', value:`50-day: $${s50now.toFixed(2)} · 200-day: $${s200now.toFixed(2)}`, explanation:'The 50-day average is below the 200-day average right now. This means the recent price trend is weaker than the longer term trend. The stock is in a bearish phase — not saying it cannot go up, but the wind is blowing against it right now.' });
        } else {
          signals.push({ id:'cross', status:'BULLISH', icon:'📈', name:'Golden Cross Active', value:`50-day: $${s50now.toFixed(2)} · 200-day: $${s200now.toFixed(2)}`, explanation:'The 50-day average is above the 200-day average. The recent trend is stronger than the longer term trend. This is a healthy bullish sign — the stock has good momentum behind it.' });
        }
      }

      // ── 2. RSI ──
      const rsiArr = ti.RSI.calculate({ values: closes, period: 14 });
      const rsi = rsiArr[rsiArr.length - 1];
      let rsiStatus, rsiName, rsiExplain;
      if (rsi < 25) { rsiStatus='BULLISH'; rsiName='Very Oversold — Possible Bounce'; rsiExplain=`RSI is ${rsi.toFixed(1)}. Below 30 means the stock has been sold really hard and fast. Think of a rubber band being stretched too far — it often snaps back. Not a guarantee but the selling pressure may be exhausted. Could be a good level to watch for a bounce.`; }
      else if (rsi < 35) { rsiStatus='BULLISH'; rsiName='Oversold — Worth Watching'; rsiExplain=`RSI is ${rsi.toFixed(1)}. The stock has been under heavy selling pressure. At these levels buyers sometimes start stepping in because the price looks cheap versus where it recently was. Worth watching for signs of stabilisation.`; }
      else if (rsi > 75) { rsiStatus='BEARISH'; rsiName='Very Overbought — Be Careful'; rsiExplain=`RSI is ${rsi.toFixed(1)}. Above 70 means the stock has been bought very aggressively and is now potentially overheated. Like a car revving too high — it can keep going but the risk of a pullback is elevated. Not a good time to be chasing it higher.`; }
      else if (rsi > 65) { rsiStatus='CAUTION'; rsiName='Getting Overbought'; rsiExplain=`RSI is ${rsi.toFixed(1)}. Getting close to the zone where stocks often slow down or pull back. The buying has been strong recently. Still bullish but be careful about buying too much at these levels.`; }
      else { rsiStatus='NEUTRAL'; rsiName='RSI Neutral — No Extreme'; rsiExplain=`RSI is ${rsi.toFixed(1)}. Bang in the middle — not overbought and not oversold. The stock is moving normally without extreme buying or selling pressure. This alone does not give you a clear signal either way.`; }
      signals.push({ id:'rsi', status:rsiStatus, icon:'📊', name:rsiName, value:`RSI: ${rsi.toFixed(1)}`, explanation:rsiExplain });

      // ── 3. MACD ──
      if (closes.length >= 35) {
        const macdArr = ti.MACD.calculate({ values: closes, fastPeriod: 12, slowPeriod: 26, signalPeriod: 9, SimpleMAOscillator: false, SimpleMASignal: false });
        const m = macdArr[macdArr.length - 1];
        const mPrev = macdArr[macdArr.length - 2];
        if (m && mPrev) {
          const crossedUp = m.MACD > m.signal && mPrev.MACD <= mPrev.signal;
          const crossedDown = m.MACD < m.signal && mPrev.MACD >= mPrev.signal;
          const bullish = m.MACD > m.signal;
          let macdStatus, macdName, macdExplain;
          if (crossedUp) { macdStatus='BULLISH'; macdName='MACD Just Turned Bullish'; macdExplain=`MACD just crossed above its signal line. Think of MACD as a speedometer for momentum. When it crosses upward it means buying momentum is picking up speed. This is one of the cleaner short term buy signals.`; }
          else if (crossedDown) { macdStatus='BEARISH'; macdName='MACD Just Turned Bearish'; macdExplain=`MACD just crossed below its signal line. The momentum is slowing down and turning negative. Like a car starting to brake — it does not mean it stops immediately but the direction of travel is changing.`; }
          else if (bullish) { macdStatus='BULLISH'; macdName='MACD Bullish Momentum'; macdExplain=`MACD is above its signal line meaning buying momentum is currently stronger than selling momentum. The stock has positive short term energy behind it.`; }
          else { macdStatus='BEARISH'; macdName='MACD Bearish Momentum'; macdExplain=`MACD is below its signal line meaning selling momentum is stronger than buying momentum right now. The short term energy is negative.`; }
          signals.push({ id:'macd', status:macdStatus, icon:'⚡', name:macdName, value:`MACD: ${m.MACD?.toFixed(3)} · Signal: ${m.signal?.toFixed(3)}`, explanation:macdExplain });
        }
      }

      // ── 4. Price vs 200 SMA (trend health) ──
      if (closes.length >= 200) {
        const sma200 = ti.SMA.calculate({ values: closes, period: 200 });
        const s200 = sma200[sma200.length - 1];
        const pct = ((price - s200) / s200 * 100);
        let tStatus, tName, tExplain;
        if (pct > 15) { tStatus='CAUTION'; tName=`Price Far Above Long Term Average`; tExplain=`The price is ${pct.toFixed(1)}% above its 200-day average. That is a big stretch. While it shows strong momentum, historically stocks this far above their long term average tend to pull back toward it eventually. Not a sell signal but worth noting.`; }
        else if (pct > 0) { tStatus='BULLISH'; tName=`Price Above Long Term Average`; tExplain=`The price is ${pct.toFixed(1)}% above its 200-day average. This is a healthy sign — the stock is trending upward over the long term. The 200-day average acts like a floor. As long as price stays above it the long term trend is positive.`; }
        else if (pct > -10) { tStatus='CAUTION'; tName=`Price Below Long Term Average`; tExplain=`The price is ${Math.abs(pct).toFixed(1)}% below its 200-day average. The stock has broken below its long term trend. This is a yellow flag — not a disaster but the long term health of this stock is now questionable until it recovers above the 200-day average ($${s200.toFixed(2)}).`; }
        else { tStatus='BEARISH'; tName=`Price Well Below Long Term Average`; tExplain=`The price is ${Math.abs(pct).toFixed(1)}% below its 200-day average ($${s200.toFixed(2)}). The stock is significantly below its long term trend. This is a bearish sign — it suggests the stock has been in a sustained downtrend and has lost long term support.`; }
        signals.push({ id:'trend', status:tStatus, icon:'🎯', name:tName, value:`Price: $${price} · 200-day avg: $${s200.toFixed(2)} (${pct>0?'+':''}${pct.toFixed(1)}%)`, explanation:tExplain });
      }

      // ── 5. Volume ──
      if (volumes.length >= 22) {
        const avgVol = volumes.slice(-22, -1).reduce((a, b) => a + b, 0) / 21;
        const todayVol = volumes[volumes.length - 1];
        const ratio = todayVol / avgVol;
        let vStatus, vName, vExplain;
        if (ratio > 2.5 && closes[closes.length-1] > closes[closes.length-2]) { vStatus='BULLISH'; vName=`Big Volume — Buyers Stepping In`; vExplain=`Volume today is ${ratio.toFixed(1)}x the normal average with price going up. High volume on an up day means real money is buying — not just a random drift. This kind of move tends to be more meaningful and sustainable.`; }
        else if (ratio > 2.5) { vStatus='BEARISH'; vName=`Big Volume — Heavy Selling`; vExplain=`Volume today is ${ratio.toFixed(1)}x the normal average with price going down. Heavy volume on a down day means real money is selling — not just a small wobble. This kind of drop tends to signal more pain ahead.`; }
        else if (ratio > 1.5) { vStatus='CAUTION'; vName=`Above Average Volume — Worth Watching`; vExplain=`Volume is ${ratio.toFixed(1)}x the normal level. Something is attracting more attention than usual. Not extreme but worth paying attention to what the price is doing alongside this.`; }
        else { vStatus='NEUTRAL'; vName=`Normal Volume — Nothing Unusual`; vExplain=`Volume is about normal (${ratio.toFixed(1)}x average). No unusual buying or selling activity detected. This means the current price move is not backed by exceptional conviction either way.`; }
        signals.push({ id:'volume', status:vStatus, icon:'📦', name:vName, value:`Today: ${(todayVol/1000000).toFixed(1)}M · Avg: ${(avgVol/1000000).toFixed(1)}M · ${ratio.toFixed(1)}x normal`, explanation:vExplain });
      }

      // ── 6. 52-Week Position ──
      const high52 = quote.yearHigh;
      const low52 = quote.yearLow;
      if (high52 && low52) {
        const range = high52 - low52;
        const position = ((price - low52) / range * 100);
        let wStatus, wName, wExplain;
        if (position > 85) { wStatus='CAUTION'; wName=`Near 52-Week High — Caution`; wExplain=`The stock is in the top ${(100-position).toFixed(0)}% of its yearly range, close to the highest it has been in a year. Buying near highs can work but the risk of a pullback is higher. Make sure you have a reason to buy here beyond just following the momentum.`; }
        else if (position > 50) { wStatus='BULLISH'; wName=`Upper Half of Yearly Range`; wExplain=`At $${price} the stock is in the upper half of where it has traded this year. It is performing relatively well. Not at extremes — a reasonable zone.`; }
        else if (position < 20) { wStatus='NEUTRAL'; wName=`Near 52-Week Low — Potential Value`; wExplain=`The stock is near the lowest it has been in a year. This could mean it is cheap — or that something is wrong with the company. Before buying at lows always check the reason why it has fallen this much.`; }
        else { wStatus='NEUTRAL'; wName=`Lower Half of Yearly Range`; wExplain=`At $${price} the stock is in the lower half of its yearly range. It has underperformed relative to its highs but is not at extremes. Could be recovering or could continue drifting lower.`; }
        signals.push({ id:'range', status:wStatus, icon:'📍', name:wName, value:`$${low52} ←─── $${price} ───→ $${high52} (${position.toFixed(0)}% of range)`, explanation:wExplain });
      }

      // ── 7. Bollinger Bands ──
      if (closes.length >= 25) {
        const bbArr = ti.BollingerBands.calculate({ values: closes, period: 20, stdDev: 2 });
        const bb = bbArr[bbArr.length - 1];
        if (bb) {
          const squeeze = (bb.upper - bb.lower) / bb.middle * 100;
          let bStatus, bName, bExplain;
          if (price > bb.upper) { bStatus='CAUTION'; bName=`Price Outside Upper Band — Stretched`; bExplain=`The price has moved above the upper Bollinger Band ($${bb.upper.toFixed(2)}). Think of these bands like a corridor the price usually stays inside. When it breaks out of the top it often means the stock is overextended and may snap back toward the middle ($${bb.middle.toFixed(2)}).`; }
          else if (price < bb.lower) { bStatus='BULLISH'; bName=`Price Below Lower Band — Oversold`; bExplain=`The price has dropped below the lower Bollinger Band ($${bb.lower.toFixed(2)}). The stock has been pushed outside its normal range to the downside. Often a bounce back toward the middle ($${bb.middle.toFixed(2)}) follows from these levels.`; }
          else if (squeeze < 3) { bStatus='NEUTRAL'; bName=`Bollinger Squeeze — Big Move Coming`; bExplain=`The bands are very tight right now. When the bands squeeze together like this it means the stock has been very quiet — but historically that usually ends with a sharp move. We just do not know yet if it will go up or down. Watch closely.`; }
          else { bStatus='NEUTRAL'; bName=`Price Inside Normal Range`; bExplain=`The price is within its normal Bollinger Band range. No extreme readings. The stock is behaving normally right now.`; }
          signals.push({ id:'bb', status:bStatus, icon:'🎪', name:bName, value:`Upper: $${bb.upper.toFixed(2)} · Mid: $${bb.middle.toFixed(2)} · Lower: $${bb.lower.toFixed(2)}`, explanation:bExplain });
        }
      }

      // ── Overall score ──
      const bullCount = signals.filter(s => s.status === 'BULLISH').length;
      const bearCount = signals.filter(s => s.status === 'BEARISH').length;
      const cautCount = signals.filter(s => s.status === 'CAUTION').length;
      let overallVerdict, overallColor, overallMsg;
      if (bullCount >= bearCount + cautCount) { overallVerdict = 'BULLISH'; overallColor = '#00FF88'; overallMsg = 'More signals are pointing up than down right now. Not a guarantee — but the chart is telling a mostly positive story.'; }
      else if (bearCount > bullCount) { overallVerdict = 'BEARISH'; overallColor = '#FF3355'; overallMsg = 'More signals are pointing down than up. Be careful. This does not mean the stock cannot go up — but the chart is showing more warning signs than green lights.'; }
      else { overallVerdict = 'MIXED'; overallColor = '#FFB800'; overallMsg = 'Signals are mixed — some bullish, some bearish. No clear direction from the chart right now. Wait for more clarity before committing.'; }

      res.writeHead(200); res.end(JSON.stringify({ ticker, price, signals, overall: { verdict: overallVerdict, color: overallColor, message: overallMsg, bull: bullCount, bear: bearCount, caution: cautCount }, ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── TECHNICAL SCANNER — zero AI ───
  } else if (parsedUrl.pathname === '/scanner/technical') {
    try {
      const tickers = (parsedUrl.searchParams.get('tickers') || 'AAPL,TSLA,NVDA,MSFT,AMZN,META,AMD,GOOGL,PLTR,SOFI,MARA,RIOT,COIN,NIO,LCID,SPY,QQQ,BALT,SBLK,EGLE').split(',').slice(0, 25);
      const results = await Promise.allSettled(tickers.map(async t => {
        const [q, h] = await Promise.all([fetchStock(t), fetchHistorical(t)]);
        const closes = h.closes.filter(c=>c!==null);
        const highs = h.highs?.filter(c=>c!==null)||[];
        const lows = h.lows?.filter(c=>c!==null)||[];
        const vols = h.volumes.filter(v=>v!==null);
        if (closes.length < 30) return null;

        const sma20 = ti.SMA.calculate({ values: closes, period: 20 });
        const sma50 = ti.SMA.calculate({ values: closes, period: 50 });
        const sma200 = ti.SMA.calculate({ values: closes, period: Math.min(200, closes.length-1) });
        const rsiVals = ti.RSI.calculate({ values: closes, period: 14 });
        const macdVals = ti.MACD.calculate({ values: closes, fastPeriod: 12, slowPeriod: 26, signalPeriod: 9, SimpleMAOscillator: false, SimpleMASignal: false });
        const bbVals = ti.BollingerBands.calculate({ values: closes, period: 20, stdDev: 2 });

        const price = q.price;
        const rsi = rsiVals[rsiVals.length-1];
        const macd = macdVals[macdVals.length-1];
        const bb = bbVals[bbVals.length-1];
        const ma20 = sma20[sma20.length-1];
        const ma50 = sma50[sma50.length-1];
        const ma200 = sma200.length ? sma200[sma200.length-1] : null;
        const prevMacd = macdVals[macdVals.length-2];
        const avgVol = vols.slice(-21,-1).reduce((a,b)=>a+b,0)/20;
        const volRatio = vols[vols.length-1]/avgVol;

        // Detect signals
        const signals = [];
        let bullScore = 0, bearScore = 0;

        if (rsi < 30) { signals.push({ type: 'OVERSOLD', desc: `RSI ${rsi.toFixed(0)} — bounce candidate`, strength: 'STRONG', dir: 'bull' }); bullScore += 3; }
        if (rsi > 70) { signals.push({ type: 'OVERBOUGHT', desc: `RSI ${rsi.toFixed(0)} — pullback risk`, strength: 'STRONG', dir: 'bear' }); bearScore += 3; }
        if (rsi > 40 && rsi < 60) bullScore += 1;

        // MACD crossover
        if (prevMacd && macd) {
          if (macd.MACD > macd.signal && prevMacd.MACD <= prevMacd.signal) { signals.push({ type: 'MACD CROSS UP', desc: 'Bullish MACD crossover', strength: 'STRONG', dir: 'bull' }); bullScore += 3; }
          if (macd.MACD < macd.signal && prevMacd.MACD >= prevMacd.signal) { signals.push({ type: 'MACD CROSS DOWN', desc: 'Bearish MACD crossover', strength: 'STRONG', dir: 'bear' }); bearScore += 3; }
        }

        // Bollinger Band squeeze/break
        if (bb) {
          const bbWidth = (bb.upper - bb.lower) / bb.middle;
          if (price > bb.upper) { signals.push({ type: 'BB BREAKOUT', desc: `Price above upper band $${bb.upper.toFixed(2)}`, strength: 'MEDIUM', dir: 'bull' }); bullScore += 2; }
          if (price < bb.lower) { signals.push({ type: 'BB BREAKDOWN', desc: `Price below lower band $${bb.lower.toFixed(2)}`, strength: 'MEDIUM', dir: 'bear' }); bearScore += 2; }
          if (bbWidth < 0.05) { signals.push({ type: 'BB SQUEEZE', desc: 'Bollinger Band squeeze — big move coming', strength: 'MEDIUM', dir: 'neutral' }); }
        }

        // MA relationships
        if (price > ma20 && price > ma50) { bullScore += 2; }
        if (price < ma20 && price < ma50) { bearScore += 2; }
        if (ma50 && ma200) {
          if (ma50 > ma200 && sma50[sma50.length-2] <= sma200[sma200.length-2]) { signals.push({ type: 'GOLDEN CROSS', desc: 'MA50 crossed above MA200', strength: 'STRONG', dir: 'bull' }); bullScore += 4; }
          if (ma50 < ma200 && sma50[sma50.length-2] >= sma200[sma200.length-2]) { signals.push({ type: 'DEATH CROSS', desc: 'MA50 crossed below MA200', strength: 'STRONG', dir: 'bear' }); bearScore += 4; }
        }

        // Volume spike with direction
        if (volRatio > 2 && parseFloat(q.changePercent) > 2) { signals.push({ type: 'VOLUME SURGE ↑', desc: `${volRatio.toFixed(1)}x volume + price up`, strength: 'STRONG', dir: 'bull' }); bullScore += 3; }
        if (volRatio > 2 && parseFloat(q.changePercent) < -2) { signals.push({ type: 'VOLUME DUMP ↓', desc: `${volRatio.toFixed(1)}x volume + price down`, strength: 'STRONG', dir: 'bear' }); bearScore += 3; }

        const netScore = bullScore - bearScore;
        const bias = netScore >= 3 ? 'BULLISH' : netScore <= -3 ? 'BEARISH' : 'NEUTRAL';

        return { ticker: t, price, change1d: parseFloat(q.changePercent), rsi: parseFloat(rsi?.toFixed(1)), ma20: parseFloat(ma20?.toFixed(2)), ma50: parseFloat(ma50?.toFixed(2)), volRatio: parseFloat(volRatio.toFixed(1)), signals, bullScore, bearScore, bias };
      }));

      const scanned = results.filter(r=>r.status==='fulfilled'&&r.value).map(r=>r.value);
      scanned.sort((a,b) => (b.bullScore+b.bearScore) - (a.bullScore+a.bearScore));
      res.writeHead(200); res.end(JSON.stringify({ scanned, ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── ECONOMIC CALENDAR (free API) ───
  } else if (parsedUrl.pathname === '/market/calendar') {
    try {
      const options = { hostname: 'api.tradingeconomics.com', path: '/calendar?c=guest:guest&f=json', method: 'GET', headers: { 'User-Agent': 'Mozilla/5.0' } };
      const data = await new Promise((resolve, reject) => {
        https.get(options, r => {
          let d = ''; r.on('data', c => d += c); r.on('end', () => { try { resolve(JSON.parse(d)); } catch(e) { reject(e); } });
        }).on('error', reject);
      });
      res.writeHead(200); res.end(JSON.stringify({ events: data.slice(0, 30), ts: Date.now() }));
    } catch(e) {
      // Fallback — static upcoming events
      const events = [
        { event: 'FOMC Meeting Minutes', country: 'United States', date: 'Check Federal Reserve calendar', importance: 'HIGH', impact: 'Markets pause before this. High volatility after.' },
        { event: 'CPI Inflation Data', country: 'United States', date: 'Monthly — check BLS calendar', importance: 'HIGH', impact: 'If hot → stocks drop. If cool → stocks rally.' },
        { event: 'Non-Farm Payrolls', country: 'United States', date: 'First Friday of each month', importance: 'HIGH', impact: 'Strong jobs = Fed stays hawkish. Weak = bullish for stocks.' },
        { event: 'GDP Growth Rate', country: 'United States', date: 'Quarterly', importance: 'MEDIUM', impact: 'Recession signal if negative two quarters in a row.' },
        { event: 'Earnings Season', country: 'United States', date: 'Jan/Apr/Jul/Oct', importance: 'HIGH', impact: 'Biggest price moves of the year for individual stocks.' },
        { event: 'UK Inflation (CPI)', country: 'United Kingdom', date: 'Monthly', importance: 'MEDIUM', impact: 'Affects FTSE and GBP/USD' },
        { event: 'Bank of England Rate Decision', country: 'United Kingdom', date: '8x per year', importance: 'HIGH', impact: 'Affects LLOY, BARC, NatWest and housebuilders.' },
      ];
      res.writeHead(200); res.end(JSON.stringify({ events, fallback: true, ts: Date.now() }));
    }

  // ─── BACKTESTER ───
  } else if (parsedUrl.pathname === '/backtest' && req.method === 'POST') {
    try {
      const body = await getBody(req);
      const { ticker, strategy, rsiOversold = 30, rsiOverbought = 70, smaPeriod = 20, startingCash = 10000, stopLossPct = 5, takeProfitPct = 15 } = body;
      if (!ticker) { res.writeHead(400); res.end(JSON.stringify({ error: 'ticker required' })); return; }

      const hist = await fetchHistorical(ticker);
      const closes = hist.closes.filter(c=>c!==null);
      const vols = hist.volumes.filter(v=>v!==null);
      if (closes.length < 50) { res.writeHead(400); res.end(JSON.stringify({ error: 'Not enough data' })); return; }

      const sma = ti.SMA.calculate({ values: closes, period: parseInt(smaPeriod) });
      const rsi = ti.RSI.calculate({ values: closes, period: 14 });
      const macd = ti.MACD.calculate({ values: closes, fastPeriod: 12, slowPeriod: 26, signalPeriod: 9, SimpleMAOscillator: false, SimpleMASignal: false });

      let cash = parseFloat(startingCash);
      let shares = 0;
      let entryPrice = 0;
      const trades = [];
      const equity = [];
      let wins = 0, losses = 0, totalPnl = 0;

      const offset = Math.max(parseInt(smaPeriod), 30);
      for (let i = offset; i < closes.length; i++) {
        const price = closes[i];
        const rsiVal = rsi[i - (closes.length - rsi.length)];
        const macdVal = macd[i - (closes.length - macd.length)];
        const macdPrev = macd[i - (closes.length - macd.length) - 1];
        const smaVal = sma[i - (closes.length - sma.length)];
        const volRatio = vols[i] / (vols.slice(i-20,i).reduce((a,b)=>a+b,0)/20);

        let buySignal = false, sellSignal = false;

        if (strategy === 'rsi') {
          buySignal = rsiVal < rsiOversold;
          sellSignal = rsiVal > rsiOverbought;
        } else if (strategy === 'macd') {
          buySignal = macdVal && macdPrev && macdVal.MACD > macdVal.signal && macdPrev.MACD <= macdPrev.signal;
          sellSignal = macdVal && macdPrev && macdVal.MACD < macdVal.signal && macdPrev.MACD >= macdPrev.signal;
        } else if (strategy === 'sma') {
          buySignal = price > smaVal;
          sellSignal = price < smaVal;
        } else if (strategy === 'volume') {
          buySignal = volRatio > 2 && rsiVal < 60;
          sellSignal = rsiVal > 70 || volRatio > 3 && parseFloat(closes[i]) < closes[i-1];
        }

        // Stop loss / take profit
        if (shares > 0) {
          const pnlPct = ((price - entryPrice) / entryPrice) * 100;
          if (pnlPct <= -stopLossPct) { sellSignal = true; }
          if (pnlPct >= takeProfitPct) { sellSignal = true; }
        }

        if (buySignal && shares === 0 && cash > price) {
          shares = Math.floor(cash / price);
          entryPrice = price;
          cash -= shares * price;
          trades.push({ type: 'BUY', price, day: i, shares });
        } else if (sellSignal && shares > 0) {
          const pnl = (price - entryPrice) * shares;
          totalPnl += pnl;
          if (pnl > 0) wins++; else losses++;
          cash += shares * price;
          trades.push({ type: 'SELL', price, day: i, shares, pnl: parseFloat(pnl.toFixed(2)) });
          shares = 0; entryPrice = 0;
        }
        equity.push(parseFloat((cash + shares * price).toFixed(2)));
      }

      // Close open position at end
      if (shares > 0) {
        const finalPrice = closes[closes.length-1];
        const pnl = (finalPrice - entryPrice) * shares;
        totalPnl += pnl;
        if (pnl > 0) wins++; else losses++;
        cash += shares * finalPrice;
        trades.push({ type: 'CLOSE', price: finalPrice, day: closes.length-1, shares, pnl: parseFloat(pnl.toFixed(2)) });
      }

      const finalValue = cash;
      const totalReturn = ((finalValue - startingCash) / startingCash * 100).toFixed(2);
      const buyHoldReturn = ((closes[closes.length-1] - closes[offset]) / closes[offset] * 100).toFixed(2);
      const winRate = (wins + losses) > 0 ? ((wins/(wins+losses))*100).toFixed(0) : 0;
      const maxDrawdown = equity.length > 0 ? (() => {
        let peak = equity[0], maxDD = 0;
        equity.forEach(v => { if (v > peak) peak = v; const dd = ((peak-v)/peak)*100; if (dd > maxDD) maxDD = dd; });
        return maxDD.toFixed(1);
      })() : 0;

      res.writeHead(200); res.end(JSON.stringify({
        ticker, strategy, startingCash: parseFloat(startingCash), finalValue: parseFloat(finalValue.toFixed(2)),
        totalReturn, buyHoldReturn, totalTrades: trades.length, wins, losses, winRate,
        maxDrawdown, totalPnl: parseFloat(totalPnl.toFixed(2)),
        trades: trades.slice(-20), equity: equity.slice(-100), ts: Date.now()
      }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── PAPER TRADING ───
  } else if (parsedUrl.pathname === '/paper/buy' && req.method === 'POST') {
    try {
      const body = await getBody(req);
      const { ticker, shares, notes } = body;
      const quote = await fetchStock(ticker);
      const price = quote.price;
      const total = price * shares;
      const bal = db.prepare('SELECT cash FROM paper_balance WHERE id = 1').get();
      if (bal.cash < total) { res.writeHead(400); res.end(JSON.stringify({ error: `Insufficient paper cash. Have $${bal.cash.toFixed(2)}, need $${total.toFixed(2)}` })); return; }
      db.prepare('UPDATE paper_balance SET cash = cash - ?, updated_at = CURRENT_TIMESTAMP WHERE id = 1').run(total);
      const id = db.prepare('INSERT INTO paper_trades (ticker, name, action, shares, price, total, notes) VALUES (?, ?, ?, ?, ?, ?, ?)').run(ticker.toUpperCase(), quote.name, 'BUY', shares, price, total, notes || '').lastInsertRowid;
      guardianLog('paper_buy', ticker.toUpperCase(), { shares, price, total });
      res.writeHead(200); res.end(JSON.stringify({ success: true, id, price, total, cashLeft: bal.cash - total }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  } else if (parsedUrl.pathname === '/paper/sell' && req.method === 'POST') {
    try {
      const body = await getBody(req);
      const { id } = body;
      const trade = db.prepare("SELECT * FROM paper_trades WHERE id = ? AND status = 'OPEN'").get(id);
      if (!trade) { res.writeHead(404); res.end(JSON.stringify({ error: 'Trade not found' })); return; }
      const quote = await fetchStock(trade.ticker);
      const closePrice = quote.price;
      const pnl = (closePrice - trade.price) * trade.shares;
      const pnlPct = ((closePrice - trade.price) / trade.price * 100).toFixed(2);
      db.prepare("UPDATE paper_trades SET status='CLOSED', closed_at=CURRENT_TIMESTAMP, close_price=?, pnl=? WHERE id=?").run(closePrice, pnl, id);
      db.prepare('UPDATE paper_balance SET cash = cash + ?, updated_at = CURRENT_TIMESTAMP WHERE id = 1').run(closePrice * trade.shares);
      guardianLog('paper_sell', trade.ticker, { pnl, pnlPct });
      res.writeHead(200); res.end(JSON.stringify({ success: true, closePrice, pnl: parseFloat(pnl.toFixed(2)), pnlPct }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  } else if (parsedUrl.pathname === '/paper/positions') {
    try {
      const open = db.prepare("SELECT * FROM paper_trades WHERE status = 'OPEN' ORDER BY opened_at DESC").all();
      const closed = db.prepare("SELECT * FROM paper_trades WHERE status = 'CLOSED' ORDER BY closed_at DESC LIMIT 20").all();
      const bal = db.prepare('SELECT * FROM paper_balance WHERE id = 1').get();
      const enriched = await Promise.all(open.map(async t => {
        try {
          const q = await fetchStock(t.ticker);
          const unrealised = (q.price - t.price) * t.shares;
          const unrealisedPct = ((q.price - t.price) / t.price * 100).toFixed(2);
          return { ...t, currentPrice: q.price, unrealised: parseFloat(unrealised.toFixed(2)), unrealisedPct };
        } catch(e) { return { ...t, currentPrice: null, unrealised: null }; }
      }));
      const totalPnl = closed.reduce((s,t)=>s+(t.pnl||0),0);
      const portfolioValue = enriched.reduce((s,t)=>s+(t.currentPrice||t.price)*t.shares,0);
      res.writeHead(200); res.end(JSON.stringify({ open: enriched, closed, balance: bal, portfolioValue: parseFloat(portfolioValue.toFixed(2)), totalPnl: parseFloat(totalPnl.toFixed(2)), ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  } else if (parsedUrl.pathname === '/paper/reset' && req.method === 'POST') {
    try {
      const body = await getBody(req);
      const amount = parseFloat(body.amount) || 10000;
      db.prepare('DELETE FROM paper_trades').run();
      db.prepare('UPDATE paper_balance SET cash = ?, starting_cash = ?, updated_at = CURRENT_TIMESTAMP WHERE id = 1').run(amount, amount);
      res.writeHead(200); res.end(JSON.stringify({ success: true, cash: amount }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ═══════════════════════════════════════════════════════════
  // 📊 DATA ENGINE ENDPOINTS
  // ═══════════════════════════════════════════════════════════

  // Run data collection manually
  } else if (parsedUrl.pathname === '/data/collect' && req.method === 'POST') {
    try {
      res.writeHead(200); res.end(JSON.stringify({ status: 'started', message: 'Collection running in background' }));
      runDataEngine(true).then(r => console.log('[DataEngine] Manual run complete:', r));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // Watchlist management
  } else if (parsedUrl.pathname === '/data/watchlist') {
    try {
      const list = db.prepare('SELECT * FROM watchlist WHERE active = 1 ORDER BY category, ticker').all();
      // Enrich with latest snapshot
      const enriched = list.map(w => {
        const snap = db.prepare('SELECT * FROM daily_snapshots WHERE ticker = ? ORDER BY date DESC LIMIT 1').get(w.ticker);
        const earnCount = db.prepare('SELECT COUNT(*) as c FROM earnings_history WHERE ticker = ?').get(w.ticker);
        const insiderCount = db.prepare('SELECT COUNT(*) as c FROM insider_trades WHERE ticker = ?').get(w.ticker);
        const snapCount = db.prepare('SELECT COUNT(*) as c FROM daily_snapshots WHERE ticker = ?').get(w.ticker);
        return { ...w, latestSnap: snap, earnings: earnCount.c, insiders: insiderCount.c, snapshots: snapCount.c };
      });
      res.writeHead(200); res.end(JSON.stringify({ watchlist: enriched, ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  } else if (parsedUrl.pathname === '/data/watchlist/add' && req.method === 'POST') {
    try {
      const body = await getBody(req);
      const ticker = body.ticker?.toUpperCase();
      if (!ticker) { res.writeHead(400); res.end(JSON.stringify({ error: 'ticker required' })); return; }
      const quote = await fetchStock(ticker);
      db.prepare('INSERT OR REPLACE INTO watchlist (ticker, name, category, active) VALUES (?, ?, ?, 1)')
        .run(ticker, quote.name || ticker, body.category || 'General');
      res.writeHead(200); res.end(JSON.stringify({ success: true, ticker, name: quote.name }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  } else if (parsedUrl.pathname === '/data/watchlist/remove' && req.method === 'POST') {
    try {
      const body = await getBody(req);
      db.prepare('UPDATE watchlist SET active = 0 WHERE ticker = ?').run(body.ticker?.toUpperCase());
      res.writeHead(200); res.end(JSON.stringify({ success: true }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // Snapshot history for a ticker
  } else if (parsedUrl.pathname === '/data/snapshots') {
    const t = parsedUrl.searchParams.get('ticker');
    const days = parseInt(parsedUrl.searchParams.get('days') || '90');
    try {
      const snaps = db.prepare('SELECT * FROM daily_snapshots WHERE ticker = ? ORDER BY date DESC LIMIT ?').all(t || '%', days);
      res.writeHead(200); res.end(JSON.stringify({ ticker: t, snapshots: snaps, count: snaps.length }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // Earnings history
  } else if (parsedUrl.pathname === '/data/earnings') {
    const t = parsedUrl.searchParams.get('ticker');
    try {
      const earnings = t
        ? db.prepare('SELECT * FROM earnings_history WHERE ticker = ? ORDER BY earnings_date DESC').all(t)
        : db.prepare('SELECT * FROM earnings_history ORDER BY earnings_date DESC LIMIT 50').all();
      const stats = t ? db.prepare(`SELECT COUNT(*) as total, SUM(CASE WHEN beat_miss='BEAT' THEN 1 ELSE 0 END) as beats, AVG(eps_surprise_pct) as avg_surprise FROM earnings_history WHERE ticker = ?`).get(t) : null;
      res.writeHead(200); res.end(JSON.stringify({ ticker: t, earnings, stats, count: earnings.length }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // Insider trades
  } else if (parsedUrl.pathname === '/data/insiders') {
    const t = parsedUrl.searchParams.get('ticker');
    try {
      const trades = t
        ? db.prepare('SELECT * FROM insider_trades WHERE ticker = ? ORDER BY trade_date DESC LIMIT 30').all(t)
        : db.prepare('SELECT * FROM insider_trades ORDER BY trade_date DESC LIMIT 50').all();
      const buys = trades.filter(t => t.trade_type === 'BUY');
      const sells = trades.filter(t => t.trade_type === 'SELL');
      res.writeHead(200); res.end(JSON.stringify({ ticker: t, trades, buys: buys.length, sells: sells.length, clusterBuy: buys.length >= 3 }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // Database stats — how much data we've collected
  } else if (parsedUrl.pathname === '/data/stats') {
    try {
      const snapCount = db.prepare('SELECT COUNT(*) as c FROM daily_snapshots').get();
      const earningsCount = db.prepare('SELECT COUNT(*) as c FROM earnings_history').get();
      const insiderCount = db.prepare('SELECT COUNT(*) as c FROM insider_trades').get();
      const watchCount = db.prepare('SELECT COUNT(*) as c FROM watchlist WHERE active = 1').get();
      const oldestSnap = db.prepare('SELECT MIN(date) as d FROM daily_snapshots').get();
      const newestSnap = db.prepare('SELECT MAX(date) as d FROM daily_snapshots').get();
      const logs = db.prepare('SELECT * FROM data_engine_log ORDER BY ts DESC LIMIT 5').all();
      const topTickers = db.prepare('SELECT ticker, COUNT(*) as days FROM daily_snapshots GROUP BY ticker ORDER BY days DESC LIMIT 10').all();
      res.writeHead(200); res.end(JSON.stringify({
        snapshots: snapCount.c, earnings: earningsCount.c, insiders: insiderCount.c,
        watchlist: watchCount.c, oldestDate: oldestSnap.d, newestDate: newestSnap.d,
        recentLogs: logs, topTickers, ts: Date.now()
      }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // Pattern analysis — what does YOUR data say
  } else if (parsedUrl.pathname === '/data/patterns') {
    const t = parsedUrl.searchParams.get('ticker');
    try {
      const snaps = db.prepare('SELECT * FROM daily_snapshots WHERE ticker = ? ORDER BY date ASC').all(t);
      if (snaps.length < 10) { res.writeHead(200); res.end(JSON.stringify({ patterns: [], message: 'Need more data — keep collecting' })); return; }

      const patterns = [];

      // Pattern 1: RSI oversold bounce
      let rsiBounces = 0, rsiWins = 0;
      for (let i = 0; i < snaps.length - 5; i++) {
        if (snaps[i].rsi_14 < 30) {
          rsiBounces++;
          const futureReturn = snaps[i+5] ? ((snaps[i+5].price - snaps[i].price) / snaps[i].price * 100) : null;
          if (futureReturn > 0) rsiWins++;
        }
      }
      if (rsiBounces >= 3) patterns.push({ type: 'RSI Oversold Bounce', ticker: t, occurrences: rsiBounces, winRate: parseFloat((rsiWins/rsiBounces*100).toFixed(0)), description: `When RSI drops below 30, price rose within 5 days ${(rsiWins/rsiBounces*100).toFixed(0)}% of the time` });

      // Pattern 2: Volume spike returns
      let volSpikes = 0, volWins = 0;
      for (let i = 0; i < snaps.length - 5; i++) {
        if (snaps[i].vol_ratio > 2) {
          volSpikes++;
          const futureReturn = snaps[i+5] ? ((snaps[i+5].price - snaps[i].price) / snaps[i].price * 100) : null;
          if (futureReturn > 2) volWins++;
        }
      }
      if (volSpikes >= 3) patterns.push({ type: 'Volume Spike Follow-Through', ticker: t, occurrences: volSpikes, winRate: parseFloat((volWins/volSpikes*100).toFixed(0)), description: `2x+ volume spikes led to 2%+ gain within 5 days ${(volWins/volSpikes*100).toFixed(0)}% of the time` });

      // Pattern 3: Near 52W low bounce
      let lowBounces = 0, lowWins = 0;
      for (let i = 0; i < snaps.length - 10; i++) {
        if (snaps[i].dist_from_low < 5) {
          lowBounces++;
          const futureReturn = snaps[i+10] ? ((snaps[i+10].price - snaps[i].price) / snaps[i].price * 100) : null;
          if (futureReturn > 3) lowWins++;
        }
      }
      if (lowBounces >= 2) patterns.push({ type: '52W Low Bounce', ticker: t, occurrences: lowBounces, winRate: parseFloat((lowWins/lowBounces*100).toFixed(0)), description: `Within 5% of 52W low, price rose 3%+ within 10 days ${(lowWins/lowBounces*100).toFixed(0)}% of the time` });

      res.writeHead(200); res.end(JSON.stringify({ ticker: t, patterns, dataPoints: snaps.length, dateRange: `${snaps[0]?.date} to ${snaps[snaps.length-1]?.date}` }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── BEAR CASE DESTROYER ───
  } else if (parsedUrl.pathname === '/intel/bearcase') {
    try {
      const body = await getBody(req);
      const { ticker, bullThesis } = body;
      const [quote, hist, news] = await Promise.all([fetchStock(ticker), fetchHistorical(ticker), fetchAllNews(ticker, ticker)]);
      const closes = hist.closes.filter(c=>c!==null);
      const rsi = ti.RSI.calculate({ values: closes, period: 14 });
      const change20d = closes.length > 21 ? ((closes[closes.length-1]-closes[closes.length-21])/closes[closes.length-21]*100).toFixed(2) : 0;
      const dbEarnings = db.prepare('SELECT * FROM earnings_history WHERE ticker = ? ORDER BY earnings_date DESC LIMIT 4').all(ticker.toUpperCase());
      const dbInsiders = db.prepare("SELECT * FROM insider_trades WHERE ticker = ? AND trade_type = 'SELL' ORDER BY trade_date DESC LIMIT 5").all(ticker.toUpperCase());
      const claudeRes = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514', max_tokens: 1200,
        messages: [{ role: 'user', content: `You are a ruthless short seller. Your job is to DESTROY this bull thesis with facts.

IMPORTANT: Write everything in simple plain English. Imagine you are explaining to a smart 18 year old who is just learning to trade and has never worked in finance. No jargon, no complex terms. If you must use a technical word, explain it in brackets immediately after.



STOCK: ${ticker} — Price: $${quote.price} — 20D Change: ${change20d}%
RSI: ${rsi[rsi.length-1]?.toFixed(1)}
52W Range: $${quote.yearLow} - $${quote.yearHigh}

BULL THESIS TO DESTROY: "${bullThesis}"

RECENT NEWS: ${news.slice(0,6).map(n=>n.title).join(' | ')}
EARNINGS HISTORY: ${dbEarnings.map(e=>`${e.earnings_date}: ${e.beat_miss} (${e.eps_surprise_pct?.toFixed(1)}%)`).join(', ') || 'No data yet'}
INSIDER SELLS: ${dbInsiders.length} recent sell transactions

Respond in JSON only:
{
  "verdict": "WEAK THESIS" | "MODERATE THESIS" | "STRONG THESIS",
  "thesisScore": <1-10 how strong the bull case actually is>,
  "bearArguments": [
    { "argument": "specific reason 1", "severity": "CRITICAL|HIGH|MEDIUM", "evidence": "data backing this" },
    { "argument": "specific reason 2", "severity": "CRITICAL|HIGH|MEDIUM", "evidence": "data backing this" },
    { "argument": "specific reason 3", "severity": "CRITICAL|HIGH|MEDIUM", "evidence": "data backing this" }
  ],
  "biggestBlindspot": "the one risk you are almost certainly ignoring",
  "whatCouldKillThisTrade": "specific scenario that makes you lose 30%+",
  "counterArgument": "the strongest thing the bulls have going for them despite all this",
  "finalVerdict": "should you still enter, wait, or avoid — be brutal and direct"
}` }]
      });
      const raw = claudeRes.content[0].text.replace(/```json|```/g,'').trim();
      guardianLog('bear_case', ticker, {});
      res.writeHead(200); res.end(JSON.stringify({ ticker, price: quote.price, analysis: JSON.parse(raw), ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── PRE-MORTEM ───
  } else if (parsedUrl.pathname === '/intel/premortem') {
    try {
      const body = await getBody(req);
      const { ticker, entryPrice, thesis } = body;
      const [quote, hist] = await Promise.all([fetchStock(ticker), fetchHistorical(ticker)]);
      const closes = hist.closes.filter(c=>c!==null);
      const rsi = ti.RSI.calculate({ values: closes, period: 14 });
      const dbEarnings = db.prepare('SELECT * FROM earnings_history WHERE ticker = ? ORDER BY earnings_date DESC LIMIT 4').all(ticker.toUpperCase());
      const claudeRes = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514', max_tokens: 1200,
        messages: [{ role: 'user', content: `You are a post-mortem analyst. Imagine it is 12 months from now and this trade FAILED catastrophically.

IMPORTANT: Write everything in simple plain English. Imagine you are explaining to a smart 18 year old who is just learning to trade and has never worked in finance. No jargon, no complex terms. If you must use a technical word, explain it in brackets immediately after.



TRADE: ${ticker} entered at $${entryPrice || quote.price}
CURRENT PRICE: $${quote.price}
RSI: ${rsi[rsi.length-1]?.toFixed(1)}
THESIS: "${thesis || 'Not provided'}"
EARNINGS TRACK RECORD: ${dbEarnings.map(e=>`${e.beat_miss}`).join(', ') || 'Unknown'}

Write the post-mortem of why this trade failed. Be brutally specific. Respond in JSON only:
{
  "headline": "one sentence describing how the trade failed",
  "stockPriceNow": <where the stock is 12 months later in your scenario>,
  "lossPct": <how much was lost>,
  "whatWentWrong": [
    "specific internal failure 1 — company execution",
    "specific failure 2 — macro/sector",
    "specific failure 3 — timing/entry mistake"
  ],
  "warningSignals": ["signal that was visible at entry but ignored 1", "signal 2", "signal 3"],
  "kpiThatMissed": "the specific metric that first showed the thesis was breaking down",
  "couldHaveAvoided": "the one thing you should have done differently at entry",
  "recoveryScenario": "what would need to happen for the stock to recover",
  "lessonLearned": "the single most important trading lesson from this failure",
  "probabilityOfThisScenario": <0-100 how likely this bad outcome actually is>
}` }]
      });
      const raw = claudeRes.content[0].text.replace(/```json|```/g,'').trim();
      guardianLog('premortem', ticker, {});
      res.writeHead(200); res.end(JSON.stringify({ ticker, entryPrice: entryPrice || quote.price, premortem: JSON.parse(raw), ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── HYPE FILTER ───
  } else if (parsedUrl.pathname === '/intel/hypefilter') {
    try {
      const body = await getBody(req);
      const { ticker, buzzword = 'AI' } = body;
      const [quote, news] = await Promise.all([fetchStock(ticker), fetchAllNews(ticker, ticker)]);
      const claudeRes = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514', max_tokens: 1000,
        messages: [{ role: 'user', content: `You are a hype detector. Separate genuine business transformation from buzzword marketing.

IMPORTANT: Write everything in simple plain English. Imagine you are explaining to a smart 18 year old who is just learning to trade and has never worked in finance. No jargon, no complex terms. If you must use a technical word, explain it in brackets immediately after.



STOCK: ${ticker} — $${quote.price}
BUZZWORD TO ANALYSE: "${buzzword}"
RECENT NEWS (${news.length} articles): ${news.slice(0,10).map(n=>n.title).join(' | ')}

Count how many times "${buzzword}" appears in context vs actual capital allocation. Respond in JSON only:
{
  "hypeScore": <0-10, 10 = pure hype, 0 = fully backed by reality>,
  "buzzwordMentions": <estimated frequency in earnings calls and press releases>,
  "actualCapexIncrease": "estimated R&D/capex change related to ${buzzword}",
  "revenueFromTheme": "actual revenue attributable to ${buzzword} if any",
  "gapAnalysis": "the gap between what they say and what they spend",
  "comparativeHype": "how this compares to peers in the same space",
  "genuineSignals": ["real evidence this isnt just hype 1", "evidence 2"],
  "hypeSignals": ["red flag 1 — just talk", "red flag 2"],
  "verdict": "GENUINE TRANSFORMATION" | "PARTIALLY REAL" | "PURE HYPE" | "DANGEROUS HYPE",
  "tradingImplication": "what this hype analysis means for the stock price short and long term",
  "recommendation": "buy the hype now and sell before reality hits / avoid / genuine long term hold"
}` }]
      });
      const raw = claudeRes.content[0].text.replace(/```json|```/g,'').trim();
      guardianLog('hype_filter', ticker, { buzzword });
      res.writeHead(200); res.end(JSON.stringify({ ticker, buzzword, analysis: JSON.parse(raw), ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── EXIT PLANNER ───
  } else if (parsedUrl.pathname === '/intel/exitplan') {
    try {
      const body = await getBody(req);
      const { ticker, entryPrice, shares } = body;
      const [quote, hist] = await Promise.all([fetchStock(ticker), fetchHistorical(ticker)]);
      const closes = hist.closes.filter(c=>c!==null);
      const highs = hist.highs?.filter(c=>c!==null) || closes;
      const lows = hist.lows?.filter(c=>c!==null) || closes;
      const rsi = ti.RSI.calculate({ values: closes, period: 14 });
      const atr = ti.ATR.calculate({ high: highs.slice(-20), low: lows.slice(-20), close: closes.slice(-20), period: 14 });
      const currentATR = atr[atr.length-1] || (quote.price * 0.02);
      const entry = parseFloat(entryPrice) || quote.price;
      const currentPnlPct = ((quote.price - entry) / entry * 100).toFixed(2);
      const stopLoss1 = (entry - currentATR * 1.5).toFixed(2);
      const stopLoss2 = (entry - currentATR * 2).toFixed(2);
      const tp1 = (entry + currentATR * 2).toFixed(2);
      const tp2 = (entry + currentATR * 4).toFixed(2);
      const tp3 = (entry + currentATR * 6).toFixed(2);
      const dbPattern = db.prepare('SELECT * FROM daily_snapshots WHERE ticker = ? ORDER BY date DESC LIMIT 30').all(ticker.toUpperCase());
      const claudeRes = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514', max_tokens: 1000,
        messages: [{ role: 'user', content: `You are an exit strategy architect. Build a complete exit plan.

IMPORTANT: Write everything in simple plain English. Imagine you are explaining to a smart 18 year old who is just learning to trade and has never worked in finance. No jargon, no complex terms. If you must use a technical word, explain it in brackets immediately after.



TRADE: ${ticker} — Entry: $${entry} — Current: $${quote.price} — P&L: ${currentPnlPct}%
SHARES: ${shares || 'Unknown'}
ATR(14): $${currentATR.toFixed(2)}
RSI: ${rsi[rsi.length-1]?.toFixed(1)}
52W: $${quote.yearLow} - $${quote.yearHigh}
ATR-BASED LEVELS: Stop1=$${stopLoss1}, Stop2=$${stopLoss2}, TP1=$${tp1}, TP2=$${tp2}, TP3=$${tp3}
MY DATA POINTS: ${dbPattern.length} days of historical snapshots

Respond in JSON only:
{
  "currentStatus": "IN PROFIT" | "AT LOSS" | "BREAKEVEN",
  "stopLoss": { "tight": ${stopLoss1}, "normal": ${stopLoss2}, "recommended": <which one and why> },
  "targets": [
    { "price": ${tp1}, "label": "Target 1", "action": "sell 33% here", "probability": <0-100> },
    { "price": ${tp2}, "label": "Target 2", "action": "sell another 33%", "probability": <0-100> },
    { "price": ${tp3}, "label": "Target 3", "action": "let remainder run", "probability": <0-100> }
  ],
  "trailingStopStrategy": "how to use a trailing stop to lock in gains as price rises",
  "exitTriggers": ["specific news event that should trigger immediate sell", "technical signal to exit", "time-based rule"],
  "holdOrSell": "HOLD" | "TAKE PARTIAL PROFIT" | "SELL ALL" | "CUT LOSS",
  "reasoning": "2 sentence explanation of the exit recommendation",
  "worstCaseIfWrongStop": <dollar loss if stop is hit on ${shares || 10} shares>,
  "bestCaseAtTarget3": <dollar gain if target 3 hit on ${shares || 10} shares>
}` }]
      });
      const raw = claudeRes.content[0].text.replace(/```json|```/g,'').trim();
      guardianLog('exit_plan', ticker, { entryPrice: entry });
      res.writeHead(200); res.end(JSON.stringify({ ticker, entry, currentPrice: quote.price, currentPnlPct, atr: currentATR.toFixed(2), exitPlan: JSON.parse(raw), ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── TRADE IDEA GENERATOR ───
  } else if (parsedUrl.pathname === '/intel/tradeideas') {
    try {
      const body = await getBody(req);
      const { tickers } = body;
      const tickerList = (tickers || 'AAPL,TSLA,NVDA,MSFT,AMD,MARA,RIOT,PLTR,SOFI,NIO').split(',').slice(0,10);
      const marketData = await Promise.allSettled(tickerList.map(async t => {
        try {
          const [q, h] = await Promise.all([fetchStock(t), fetchHistorical(t)]);
          const closes = h.closes.filter(c=>c!==null);
          const vols = h.volumes.filter(v=>v!==null);
          const rsi = ti.RSI.calculate({ values: closes, period: 14 });
          const avgVol = vols.slice(-21,-1).reduce((a,b)=>a+b,0)/20;
          const volRatio = vols[vols.length-1]/avgVol;
          const change5d = closes.length > 6 ? ((closes[closes.length-1]-closes[closes.length-6])/closes[closes.length-6]*100).toFixed(2) : 0;
          const dbSnap = db.prepare('SELECT * FROM daily_snapshots WHERE ticker = ? ORDER BY date DESC LIMIT 5').all(t);
          const dbEarn = db.prepare('SELECT * FROM earnings_history WHERE ticker = ? ORDER BY earnings_date DESC LIMIT 2').all(t);
          return { ticker: t, price: q.price, change1d: q.changePercent, change5d, rsi: rsi[rsi.length-1]?.toFixed(1), volRatio: volRatio.toFixed(1), yearHigh: q.yearHigh, yearLow: q.yearLow, myData: dbSnap.length, recentEarnings: dbEarn[0]?.beat_miss || 'Unknown' };
        } catch(e) { return null; }
      }));
      const stocks = marketData.filter(r=>r.status==='fulfilled'&&r.value).map(r=>r.value);
      const claudeRes = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514', max_tokens: 1500,
        messages: [{ role: 'user', content: `You are a senior trader. Generate 5 high-probability trade ideas from this live market data.

IMPORTANT: Write everything in simple plain English. Imagine you are explaining to a smart 18 year old who is just learning to trade and has never worked in finance. No jargon, no complex terms. If you must use a technical word, explain it in brackets immediately after.



LIVE MARKET DATA RIGHT NOW:
${stocks.map(s=>`${s.ticker}: CURRENT PRICE $${s.price}, 1D: ${s.change1d}%, 5D: ${s.change5d}%, RSI: ${s.rsi}, Vol: ${s.volRatio}x, 52W High: $${s.yearHigh}, 52W Low: $${s.yearLow}, Last Earnings: ${s.recentEarnings}`).join('\n')}

RULES:
- Do NOT suggest buying at the current market price
- Each idea must be a PLANNED entry: either wait for a PULLBACK to support, or wait for a BREAKOUT above resistance
- All prices (entry, stop, targets) must be realistic dollar amounts based on the live prices above
- currentPrice must exactly match the live price shown above for that ticker
- entryTrigger must be a specific plain-English sentence like "Wait for price to pull back to $175 then enter" or "Enter if price breaks above $192 on volume above 2x average"

Example of correct output for NVDA if current price is $185:
{
  "ticker": "NVDA",
  "direction": "LONG",
  "entryType": "PULLBACK",
  "currentPrice": 185.00,
  "entry": 178.00,
  "entryTrigger": "Wait for pullback to $178 support zone near 20-day MA before entering",
  "stopLoss": 172.00,
  "target1": 192.00,
  "target2": 200.00,
  "riskReward": "1:2.3",
  "timeframe": "1-2 weeks",
  "catalyst": "AI capex cycle",
  "technicalReason": "RSI cooling from overbought, $178 is strong support",
  "confidence": 7,
  "riskLevel": "MEDIUM"
}

Now generate 5 ideas from the live data above. Respond in JSON only:
{
  "ideas": [ ...5 ideas following the exact same structure as the example above... ],
  "marketBias": "BULLISH | BEARISH | MIXED",
  "bestIdea": "which of the 5 has the best setup and why"
}` }]
      });
      const raw = claudeRes.content[0].text.replace(/```json|```/g,'').trim();
      const parsed = JSON.parse(raw);
      // Inject live price from our own data — never trust Claude to echo it back correctly
      const priceMap = {};
      stocks.forEach(s => { priceMap[s.ticker] = s.price; });
      if (parsed.ideas) {
        parsed.ideas = parsed.ideas.map(idea => ({
          ...idea,
          currentPrice: priceMap[idea.ticker] || idea.currentPrice,
          entryTrigger: idea.entryTrigger || idea.catalyst || 'Wait for setup confirmation'
        }));
      }
      guardianLog('trade_ideas', null, { tickers: tickerList });
      res.writeHead(200); res.end(JSON.stringify({ ideas: parsed, stocksAnalysed: stocks.length, ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── TRADING JOURNAL ANALYZER ───
  } else if (parsedUrl.pathname === '/intel/journalanalyze') {
    try {
      const today = new Date().toISOString().split('T')[0];
      const last30days = new Date(Date.now() - 30*24*3600000).toISOString().split('T')[0];
      const signals = db.prepare('SELECT * FROM signal_log WHERE logged_at >= ? ORDER BY logged_at DESC').all(last30days);
      const events = db.prepare('SELECT * FROM guardian_events WHERE ts >= ? ORDER BY ts DESC').all(last30days);
      const interventions = db.prepare('SELECT * FROM guardian_interventions WHERE ts >= ? ORDER BY ts DESC').all(last30days);
      const paperTrades = db.prepare('SELECT * FROM paper_trades WHERE opened_at >= ? ORDER BY opened_at DESC').all(last30days);
      const paperClosed = paperTrades.filter(t=>t.status==='CLOSED');
      const paperWins = paperClosed.filter(t=>(t.pnl||0)>0).length;
      const tickerFreq = {};
      events.forEach(e=>{ if(e.ticker){ tickerFreq[e.ticker] = (tickerFreq[e.ticker]||0)+1; } });
      const topTickers = Object.entries(tickerFreq).sort((a,b)=>b[1]-a[1]).slice(0,5);
      const claudeRes = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514', max_tokens: 1500,
        messages: [{ role: 'user', content: `You are a trading psychologist and performance coach. Analyse this trader's 30-day activity log.

IMPORTANT: Write everything in simple plain English. Imagine you are explaining to a smart 18 year old who is just learning to trade and has never worked in finance. No jargon, no complex terms. If you must use a technical word, explain it in brackets immediately after.



ACTIVITY SUMMARY (last 30 days):
- Total signals run: ${signals.length}
- Guardian warnings triggered: ${interventions.length}
- Warning types: ${interventions.map(i=>i.title).join(', ') || 'none'}
- Paper trades: ${paperTrades.length} total, ${paperClosed.length} closed
- Paper trade win rate: ${paperClosed.length > 0 ? (paperWins/paperClosed.length*100).toFixed(0) : 0}%
- Most watched tickers: ${topTickers.map(([t,c])=>`${t}(${c}x)`).join(', ')}
- Total app actions: ${events.length}

PAPER TRADE RESULTS:
${paperClosed.slice(0,10).map(t=>`${t.ticker}: ${t.action} ${t.shares}sh @ $${t.price} → $${t.close_price} = ${t.pnl>=0?'+':''}$${t.pnl?.toFixed(2)}`).join('\n') || 'No closed trades'}

Respond in JSON only:
{
  "traderProfile": "2 sentence description of this trader's style and tendencies",
  "topStrengths": ["strength 1", "strength 2"],
  "recurringErrors": [
    { "error": "specific mistake pattern", "frequency": "how often", "cost": "impact on performance" }
  ],
  "behavioralBiases": ["bias 1 detected", "bias 2"],
  "bestPerformingSetup": "what type of trade worked best",
  "worstPerformingSetup": "what consistently lost money",
  "obsessionAlert": ${topTickers.length > 0 && topTickers[0][1] > 10 ? `"Over-focused on ${topTickers[0][0]} — ${topTickers[0][1]} interactions"` : 'null'},
  "threeRules": [
    "Rule 1 — specific rule to improve immediately",
    "Rule 2 — specific rule to improve immediately", 
    "Rule 3 — specific rule to improve immediately"
  ],
  "disciplineScore": <1-10>,
  "projectedImprovement": "what changes if they follow these 3 rules"
}` }]
      });
      const raw = claudeRes.content[0].text.replace(/```json|```/g,'').trim();
      res.writeHead(200); res.end(JSON.stringify({ journal: JSON.parse(raw), period: '30 days', signals: signals.length, trades: paperClosed.length, ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── DAILY TRADE PLAN ───
  } else if (parsedUrl.pathname === '/intel/dailyplan') {
    try {
      const body = await getBody(req);
      const { tickers } = body;
      const watchlist = (tickers || 'SPY,QQQ,AAPL,TSLA,NVDA').split(',').slice(0,8);
      const marketData = await Promise.allSettled(watchlist.map(async t => {
        const q = await fetchStock(t);
        return { ticker: t, price: q.price, change: q.changePercent };
      }));
      const stocks = marketData.filter(r=>r.status==='fulfilled'&&r.value).map(r=>r.value);
      const fgData = await fetch('http://localhost:3000/market/feargreed').then(r=>r.json()).catch(()=>({ score: 50, rating: 'Neutral' }));
      const claudeRes = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514', max_tokens: 1500,
        messages: [{ role: 'user', content: `You are a professional trading coach. Create a complete daily trade plan for today.

IMPORTANT: Write everything in simple plain English. Imagine you are explaining to a smart 18 year old who is just learning to trade and has never worked in finance. No jargon, no complex terms. If you must use a technical word, explain it in brackets immediately after.



TODAY'S MARKET:
Fear & Greed: ${fgData.score} (${fgData.rating})
Watchlist: ${stocks.map(s=>`${s.ticker} $${s.price} (${s.change}%)`).join(', ')}
Date: ${new Date().toLocaleDateString('en-GB', { weekday:'long', year:'numeric', month:'long', day:'numeric' })}

Respond in JSON only:
{
  "dayRating": "STRONG TRADING DAY" | "MODERATE" | "LIGHT DAY" | "STAY FLAT",
  "marketBias": "BULLISH | BEARISH | NEUTRAL",
  "preMarket": {
    "time": "8:00 AM",
    "tasks": ["task 1", "task 2", "task 3"],
    "keyLevels": "SPY levels to watch at open"
  },
  "open": {
    "time": "2:30 PM UK (9:30 AM ET)",
    "strategy": "what to do in first 30 minutes",
    "avoid": "what NOT to do at open"
  },
  "midday": {
    "time": "5:00 PM UK (12:00 PM ET)",
    "checkIn": "what to review midday",
    "adjustment": "how to adjust if market moved against you"
  },
  "close": {
    "time": "9:00 PM UK (4:00 PM ET)",
    "tasks": ["end of day task 1", "task 2"],
    "journalPrompt": "one question to answer in your trading journal tonight"
  },
  "topTradeSetup": "the single best trade setup for today with entry and target",
  "riskReminder": "the most important risk management reminder for today",
  "quote": "a short motivational trading quote for today"
}` }]
      });
      const raw = claudeRes.content[0].text.replace(/```json|```/g,'').trim();
      guardianLog('daily_plan', null, {});
      res.writeHead(200); res.end(JSON.stringify({ plan: JSON.parse(raw), fearGreed: fgData, ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── PORTFOLIO HEALTH CHECK ───
  } else if (parsedUrl.pathname === '/intel/portfoliohealth') {
    try {
      const holdings = db.prepare('SELECT * FROM portfolio ORDER BY addedAt DESC').all();
      const enriched = await Promise.all(holdings.map(async h => {
        try {
          const q = await fetchStock(h.ticker);
          return { ticker: h.ticker, shares: h.shares, buyPrice: h.buyPrice, currentPrice: q.price, value: q.price * h.shares, pnl: (q.price - h.buyPrice) * h.shares, pnlPct: ((q.price - h.buyPrice)/h.buyPrice*100).toFixed(2) };
        } catch(e) { return { ticker: h.ticker, shares: h.shares, buyPrice: h.buyPrice, currentPrice: h.buyPrice, value: h.buyPrice * h.shares, pnl: 0, pnlPct: 0 }; }
      }));
      const totalValue = enriched.reduce((s,h)=>s+h.value, 0);
      const claudeRes = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514', max_tokens: 1500,
        messages: [{ role: 'user', content: `You are a portfolio risk manager. Analyse this portfolio for health, concentration risk, and resilience.

IMPORTANT: Write everything in simple plain English. Imagine you are explaining to a smart 18 year old who is just learning to trade and has never worked in finance. No jargon, no complex terms. If you must use a technical word, explain it in brackets immediately after.



PORTFOLIO (Total Value: $${totalValue.toFixed(2)}):
${enriched.map(h=>`${h.ticker}: ${h.shares} shares @ $${h.currentPrice} = $${h.value.toFixed(2)} (${h.pnlPct}% P&L)`).join('\n')}

Respond in JSON only:
{
  "healthScore": <1-10>,
  "totalValue": ${totalValue.toFixed(2)},
  "overallPnl": "${enriched.reduce((s,h)=>s+h.pnl,0).toFixed(2)}",
  "concentration": [
    { "ticker": "XX", "pct": <% of portfolio>, "risk": "HIGH|MEDIUM|LOW" }
  ],
  "sectorExposure": { "sectorName": <pct> },
  "correlationRisk": "are these stocks likely to fall together in a crash",
  "weakestPosition": "the holding most at risk right now and why",
  "strongestPosition": "the best performing holding and whether to add",
  "survives20pctCrash": <estimated portfolio value after 20% market crash>,
  "rebalanceSuggestion": "specific rebalancing action to improve risk/reward",
  "hedgeSuggestion": "one uncorrelated asset to add as hedge",
  "immediateAction": "the single most important thing to do to this portfolio today"
}` }]
      });
      const raw = claudeRes.content[0].text.replace(/```json|```/g,'').trim();
      res.writeHead(200); res.end(JSON.stringify({ health: JSON.parse(raw), holdings: enriched, totalValue: parseFloat(totalValue.toFixed(2)), ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── DCF FAIR VALUE ───
  } else if (parsedUrl.pathname === '/intel/dcf') {
    try {
      const body = await getBody(req);
      const { ticker, wacc = 8, terminalGrowth = 2 } = body;
      const quote = await fetchStock(ticker);
      const dbEarnings = db.prepare('SELECT * FROM earnings_history WHERE ticker = ? ORDER BY earnings_date DESC LIMIT 8').all(ticker.toUpperCase());
      const claudeRes = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514', max_tokens: 1500,
        messages: [{ role: 'user', content: `You are a valuation analyst. Build a DCF model for

IMPORTANT: Write everything in simple plain English. Imagine you are explaining to a smart 18 year old who is just learning to trade and has never worked in finance. No jargon, no complex terms. If you must use a technical word, explain it in brackets immediately after.

 ${ticker}.

CURRENT PRICE: $${quote.price}
52W RANGE: $${quote.yearLow} - $${quote.yearHigh}
WACC: ${wacc}%
TERMINAL GROWTH RATE: ${terminalGrowth}%
MY EARNINGS DATA: ${dbEarnings.map(e=>`${e.earnings_date}: EPS ${e.actual_eps} (${e.beat_miss})`).join(', ') || 'Limited data'}

Build a realistic DCF. Respond in JSON only:
{
  "fairValue": <your DCF fair value estimate>,
  "currentPrice": ${quote.price},
  "upDownside": <% upside or downside from current price>,
  "verdict": "SIGNIFICANTLY UNDERVALUED" | "SLIGHTLY UNDERVALUED" | "FAIRLY VALUED" | "SLIGHTLY OVERVALUED" | "SIGNIFICANTLY OVERVALUED",
  "assumptions": {
    "revenueGrowthY1": <% growth year 1>,
    "revenueGrowthY2": <% growth year 2>,
    "revenueGrowthY3": <% growth year 3>,
    "fcfMargin": <% free cash flow margin>,
    "wacc": ${wacc},
    "terminalGrowth": ${terminalGrowth}
  },
  "sensitivityAnalysis": [
    { "scenario": "Bear case (growth -2%)", "fairValue": <price> },
    { "scenario": "Base case", "fairValue": <price> },
    { "scenario": "Bull case (growth +2%)", "fairValue": <price> }
  ],
  "impliedGrowthRate": "what growth rate the market is currently pricing in at $${quote.price}",
  "keyRisk": "biggest risk to this valuation",
  "buyZone": "price range where this becomes a clear buy",
  "avoidZone": "price range where valuation becomes stretched"
}` }]
      });
      const raw = claudeRes.content[0].text.replace(/```json|```/g,'').trim();
      guardianLog('dcf_model', ticker, {});
      res.writeHead(200); res.end(JSON.stringify({ ticker, price: quote.price, dcf: JSON.parse(raw), ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── RELATIVE VALUE COMPARER ───
  } else if (parsedUrl.pathname === '/intel/relativevalue') {
    try {
      const body = await getBody(req);
      const { tickerA, tickerB } = body;
      const [qA, qB, hA, hB] = await Promise.all([fetchStock(tickerA), fetchStock(tickerB), fetchHistorical(tickerA), fetchHistorical(tickerB)]);
      const closesA = hA.closes.filter(c=>c!==null);
      const closesB = hB.closes.filter(c=>c!==null);
      const rsiA = ti.RSI.calculate({ values: closesA, period: 14 });
      const rsiB = ti.RSI.calculate({ values: closesB, period: 14 });
      const ret1mA = closesA.length > 22 ? ((closesA[closesA.length-1]-closesA[closesA.length-22])/closesA[closesA.length-22]*100).toFixed(2) : 0;
      const ret1mB = closesB.length > 22 ? ((closesB[closesB.length-1]-closesB[closesB.length-22])/closesB[closesB.length-22]*100).toFixed(2) : 0;
      const dbEarnA = db.prepare('SELECT AVG(eps_surprise_pct) as avg FROM earnings_history WHERE ticker = ?').get(tickerA.toUpperCase());
      const dbEarnB = db.prepare('SELECT AVG(eps_surprise_pct) as avg FROM earnings_history WHERE ticker = ?').get(tickerB.toUpperCase());
      const claudeRes = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514', max_tokens: 1200,
        messages: [{ role: 'user', content: `You are comparing two stocks for someone who is learning to trade. Use simple everyday language. No jargon. Explain like you are talking to a friend who just started investing.

Live data:
${tickerA}: price $${qA.price} | last month return: ${ret1mA}% | RSI: ${rsiA[rsiA.length-1]?.toFixed(1)} | 52-week range: $${qA.yearLow} to $${qA.yearHigh} | average earnings beat: ${dbEarnA?.avg?.toFixed(1)||'?'}%
${tickerB}: price $${qB.price} | last month return: ${ret1mB}% | RSI: ${rsiB[rsiB.length-1]?.toFixed(1)} | 52-week range: $${qB.yearLow} to $${qB.yearHigh} | average earnings beat: ${dbEarnB?.avg?.toFixed(1)||'?'}%

RSI explanation for context: below 40 means the stock has been falling and might bounce. Above 60 means it has been rising and might be getting expensive.

Respond in JSON only. All text must be simple plain English that a beginner can understand:
{
  "winner": "${tickerA}" or "${tickerB}",
  "winnerReason": "explain in 2 simple sentences why this one looks better right now — like telling a friend",
  "comparison": {
    "momentum": { "winner": "X", "reason": "which has been performing better recently and why — simple words" },
    "valuation": { "winner": "X", "reason": "which one is better value for money right now — simple words" },
    "earningsQuality": { "winner": "X", "reason": "which company is better at delivering on its profit promises — simple words" },
    "riskReward": { "winner": "X", "reason": "which one gives you a better chance of making money vs losing money — simple words" },
    "technicals": { "winner": "X", "reason": "what the chart is saying about each stock — simple words" }
  },
  "scorecard": { "${tickerA}": <0-10>, "${tickerB}": <0-10> },
  "ifICouldOnlyBuyOne": "${tickerA}" or "${tickerB}",
  "bestScenarioA": "what good thing would need to happen for ${tickerA} to go up — simple words",
  "bestScenarioB": "what good thing would need to happen for ${tickerB} to go up — simple words",
  "pairTrade": "ignore this if too complex — but if one looks good and the other looks bad, explain simply"
}` }]
      });
      const raw = claudeRes.content[0].text.replace(/```json|```/g,'').trim();
      guardianLog('relative_value', tickerA, { vs: tickerB });
      res.writeHead(200); res.end(JSON.stringify({ tickerA, tickerB, priceA: qA.price, priceB: qB.price, comparison: JSON.parse(raw), ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── MULTI FACTOR RANKER ───
  } else if (parsedUrl.pathname === '/intel/multifactor') {
    try {
      const body = await getBody(req);
      const { tickers, weightMomentum = 40, weightValue = 30, weightEarnings = 30 } = body;
      const tickerList = (tickers || 'AAPL,MSFT,NVDA,GOOG,AMD,TSLA,META,AMZN,AVGO,ORCL').split(',').slice(0,12);
      const stocks = await Promise.allSettled(tickerList.map(async t => {
        try {
          const [q, h] = await Promise.all([fetchStock(t), fetchHistorical(t)]);
          const closes = h.closes.filter(c=>c!==null);
          const rsi = ti.RSI.calculate({ values: closes, period: 14 });
          const ret1m = closes.length > 22 ? ((closes[closes.length-1]-closes[closes.length-22])/closes[closes.length-22]*100) : 0;
          const ret3m = closes.length > 66 ? ((closes[closes.length-1]-closes[closes.length-66])/closes[closes.length-66]*100) : 0;
          const distFromHigh = q.yearHigh ? ((q.yearHigh - q.price)/q.yearHigh*100) : 50;
          const dbEarn = db.prepare('SELECT AVG(eps_surprise_pct) as avg, COUNT(*) as total FROM earnings_history WHERE ticker = ?').get(t);
          // Score each factor 0-100
          const momentumScore = Math.max(0, Math.min(100, 50 + ret1m*2 + ret3m));
          const valueScore = Math.max(0, Math.min(100, 100 - distFromHigh));
          const earningsScore = dbEarn?.total > 0 ? Math.max(0, Math.min(100, 50 + (dbEarn.avg||0)*5)) : 50;
          const compositeScore = (momentumScore * weightMomentum/100) + (valueScore * weightValue/100) + (earningsScore * weightEarnings/100);
          return { ticker: t, price: q.price, change1d: parseFloat(q.changePercent), ret1m: parseFloat(ret1m.toFixed(1)), ret3m: parseFloat(ret3m.toFixed(1)), rsi: rsi[rsi.length-1]?.toFixed(1), momentumScore: parseFloat(momentumScore.toFixed(0)), valueScore: parseFloat(valueScore.toFixed(0)), earningsScore: parseFloat(earningsScore.toFixed(0)), compositeScore: parseFloat(compositeScore.toFixed(0)), earningsData: dbEarn?.total || 0 };
        } catch(e) { return null; }
      }));
      const ranked = stocks.filter(r=>r.status==='fulfilled'&&r.value).map(r=>r.value).sort((a,b)=>b.compositeScore-a.compositeScore);
      res.writeHead(200); res.end(JSON.stringify({ ranked, weights: { momentum: weightMomentum, value: weightValue, earnings: weightEarnings }, ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  // ─── MACRO IMPACT ON PORTFOLIO ───
  } else if (parsedUrl.pathname === '/intel/macroimpact') {
    try {
      const body = await getBody(req);
      const { scenario } = body;
      const holdings = db.prepare('SELECT * FROM portfolio').all();
      const claudeRes = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514', max_tokens: 1500,
        messages: [{ role: 'user', content: `You are a macro strategist at Bridgewater. Analyse how this macro scenario impacts this specific portfolio.

IMPORTANT: Write everything in simple plain English. Imagine you are explaining to a smart 18 year old who is just learning to trade and has never worked in finance. No jargon, no complex terms. If you must use a technical word, explain it in brackets immediately after.



MACRO SCENARIO: "${scenario || 'Higher for longer interest rates — Fed keeps rates elevated for 12+ months'}"

PORTFOLIO HOLDINGS: ${holdings.map(h=>`${h.ticker} (${h.shares} shares @ $${h.buyPrice})`).join(', ') || 'No portfolio holdings — analyse general market impact'}

Respond in JSON only:
{
  "scenarioSummary": "2 sentence description of what this macro environment means",
  "overallImpact": "VERY POSITIVE" | "POSITIVE" | "NEUTRAL" | "NEGATIVE" | "VERY NEGATIVE",
  "portfolioImpact": <estimated % change to overall portfolio in this scenario>,
  "holdingAnalysis": [
    { "ticker": "XX", "impact": "POSITIVE|NEGATIVE|NEUTRAL", "reason": "why this specific stock is affected", "estimatedMove": "+/-X%" }
  ],
  "sectorsToOverweight": ["sector 1 in this environment", "sector 2"],
  "sectorsToUnderweight": ["sector to avoid 1", "sector 2"],
  "hedgeSuggestions": ["specific hedge 1", "hedge 2"],
  "opportunityInCrisis": "the best buying opportunity IF this scenario plays out",
  "timeToPosition": "when to position — now / wait for confirmation / gradually",
  "worstCaseForPortfolio": "the absolute worst case scenario for these specific holdings",
  "actionPlan": ["specific action 1", "specific action 2", "specific action 3"]
}` }]
      });
      const raw = claudeRes.content[0].text.replace(/```json|```/g,'').trim();
      guardianLog('macro_impact', null, { scenario });
      res.writeHead(200); res.end(JSON.stringify({ scenario, impact: JSON.parse(raw), holdings: holdings.length, ts: Date.now() }));
    } catch(e) { res.writeHead(500); res.end(JSON.stringify({ error: e.message })); }

  } else {
    res.writeHead(404); res.end(JSON.stringify({ error: 'Not found' }));
  }
});

server.listen(3000, () => {
  console.log('WealthCore — Qureshi Private running on port 3000');
});
